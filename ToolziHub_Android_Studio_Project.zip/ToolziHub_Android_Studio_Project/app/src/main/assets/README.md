# ToolziHub

Many useful tools. One smart hub.

A free, fast, browser-based micro-tools platform: 77 tools across 10 categories (PDF, Image, Text, Developer, Calculator, Generator, Voice, Career, Email, Media)
(PDF, Image, Text, Developer, Calculator, Generator), built with plain HTML,
CSS and vanilla JavaScript. No build step, no framework, no backend.

---

## 1. Running it locally

The site uses root-relative URLs (`/assets/css/style.css`, `/tools/...`), so
it needs to be served over HTTP rather than opened directly as a `file://`
path. From this folder, run:

```bash
python3 -m http.server 8000
```

Then open **http://localhost:8000/**. Any static server works equally well
(e.g. `npx serve`, VS Code's Live Server extension).

## 2. Deploying it

This is a static site \u2014 there is nothing to build or compile. Drag-and-drop
(or connect this folder/repo to) any static host:

- **Netlify** \u2014 drag the `toolzihub` folder onto app.netlify.com/drop
- **Vercel** \u2014 `vercel deploy` from this folder, or connect a Git repo
- **GitHub Pages** \u2014 push to a repo and enable Pages on the root
- **Cloudflare Pages**, **Firebase Hosting**, or any plain web server (nginx, Apache, S3+CloudFront, etc.)

No environment variables, database, or server-side code are required.

### Before you go live \u2014 replace these placeholders

The build deliberately avoids inventing information it wasn't given (see
Part 4/5 of the spec: "no fake information"). A few spots are left as clearly
marked placeholders for you to fill in:

| Where | What to do |
|---|---|
| `contact.html` | Add your real support/business email addresses |
| `terms.html` | Add your governing jurisdiction |
| `assets/js/*.js`, `sitemap.xml`, page `<link rel="canonical">` tags | Currently use `https://www.toolzihub.com` as a placeholder domain \u2014 find/replace with your real domain once registered |
| `robots.txt` / `sitemap.xml` | Regenerate (see below) after changing the domain so the sitemap URLs match |

## 3. Project structure

```
toolzihub/
  index.html, all-tools.html, about.html, contact.html,
  privacy.html, terms.html, disclaimer.html, 404.html
  categories/<category-id>.html         7 category pages
  tools/<tool-id>.html                  35 tool pages
  assets/
    css/style.css                       entire design system (one file)
    js/
      icons.js                          shared inline-SVG icon set
      categories-data.js                10 categories (generated data)
      tools-data.js                     77 tools (generated data)
      main.js                           nav, dynamic card rendering, FAQ accordions
      search.js                         live search (global + category-scoped)
      tools-logic.js                    the actual working logic for all 77 tools
    images/                             logo + favicons (already optimized)
  sitemap.xml, robots.txt
```

### How a page gets built

Every HTML page in this project is **generated from Python source**, not
hand-edited directly (hand-editing the generated `.html` files works fine for
a one-off tweak, but running the generator again will overwrite them). The
source of truth lives in `/build` (see below) \u2014 keep that folder if you plan
to add more tools later; it's not needed to just deploy the site.

## 4. Adding a new tool (without rebuilding the site)

This is the "Future Tool Addition System" the spec calls for. If you still
have the `/build` folder:

1. **Add the tool's data** to `build/data_tools.py` \u2014 copy an existing entry
   in the `TOOLS` list and fill in `id`, `name`, `category` (an existing
   category id, or see step 3 for a new one), `short`, `description`,
   `keywords`, `icon`, `status`, `howto`, and `faq`. This one entry is what
   powers the tool's card everywhere (search, homepage, category page, All
   Tools), its dedicated page's SEO metadata, and its related-tools links.
2. **Add the tool's interactive markup + logic** in `build/tool_bodies.py`
   (the HTML shell for its inputs/buttons/results) and a matching
   `window.TZTools.<yourTool> = { init() {...} }` block in
   `assets/js/tools-logic.js` (the real working code).
3. **If it needs an icon that doesn't exist yet**, add it to `build/icons.py`.
4. Run the generator:
   ```bash
   cd build
   python3 generate_data_files.py   # regenerates icons.js / *-data.js
   python3 generate.py              # regenerates every HTML page
   ```
   The new tool automatically appears in: global search, its category's
   search, the category page grid, the All Tools page, the homepage (if
   marked `"popular"` or `"new"`), related-tools sections on sibling tools,
   the sitemap, and gets its own SEO-friendly URL at `/tools/<id>.html`. You
   do not need to touch navigation, the sitemap generator, or any other page
   by hand.

## 5. Adding a new category

1. Add an entry to `CATEGORIES` in `build/data_categories.py` (id, name,
   icon, color, short/long description).
2. Point one or more tools' `"category"` field at the new category id.
3. Re-run `python3 generate.py`. The category gets its own page, joins the
   header's Categories dropdown, the homepage category grid, the mobile nav,
   and the All Tools filter sidebar automatically.

## 6. Design system

Colors, type scale, spacing, and every reusable component (buttons, cards,
form fields, the FAQ accordion, toasts, etc.) live in one file:
`assets/css/style.css`, driven by CSS custom properties at the top. The
palette is sampled directly from the ToolziHub logo (navy `#041B45`, blue
`#0EA5EC`, green `#22C55E`, plus teal/purple accents for category icons).

Deliberately **no external font or icon-library request** is made \u2014 the
brief's performance-first requirement is taken literally, so the whole site
uses the system font stack and hand-authored inline SVG icons. The only
external requests the site ever makes are for 7 tools that need a real
processing library (see below), loaded only on that tool's own page.

## 7. Honest limitations (read before you promise these to users)

- **PDF \u2194 Word conversion** preserves text content, not original layout,
  fonts, images, or tables.
- **PDF Compressor** rasterizes each page to shrink file size \u2014 the result is
  no longer text-selectable. This is disclosed on the tool page itself.
- **The code minifier** is a safe, conservative whitespace/comment stripper,
  not a full parser-based minifier (it won't rename variables or restructure
  code). It was tested against string/comment edge cases in both CSS and JS.
- **Seven tools load a third-party library from a CDN** the first time
  they're used (PDF.js, pdf-lib, Mammoth.js, jsPDF, Tesseract.js, JSZip) \u2014
  everything else runs with zero external dependencies. The file/text itself
  is never uploaded anywhere in any tool; only the processing library itself
  is fetched. Every one of these tools fails gracefully with a clear message
  if that library can't load (e.g. no internet connection), rather than
  crashing silently.
- **Invoice Generator** has no logo upload yet. It supports every active ISO 4217
  currency (v10); the PDF prints amounts with the 3-letter code (e.g. `PKR 1,250.00`)
  so every currency renders correctly in the PDF font.
- **Voice tools (v10)** use free, open-source AI that runs in the visitor's browser \u2014
  no API keys and no per-use fees. Text to Speech uses Kokoro-82M (kokoro-js, ~90 MB
  model, downloaded once); Speech to Text file transcription uses Whisper via
  Transformers.js. Both load from jsDelivr / Hugging Face on first use and are cached
  by the browser. Live microphone dictation uses the browser's own SpeechRecognition
  API (Chrome/Edge/Safari), which may be processed by the browser vendor's service.
  Device voices (speechSynthesis) cannot be saved as an audio file.
- **Paycheck Calculator** uses 2026 tax figures (US federal brackets and FICA, UK 2026/27
  for England/Wales/NI, Canada federal + CPP/EI). State and provincial tax is a user-entered
  flat rate. These numbers must be refreshed every tax year.
- **Background Remover** uses the open-source MODNet model via Transformers.js (about 25 MB,
  downloaded once); it is tuned for portraits. Passport Photo Maker has no face detection.
- **Heavier libraries loaded on demand:** pdf-lib, JSZip, pdf.js, jsPDF, heic2any, JsBarcode.
- **Text to Speech word limit:** 1,500 words (about 10 minutes at 150 words/minute).

## 8. What's been tested

Every page was checked (via an automated headless-browser pass) for: valid
HTML nesting, zero JavaScript console errors, no horizontal overflow at 5
viewport widths (360\u20131600px), working internal links (no 404s), exactly one
`<h1>` per page, `alt` text on every image, an accessible label on every form
control, and `lang`/viewport meta tags. Every tool's actual output was
functionally verified (not just "the button doesn't crash") \u2014 including a
real date-math edge-case bug (Jan 31 \u2192 Mar 1) that was caught and fixed
during testing. See the tool pages' own FAQ sections for tool-specific notes.

## Popular section and versions (v12 notes)

- **Popular section:** the home page shows only the top 6 tools whose `status` is `"popular"` in
  `tools-data.js`, ordered by their `rank` (1 = first). Each new version, re-check whether a newly
  added tool deserves a spot and replace the least popular one only if needed. Current top 6:
  Merge PDF, Compress PDF, Temp Mail, PDF to Word, Background Remover, QR Code Generator (Temp Mail replaced Word Counter in v13: roughly 5 million monthly searches).
- **Dark theme:** toggle in the header; saved in `localStorage` (`tz-theme`) and follows the system
  setting until the visitor chooses. All colours come from CSS variables in `style.css`.
- **Motion:** cross-page view transitions (with a JS fade fallback), tool-page entrance, ripple on
  buttons, back-to-top and scroll progress. Everything respects `prefers-reduced-motion`.
- **Shortcuts:** `/` or Ctrl/Cmd+K opens search.

## v13 notes

- **Temp Mail** uses the free mail.tm REST API (no key, 8 requests/second/IP). Their terms require a visible link back to mail.tm
  (included in the tool). Inboxes are kept in `sessionStorage` for the current tab only. It cannot offer .edu addresses.
- **Currency Converter** uses open.er-api.com (attribution link included). **Email Address Checker** uses DNS-over-HTTPS (dns.google, Cloudflare).
- **Media tools** use `MediaRecorder`, `getDisplayMedia` and the Web Audio API; MP3 encoding loads `lamejs` on demand.
- **Scroll reveal:** elements are pre-hidden through `html.tz-js` (set in `<head>`) and a CSS failsafe shows everything after 5 seconds if scripts fail.
- The NEW badge is only used for the latest version's tools; earlier ones are set back to standard.
- Video downloaders (YouTube/TikTok/Facebook/Pinterest) are intentionally not included: they break those platforms' terms and copyright rules and cannot run without a server.

## v14 notes

- **Temp Mail hotfix:** the tool now tries two free services with the same open API (mail.tm, then mail.gw), has a 15-second timeout,
  a Retry button, a manual service selector, and shows the real reason when no service can be reached (usually an ISP, VPN or ad-blocker
  blocking the API). Attribution links to both services are shown on the page.
