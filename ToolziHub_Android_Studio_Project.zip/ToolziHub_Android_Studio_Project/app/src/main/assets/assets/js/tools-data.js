// Tool data — single source of truth for search, cards, related tools, All Tools page.
var TZ_TOOLS = [
  {
    "id": "pdf-to-text",
    "name": "PDF to Text",
    "category": "pdf-tools",
    "icon": "file-text",
    "status": "standard",
    "short": "Extract clean, selectable text from any PDF file.",
    "description": "Pull the text content out of a PDF and get it back as plain text you can copy, search, or drop into another document. Everything runs in your browser \u2014 the file is never uploaded anywhere.",
    "keywords": [
      "pdf to text",
      "extract text from pdf",
      "pdf text extractor",
      "convert pdf to txt",
      "read pdf text"
    ],
    "howto": [
      "Upload or drag in the PDF you want to read.",
      "ToolziHub scans every page and pulls out the text.",
      "Review the extracted text in the box below.",
      "Copy it or download it as a .txt file."
    ],
    "faq": [
      [
        "Does this work with scanned PDFs?",
        "This tool reads text that's already embedded in the PDF. If your PDF is a scan or photo with no selectable text, use the Image to Text (OCR) tool instead."
      ],
      [
        "Is my file uploaded to a server?",
        "No. The PDF is opened and processed directly in your browser tab; it isn't sent anywhere."
      ],
      [
        "Will formatting like tables and columns be preserved?",
        "The tool extracts readable text in reading order. Complex layouts such as multi-column pages or tables may come out re-ordered, so check the result before using it."
      ]
    ],
    "note": null
  },
  {
    "id": "pdf-to-word",
    "name": "PDF to Word",
    "category": "pdf-tools",
    "icon": "file-word",
    "status": "popular",
    "short": "Turn a PDF's text into an editable Word (.docx) file.",
    "description": "Extracts the text from your PDF and packages it into a standard .docx file you can open and edit in Word, Google Docs, or LibreOffice.",
    "keywords": [
      "pdf to word",
      "pdf to docx",
      "convert pdf to word",
      "editable pdf"
    ],
    "howto": [
      "Upload the PDF you want to convert.",
      "ToolziHub extracts the text from every page.",
      "Preview the text that will go into your document.",
      "Download the ready-made .docx file."
    ],
    "faq": [
      [
        "Will the layout look exactly like my PDF?",
        "No \u2014 this conversion focuses on producing an accurate, editable copy of the text. Original formatting such as columns, images and precise fonts aren't recreated. For mostly-text PDFs the result is very usable; for heavily designed documents, expect to reformat."
      ],
      [
        "Can it convert scanned documents?",
        "Only if the PDF already has selectable text. For scanned pages, run the file through Image to Text OCR first."
      ],
      [
        "Is there a file size limit?",
        "Very large PDFs may take longer or use more memory since everything runs in your browser. For best results, use files under about 20 MB."
      ]
    ],
    "note": "This conversion preserves text content, not the original visual layout, images or fonts \u2014 ideal for getting an editable copy of the words, not a pixel-perfect clone.",
    "rank": 4
  },
  {
    "id": "word-to-pdf",
    "name": "Word to PDF",
    "category": "pdf-tools",
    "icon": "file-pdf-arrow",
    "status": "standard",
    "short": "Convert a .docx file into a shareable PDF.",
    "description": "Reads a Word document and lays its text out into a clean, downloadable PDF \u2014 handy when you need a version that looks the same everywhere and is harder to edit by accident.",
    "keywords": [
      "word to pdf",
      "docx to pdf",
      "convert word document to pdf"
    ],
    "howto": [
      "Upload a .docx file.",
      "ToolziHub reads the document's text and structure.",
      "Preview how the content will appear.",
      "Download the generated PDF."
    ],
    "faq": [
      [
        "Will images inside my Word document appear in the PDF?",
        "This tool currently converts the text content of the document. Embedded images and complex formatting like multi-column layouts aren't recreated yet."
      ],
      [
        "Does it support the older .doc format?",
        "Only the modern .docx format is supported. If you have a .doc file, save it as .docx in Word first."
      ],
      [
        "Can I control the page size or margins?",
        "The PDF is generated with standard A4 margins for now. Custom page setup may be added as ToolziHub grows."
      ]
    ],
    "note": "This tool converts the document's text content; embedded images and advanced layout aren't recreated yet."
  },
  {
    "id": "pdf-compressor",
    "name": "PDF Compressor",
    "category": "pdf-tools",
    "icon": "shrink",
    "status": "popular",
    "short": "Shrink a PDF's file size before you email or upload it.",
    "description": "Reduces a PDF's file size by re-rendering each page at a quality level you choose \u2014 useful when a file is too large to email or upload.",
    "keywords": [
      "compress pdf",
      "reduce pdf size",
      "shrink pdf",
      "pdf file size reducer"
    ],
    "howto": [
      "Upload the PDF you want to shrink.",
      "Choose a compression level.",
      "ToolziHub rebuilds a smaller version of the file.",
      "Download the compressed PDF."
    ],
    "faq": [
      [
        "How does the compression work?",
        "Each page is redrawn as a compressed image at the quality level you choose, then reassembled into a new PDF. Lower quality means a smaller file."
      ],
      [
        "Will the text still be selectable afterwards?",
        "No \u2014 because pages are converted to images to shrink them, text in the compressed file is no longer selectable or searchable. Keep your original if you need selectable text."
      ],
      [
        "How much smaller will my file get?",
        "It depends heavily on the original \u2014 PDFs with large, high-resolution images shrink the most, while files that are already small or mostly text may not shrink much further."
      ]
    ],
    "note": "This tool rasterizes each page, trading text-selectability for a smaller file \u2014 great for sharing, not for further text editing.",
    "rank": 2
  },
  {
    "id": "pdf-merge",
    "name": "Merge PDF",
    "category": "pdf-tools",
    "icon": "file-merge",
    "status": "popular",
    "short": "Combine several PDF files into a single document, in any order.",
    "description": "Add two or more PDF files, arrange them in the order you want, and combine them into one PDF you can download straight away.",
    "keywords": [
      "merge pdf",
      "combine pdf files",
      "join pdf",
      "pdf combiner"
    ],
    "howto": [
      "Add the PDF files you want to combine.",
      "Reorder them using the up/down controls if needed.",
      "Select Merge PDFs.",
      "Download the combined file."
    ],
    "faq": [
      [
        "Is there a limit on how many files I can merge?",
        "You can add as many files as your device's memory comfortably allows. For very large batches, merge in smaller groups if the browser feels slow."
      ],
      [
        "Can I remove a file after adding it?",
        "Yes, use the remove button next to any file in the list before merging."
      ],
      [
        "Does merging affect the quality of the original pages?",
        "No. Pages are copied into the new file as-is, so quality is unchanged."
      ]
    ],
    "note": null,
    "rank": 1
  },
  {
    "id": "image-to-text-ocr",
    "name": "Image to Text (OCR)",
    "category": "image-tools",
    "icon": "ocr",
    "status": "standard",
    "short": "Pull text out of a photo, screenshot, or scanned document.",
    "description": "Uses on-device optical character recognition to read the text inside an image \u2014 great for scanned pages, screenshots, or photos of printed text.",
    "keywords": [
      "image to text",
      "ocr",
      "extract text from image",
      "photo to text",
      "scan to text"
    ],
    "howto": [
      "Upload an image that contains text.",
      "Select the language of the text.",
      "ToolziHub scans the image and recognizes the characters.",
      "Copy or download the extracted text."
    ],
    "faq": [
      [
        "What image formats are supported?",
        "JPG, PNG and WebP images all work."
      ],
      [
        "Why did it miss some words?",
        "OCR accuracy depends on image quality \u2014 clear, well-lit, straight-on photos of printed text work best. Handwriting, blurry photos and low-contrast images are harder to read accurately."
      ],
      [
        "Does the image get uploaded anywhere?",
        "No, recognition runs inside your browser using an on-device engine loaded the first time you use the tool."
      ]
    ],
    "note": "This tool loads a recognition engine over the internet the first time you use it, but your image itself is never uploaded \u2014 recognition happens on your device."
  },
  {
    "id": "image-compressor",
    "name": "Image Compressor",
    "category": "image-tools",
    "icon": "shrink",
    "status": "standard",
    "short": "Reduce an image's file size while keeping it looking sharp.",
    "description": "Re-encodes your image at a quality level you choose, so you can shrink file size for faster page loads or smaller attachments without leaving your browser.",
    "keywords": [
      "compress image",
      "reduce image size",
      "image file size reducer",
      "shrink photo"
    ],
    "howto": [
      "Upload the image you want to compress.",
      "Drag the quality slider to your preferred balance of size and clarity.",
      "Watch the estimated file size update live.",
      "Download the compressed image."
    ],
    "faq": [
      [
        "Which formats can I compress?",
        "JPG, PNG and WebP images."
      ],
      [
        "Will compressing reduce the image dimensions?",
        "No, only file size and quality are affected. Use the Image Resizer if you also want to change width or height."
      ],
      [
        "What quality level should I use?",
        "70\u201385% usually gives a big size reduction with little visible quality loss for photos. Go higher if the image contains fine detail or text."
      ]
    ],
    "note": null
  },
  {
    "id": "image-resizer",
    "name": "Image Resizer",
    "category": "image-tools",
    "icon": "resize",
    "status": "standard",
    "short": "Change an image's width and height to exactly the size you need.",
    "description": "Resize an image to specific dimensions or a percentage of the original, with an option to lock proportions so nothing looks stretched.",
    "keywords": [
      "resize image",
      "change image dimensions",
      "image size changer",
      "scale image"
    ],
    "howto": [
      "Upload the image you want to resize.",
      "Enter a new width and/or height, or pick a percentage.",
      "Keep \u201cLock aspect ratio\u201d on to avoid distortion.",
      "Download the resized image."
    ],
    "faq": [
      [
        "What happens if I unlock the aspect ratio?",
        "You can set width and height independently, but the image may look stretched or squashed if the new proportions differ a lot from the original."
      ],
      [
        "Can I enlarge a small image?",
        "Yes, though enlarging beyond the original size can make the image look softer since no new detail is created."
      ],
      [
        "What format will the resized image be saved as?",
        "The output keeps the same format as your original upload."
      ]
    ],
    "note": null
  },
  {
    "id": "image-converter",
    "name": "Image Converter",
    "category": "image-tools",
    "icon": "convert",
    "status": "standard",
    "short": "Convert images between JPG, PNG and WebP.",
    "description": "Switch an image from one format to another \u2014 for example turning a PNG into a smaller WebP, or a WebP into a widely-compatible JPG \u2014 all inside your browser.",
    "keywords": [
      "image converter",
      "jpg to png",
      "png to jpg",
      "convert to webp",
      "webp converter"
    ],
    "howto": [
      "Upload the image you want to convert.",
      "Choose the output format: JPG, PNG or WebP.",
      "For JPG or WebP, set a quality level.",
      "Download the converted file."
    ],
    "faq": [
      [
        "Will converting to JPG lose transparency?",
        "Yes \u2014 JPG doesn't support transparency, so transparent areas will be filled with white. Use PNG or WebP to keep transparency."
      ],
      [
        "Which format should I choose for the web?",
        "WebP typically gives the smallest file size at similar quality, PNG is safer when you need transparency, and JPG is a dependable default for photos."
      ],
      [
        "Does conversion affect image quality?",
        "Converting to PNG keeps quality intact since it's lossless. Converting to JPG or WebP applies compression based on the quality level you choose."
      ]
    ],
    "note": null
  },
  {
    "id": "word-counter",
    "name": "Word & Character Counter",
    "category": "text-tools",
    "icon": "type",
    "status": "standard",
    "short": "Get live word, character, and sentence counts as you type.",
    "description": "Paste or type any text to see word count, character count (with and without spaces), sentence and paragraph counts, and an estimated reading time \u2014 updated instantly.",
    "keywords": [
      "word counter",
      "character counter",
      "count words",
      "text statistics",
      "reading time calculator"
    ],
    "howto": [
      "Type directly into the box, or paste in your text.",
      "Watch the counts update as you type.",
      "Check word, character, sentence and paragraph counts at a glance.",
      "Clear the box to start over."
    ],
    "faq": [
      [
        "Does it count spaces as characters?",
        "Both counts are shown side by side \u2014 total characters including spaces, and characters excluding spaces."
      ],
      [
        "How is reading time calculated?",
        "It's estimated using an average silent reading speed of about 200 words per minute, so treat it as a helpful guide rather than an exact figure."
      ],
      [
        "Is there a limit to how much text I can paste?",
        "No hard limit, though extremely long text may make typing feel slightly less instant on older devices."
      ]
    ],
    "note": null
  },
  {
    "id": "case-converter",
    "name": "Case Converter",
    "category": "text-tools",
    "icon": "case",
    "status": "standard",
    "short": "Switch text between UPPERCASE, lowercase, Title Case and more.",
    "description": "Paste your text and convert it to the capitalization style you need \u2014 including UPPERCASE, lowercase, Title Case, Sentence case, camelCase and snake_case.",
    "keywords": [
      "case converter",
      "uppercase to lowercase",
      "title case converter",
      "camel case",
      "snake case"
    ],
    "howto": [
      "Paste or type your text.",
      "Choose a case style from the options.",
      "The converted text appears instantly.",
      "Copy the result."
    ],
    "faq": [
      [
        "What's the difference between Title Case and Sentence case?",
        "Title Case capitalizes most words (Like This), while Sentence case only capitalizes the first letter of each sentence."
      ],
      [
        "What are camelCase and snake_case used for?",
        "They're common naming styles in programming \u2014 camelCase capitalizes each new word with no spaces (toolziHub), while snake_case joins words with underscores (toolzi_hub)."
      ],
      [
        "Will punctuation be affected?",
        "No, punctuation is left as-is; only letter casing changes."
      ]
    ],
    "note": null
  },
  {
    "id": "remove-duplicate-lines",
    "name": "Remove Duplicate Lines",
    "category": "text-tools",
    "icon": "layers",
    "status": "standard",
    "short": "Clean up a list by removing repeated lines.",
    "description": "Paste in a list of lines \u2014 emails, keywords, URLs, anything \u2014 and get back a version with exact duplicates removed, with options for case sensitivity and trimming.",
    "keywords": [
      "remove duplicate lines",
      "delete duplicate lines",
      "unique lines",
      "list deduplication"
    ],
    "howto": [
      "Paste your list, one item per line.",
      "Choose whether matching should be case-sensitive.",
      "Choose whether to trim extra whitespace before comparing.",
      "Copy or download the cleaned list."
    ],
    "faq": [
      [
        "Does it change the order of my list?",
        "No, the first occurrence of each line is kept in its original position; only later duplicates are removed."
      ],
      [
        "What does \u201ccase-sensitive\u201d mean here?",
        "With it on, \u201cApple\u201d and \u201capple\u201d are treated as different lines. With it off, they're treated as duplicates."
      ],
      [
        "Can it remove blank lines too?",
        "Yes, there's a separate option to strip empty lines from the result."
      ]
    ],
    "note": null
  },
  {
    "id": "json-formatter",
    "name": "JSON Formatter & Validator",
    "category": "developer-tools",
    "icon": "code",
    "status": "standard",
    "short": "Format, validate, and minify JSON in one place.",
    "description": "Paste in JSON to instantly check whether it's valid, pretty-print it with proper indentation, or compress it down to a single line.",
    "keywords": [
      "json formatter",
      "json validator",
      "json beautifier",
      "json minifier",
      "validate json"
    ],
    "howto": [
      "Paste your JSON into the input box.",
      "Select Format to beautify it, or Minify to compress it.",
      "Any syntax errors are highlighted with a description.",
      "Copy the formatted result."
    ],
    "faq": [
      [
        "How does it help me find an error in invalid JSON?",
        "If parsing fails, the tool shows the error message and, where available, its approximate position in your text."
      ],
      [
        "What's the difference between Format and Minify?",
        "Format adds indentation and line breaks for readability. Minify strips all unnecessary whitespace to make the JSON as compact as possible."
      ],
      [
        "Does it support very large JSON files?",
        "Yes, though extremely large payloads may take a moment to process since it all happens in your browser."
      ]
    ],
    "note": null
  },
  {
    "id": "url-encoder-decoder",
    "name": "URL Encoder / Decoder",
    "category": "developer-tools",
    "icon": "link",
    "status": "standard",
    "short": "Encode text for safe use in a URL, or decode an encoded URL.",
    "description": "Convert text into its percent-encoded form for safe use inside URLs and query strings, or decode an already-encoded URL back into readable text.",
    "keywords": [
      "url encoder",
      "url decoder",
      "percent encoding",
      "encode uri component"
    ],
    "howto": [
      "Paste the text or URL you want to convert.",
      "Choose Encode or Decode.",
      "The result appears instantly below.",
      "Copy it for use in your link, code, or query string."
    ],
    "faq": [
      [
        "What characters get encoded?",
        "Characters that aren't safe in a URL \u2014 such as spaces, &, ?, # and other symbols \u2014 are converted to their percent-encoded equivalents (a space becomes %20)."
      ],
      [
        "What happens if I try to decode text that isn't encoded?",
        "Plain text with no percent-encoded sequences is simply returned unchanged."
      ],
      [
        "Can I encode a whole URL, including the https:// part?",
        "You can, but that will also encode characters like : and / that are usually meant to stay as-is. For a full URL, it's often better to only encode individual parameter values."
      ]
    ],
    "note": null
  },
  {
    "id": "code-minifier",
    "name": "HTML / CSS / JS Minifier",
    "category": "developer-tools",
    "icon": "minify",
    "status": "standard",
    "short": "Strip comments and extra whitespace to shrink your code.",
    "description": "Paste in HTML, CSS or JavaScript and get back a smaller version with comments and unnecessary whitespace removed \u2014 a quick way to shave size off a file before deploying it.",
    "keywords": [
      "html minifier",
      "css minifier",
      "javascript minifier",
      "minify code",
      "code compressor"
    ],
    "howto": [
      "Choose HTML, CSS or JavaScript.",
      "Paste in your code.",
      "Select Minify.",
      "Copy or download the smaller version."
    ],
    "faq": [
      [
        "How much smaller will my file get?",
        "It depends on how much whitespace and how many comments your original code contains \u2014 nicely-formatted source with lots of indentation typically shrinks noticeably."
      ],
      [
        "Is this the same as the minification used by professional build tools?",
        "This is a lightweight, browser-based minifier that removes comments and unnecessary whitespace. It doesn't rename variables or restructure code the way advanced build-tool minifiers do."
      ],
      [
        "Could minifying break my code?",
        "The minifier is conservative about not touching content inside strings, but always test minified code before relying on it in production, especially for JavaScript."
      ]
    ],
    "note": "This is a lightweight, whitespace-and-comment minifier meant for quick everyday use \u2014 always review the output before shipping it to production."
  },
  {
    "id": "percentage-calculator",
    "name": "Percentage Calculator",
    "category": "calculator-tools",
    "icon": "percent",
    "status": "standard",
    "short": "Work out percentages, increases, and decreases in seconds.",
    "description": "Covers the percentage calculations people need most often: what a percentage of a number is, what percentage one number is of another, and percentage increase or decrease between two values.",
    "keywords": [
      "percentage calculator",
      "percent increase calculator",
      "percent of a number",
      "percentage difference"
    ],
    "howto": [
      "Choose the type of percentage calculation you need.",
      "Enter the numbers involved.",
      "The answer updates instantly.",
      "Switch calculation types any time."
    ],
    "faq": [
      [
        "How do I calculate a percentage increase?",
        "Choose \u201cPercentage increase/decrease,\u201d enter the original and new values, and the tool works out both the change and the percentage."
      ],
      [
        "Can I calculate what percentage one number is of another?",
        "Yes \u2014 that's the second calculation mode; enter both numbers and it returns the percentage."
      ],
      [
        "Does it handle negative numbers?",
        "Yes, for the increase/decrease calculation, so you can see percentage decreases as well as increases."
      ]
    ],
    "note": null
  },
  {
    "id": "age-calculator",
    "name": "Age Calculator",
    "category": "calculator-tools",
    "icon": "cake",
    "status": "standard",
    "short": "Find someone's exact age in years, months and days.",
    "description": "Enter a date of birth to get an exact age breakdown, plus how many days remain until the next birthday.",
    "keywords": [
      "age calculator",
      "calculate age from date of birth",
      "how old am i",
      "days until birthday"
    ],
    "howto": [
      "Enter a date of birth.",
      "Optionally choose a date to calculate the age as of (defaults to today).",
      "See the exact age in years, months and days.",
      "Check how many days remain until the next birthday."
    ],
    "faq": [
      [
        "Can I calculate someone's age on a specific past or future date?",
        "Yes, change the \u201ccalculate as of\u201d date to any date you like."
      ],
      [
        "Why does the age show in years, months and days instead of just years?",
        "A full breakdown is more precise and useful for eligibility checks, forms, or simple curiosity."
      ],
      [
        "Does it account for leap years?",
        "Yes, the calculation is based on real calendar dates, so leap years are handled automatically."
      ]
    ],
    "note": null
  },
  {
    "id": "date-duration-calculator",
    "name": "Date & Time Duration Calculator",
    "category": "calculator-tools",
    "icon": "duration",
    "status": "standard",
    "short": "Calculate exactly how much time is between two dates.",
    "description": "Pick a start and end date (and time, if you like) to find the exact duration between them in days, hours, and minutes.",
    "keywords": [
      "date duration calculator",
      "days between dates",
      "time between two dates",
      "date difference calculator"
    ],
    "howto": [
      "Enter a start date and time.",
      "Enter an end date and time.",
      "See the total duration broken down into days, hours and minutes.",
      "Adjust either date to explore different ranges."
    ],
    "faq": [
      [
        "Can I calculate a duration that includes time, not just full days?",
        "Yes, both fields accept a specific time as well as a date."
      ],
      [
        "What happens if the end date is before the start date?",
        "The tool will let you know so you can swap the dates around."
      ],
      [
        "Does it account for time zones?",
        "Calculations use the dates and times exactly as entered, based on your device's local time."
      ]
    ],
    "note": null
  },
  {
    "id": "unit-converter",
    "name": "Unit Converter",
    "category": "calculator-tools",
    "icon": "ruler",
    "status": "standard",
    "short": "Convert between common units of length, weight, temperature and more.",
    "description": "Convert values between everyday units across several categories \u2014 length, weight, temperature, volume, area, speed, time and digital storage \u2014 with instant, accurate results.",
    "keywords": [
      "unit converter",
      "length converter",
      "weight converter",
      "temperature converter",
      "convert units"
    ],
    "howto": [
      "Choose a category, such as Length or Weight.",
      "Select the unit you're converting from and to.",
      "Enter a value.",
      "See the converted result instantly."
    ],
    "faq": [
      [
        "Which categories are supported?",
        "Length, weight/mass, temperature, volume, area, speed, time, and digital storage, with the most common units in each."
      ],
      [
        "How accurate are the conversions?",
        "Conversions use standard, widely accepted conversion factors and are accurate to several decimal places."
      ],
      [
        "Can I convert temperature the same way as other units?",
        "Yes \u2014 temperature uses its own formulas rather than a simple multiplier, and the tool handles that automatically."
      ]
    ],
    "note": null
  },
  {
    "id": "invoice-generator",
    "name": "Invoice Generator",
    "category": "generator-tools",
    "icon": "receipt",
    "status": "standard",
    "short": "Create a professional invoice in any currency and download it as a PDF.",
    "description": "Fill in your business details, your client\u2019s details and your line items, choose any world currency, and generate a clean, ready-to-send invoice as a PDF \u2014 no account or template file needed.",
    "keywords": [
      "invoice generator",
      "free invoice maker",
      "create invoice pdf",
      "invoice template",
      "invoice in any currency",
      "multi currency invoice",
      "billing generator"
    ],
    "howto": [
      "Enter your business details and your customer\u2019s name, email, phone and address.",
      "Choose the currency for the invoice from the full list of world currencies.",
      "Add each item or service with a quantity and price, and set a tax rate if needed.",
      "Download the finished invoice as a PDF."
    ],
    "faq": [
      [
        "Can I add my own tax rate?",
        "Yes, enter any tax percentage and the tool recalculates the total automatically."
      ],
      [
        "Is my invoice data saved anywhere?",
        "No \u2014 the invoice is generated entirely in your browser and isn't stored or sent anywhere. Download the PDF before closing the tab."
      ],
      [
        "Can I add a logo?",
        "Logo uploads aren't supported yet; the current version focuses on a clean, text-based layout. This may be added as ToolziHub grows."
      ],
      [
        "Which currencies can I use?",
        "Every active world currency (about 150), from US dollars and euros to Pakistani rupees and Japanese yen. Amounts in the PDF show the 3-letter currency code, such as PKR or EUR, so they print correctly everywhere."
      ]
    ],
    "note": null
  },
  {
    "id": "password-generator",
    "name": "Password Generator",
    "category": "generator-tools",
    "icon": "key",
    "status": "standard",
    "short": "Create strong, random passwords with options you control.",
    "description": "Generate secure passwords using your browser's built-in randomness \u2014 choose the length and which character types to include, then copy the result. Nothing is sent anywhere; every password is created and shown only on your device.",
    "keywords": [
      "password generator",
      "random password",
      "strong password generator",
      "secure password",
      "create password"
    ],
    "howto": [
      "Set how long you want the password to be.",
      "Choose which character types to include \u2014 uppercase, lowercase, numbers, symbols.",
      "Click Generate to create a new password.",
      "Copy it or generate another until you're happy with it."
    ],
    "faq": [
      [
        "Is this password actually secure?",
        "Yes \u2014 it's generated using your browser's cryptographically secure random number generator (the same kind used for encryption), not a predictable pattern."
      ],
      [
        "Are my passwords stored or sent anywhere?",
        "No. Everything happens locally in your browser. ToolziHub never sees or stores the passwords you generate."
      ],
      [
        "What's a good password length?",
        "12\u201316 characters with a mix of character types is a solid baseline for most accounts; use longer for anything sensitive."
      ]
    ],
    "note": null
  },
  {
    "id": "qr-code-generator",
    "name": "QR Code Generator",
    "category": "generator-tools",
    "icon": "qrcode",
    "status": "popular",
    "short": "Turn any text, link, or message into a scannable QR code.",
    "description": "Paste in a URL, message, or any text and get a clean QR code you can preview and download as an image \u2014 ready to print or share.",
    "keywords": [
      "qr code generator",
      "create qr code",
      "qr code maker",
      "generate qr code",
      "url to qr code"
    ],
    "howto": [
      "Type or paste the text or link you want to encode.",
      "The QR code preview updates automatically.",
      "Adjust the size if needed.",
      "Download the QR code as a PNG image."
    ],
    "faq": [
      [
        "What can I put into a QR code?",
        "Any text \u2014 a website link, Wi-Fi details, a phone number, or a short message. The QR code just stores whatever text you give it."
      ],
      [
        "Will the QR code expire?",
        "No \u2014 once downloaded, it's a static image that works forever and doesn't depend on ToolziHub."
      ],
      [
        "Why didn't my QR code load?",
        "This tool loads a small QR-drawing library the first time you use it, so it needs an internet connection on first use \u2014 after that it works from your device."
      ]
    ],
    "note": null,
    "rank": 6
  },
  {
    "id": "lorem-ipsum-generator",
    "name": "Lorem Ipsum Generator",
    "category": "generator-tools",
    "icon": "lorem",
    "status": "standard",
    "short": "Generate placeholder paragraphs, sentences, or words for mockups.",
    "description": "Create ready-to-paste Lorem Ipsum placeholder text in the amount you need \u2014 by paragraphs, sentences, or words \u2014 for mockups, layouts, and designs.",
    "keywords": [
      "lorem ipsum generator",
      "placeholder text generator",
      "dummy text generator",
      "filler text",
      "lorem ipsum"
    ],
    "howto": [
      "Choose whether you want paragraphs, sentences, or words.",
      "Set how many you need.",
      "Click Generate.",
      "Copy the placeholder text into your design or document."
    ],
    "faq": [
      [
        "What is Lorem Ipsum?",
        "It's traditional scrambled Latin-based placeholder text used by designers and developers to fill layouts before real content is ready."
      ],
      [
        "Can I start with the classic 'Lorem ipsum dolor sit amet'?",
        "Yes, that's the default opening \u2014 turn it off if you'd rather have fully randomized text."
      ],
      [
        "Is the text always the same?",
        "Every generation reshuffles the word bank, so you'll get different text (aside from the classic opening if enabled) each time."
      ]
    ],
    "note": null
  },
  {
    "id": "base64-encoder-decoder",
    "name": "Base64 Encoder/Decoder",
    "category": "developer-tools",
    "icon": "base64",
    "status": "standard",
    "short": "Encode text to Base64 or decode Base64 back to plain text.",
    "description": "Convert text to Base64 encoding or decode a Base64 string back into readable text \u2014 with proper handling of accented letters, emoji, and other Unicode characters.",
    "keywords": [
      "base64 encoder",
      "base64 decoder",
      "encode base64",
      "decode base64",
      "base64 converter"
    ],
    "howto": [
      "Paste your text or Base64 string into the box.",
      "Choose Encode or Decode.",
      "The result appears instantly below.",
      "Copy the result with one click."
    ],
    "faq": [
      [
        "Does this handle emoji and accented characters?",
        "Yes \u2014 text is encoded using UTF-8 first, so non-English characters and emoji decode back correctly."
      ],
      [
        "What happens if I paste invalid Base64 to decode?",
        "You'll get a clear error message instead of garbled output or a crash."
      ],
      [
        "Is Base64 encryption?",
        "No \u2014 Base64 just re-represents data in a different format; it provides no security or privacy on its own."
      ]
    ],
    "note": null
  },
  {
    "id": "hash-generator",
    "name": "Hash Generator",
    "category": "developer-tools",
    "icon": "hash",
    "status": "standard",
    "short": "Generate SHA-1, SHA-256, SHA-384, or SHA-512 hashes from text.",
    "description": "Create a cryptographic hash of any text using your browser's built-in Web Crypto API. Useful for checksums, verifying data integrity, or generating consistent identifiers.",
    "keywords": [
      "hash generator",
      "sha256 generator",
      "sha1 hash",
      "checksum generator",
      "text to hash"
    ],
    "howto": [
      "Type or paste the text you want to hash.",
      "Choose a hash algorithm (SHA-1, SHA-256, SHA-384, or SHA-512).",
      "The hash is calculated instantly.",
      "Copy the resulting hash."
    ],
    "faq": [
      [
        "Why isn't MD5 available?",
        "MD5 isn't provided by the browser's built-in secure hashing API that this tool uses, so it's not currently offered here."
      ],
      [
        "Can I hash a file, not just text?",
        "Not yet \u2014 this version hashes typed or pasted text only."
      ],
      [
        "Is hashing reversible?",
        "No \u2014 a hash can't be turned back into the original text; that's what makes it useful for verification."
      ]
    ],
    "note": null
  },
  {
    "id": "regex-tester",
    "name": "Regex Tester",
    "category": "developer-tools",
    "icon": "regex",
    "status": "standard",
    "short": "Test regular expressions against your own text and see matches live.",
    "description": "Write a regular expression, paste in some test text, and instantly see every match highlighted \u2014 along with capture groups \u2014 so you can build and debug patterns with confidence.",
    "keywords": [
      "regex tester",
      "regular expression tester",
      "test regex",
      "regex checker",
      "pattern matching tool"
    ],
    "howto": [
      "Type your regular expression pattern.",
      "Choose any flags you need (global, case-insensitive, multiline).",
      "Paste your test text.",
      "Matches are highlighted instantly, with details listed below."
    ],
    "faq": [
      [
        "What happens if my regex is invalid?",
        "The tool shows a clear error describing what's wrong instead of failing silently."
      ],
      [
        "Which regex flavor does this use?",
        "JavaScript's built-in regular expression engine \u2014 the same one used in most browsers and Node.js."
      ],
      [
        "Can I see capture groups?",
        "Yes \u2014 each match's capture groups are listed separately below the highlighted text."
      ]
    ],
    "note": null
  },
  {
    "id": "color-converter",
    "name": "Color Converter",
    "category": "developer-tools",
    "icon": "swatch",
    "status": "standard",
    "short": "Convert colors between HEX, RGB, and HSL formats instantly.",
    "description": "Enter a color in HEX, RGB, or HSL and instantly see it converted to the other formats, with a live preview swatch and a color picker for quick selection.",
    "keywords": [
      "color converter",
      "hex to rgb",
      "rgb to hex",
      "hsl converter",
      "color picker"
    ],
    "howto": [
      "Enter a color value in HEX, RGB, or HSL \u2014 or use the color picker.",
      "The other formats update automatically.",
      "Preview the color in the swatch.",
      "Copy whichever format you need."
    ],
    "faq": [
      [
        "Which formats are supported?",
        "HEX (#rrggbb), RGB, and HSL \u2014 the most common formats used in design and web development."
      ],
      [
        "Does it support transparency?",
        "Yes \u2014 you can include an alpha value for RGBA and HSLA output."
      ],
      [
        "Can I pick a color visually?",
        "Yes, use the built-in color picker to select a color and see it converted automatically."
      ]
    ],
    "note": null
  },
  {
    "id": "uuid-generator",
    "name": "UUID Generator",
    "category": "developer-tools",
    "icon": "fingerprint",
    "status": "standard",
    "short": "Generate random UUIDs (v4) for testing, databases, or unique IDs.",
    "description": "Create one or many version-4 UUIDs using your browser's secure random number generator \u2014 handy for database keys, test data, or anywhere you need a unique identifier.",
    "keywords": [
      "uuid generator",
      "guid generator",
      "random uuid",
      "unique id generator",
      "uuid v4"
    ],
    "howto": [
      "Choose how many UUIDs you want to generate.",
      "Click Generate.",
      "Copy a single UUID or all of them at once."
    ],
    "faq": [
      [
        "What's the difference between a UUID and a GUID?",
        "They're effectively the same thing \u2014 GUID is Microsoft's name for the same UUID standard."
      ],
      [
        "How unique are these?",
        "Version-4 UUIDs are generated from random bits; the chance of a collision is astronomically small."
      ],
      [
        "Can I generate more than one at a time?",
        "Yes \u2014 set the quantity and generate a whole batch at once, then copy them all together."
      ]
    ],
    "note": null
  },
  {
    "id": "bmi-calculator",
    "name": "BMI Calculator",
    "category": "calculator-tools",
    "icon": "activity-heart",
    "status": "standard",
    "short": "Calculate your Body Mass Index from height and weight.",
    "description": "Enter your height and weight in metric or imperial units to calculate your Body Mass Index (BMI) and see which general weight category it falls into.",
    "keywords": [
      "bmi calculator",
      "body mass index",
      "bmi chart",
      "calculate bmi",
      "weight calculator"
    ],
    "howto": [
      "Choose metric or imperial units.",
      "Enter your height and weight.",
      "Your BMI and weight category appear instantly."
    ],
    "faq": [
      [
        "Is BMI an exact measure of health?",
        "No \u2014 BMI is a general screening tool based on height and weight only; it doesn't account for muscle mass, age, or body composition. Talk to a healthcare provider for a fuller picture."
      ],
      [
        "What do the categories mean?",
        "They follow the standard World Health Organization ranges: underweight, normal, overweight, and obese."
      ],
      [
        "Does this work for children?",
        "No \u2014 this calculator uses adult BMI categories; children and teens need age- and sex-specific charts."
      ]
    ],
    "note": null
  },
  {
    "id": "loan-calculator",
    "name": "Loan Calculator",
    "category": "calculator-tools",
    "icon": "percent-coin",
    "status": "standard",
    "short": "Estimate monthly loan payments from amount, rate, and term.",
    "description": "Enter a loan amount, interest rate, and repayment term to estimate your monthly payment, total interest, and total repayment amount \u2014 useful for comparing loan or mortgage scenarios.",
    "keywords": [
      "loan calculator",
      "mortgage calculator",
      "emi calculator",
      "monthly payment calculator",
      "loan repayment"
    ],
    "howto": [
      "Enter the loan amount.",
      "Enter the annual interest rate.",
      "Enter the loan term in years.",
      "See your estimated monthly payment and total cost instantly."
    ],
    "faq": [
      [
        "Is this financial advice?",
        "No \u2014 this is a simple estimation tool based on the numbers you enter. It isn't financial advice; check with a lender for an exact quote."
      ],
      [
        "Does this include taxes, insurance, or fees?",
        "No \u2014 it calculates principal and interest only, based on a standard fixed-rate amortization formula."
      ],
      [
        "What if my interest rate is 0%?",
        "The tool handles that case too \u2014 payments are just split evenly across the term with no interest added."
      ]
    ],
    "note": null
  },
  {
    "id": "timestamp-converter",
    "name": "Unix Timestamp Converter",
    "category": "calculator-tools",
    "icon": "clock-arrows",
    "status": "standard",
    "short": "Convert between Unix timestamps and human-readable dates.",
    "description": "Convert a Unix timestamp into a readable date and time, or convert any date into its Unix timestamp \u2014 in seconds or milliseconds, in your local time zone and UTC.",
    "keywords": [
      "unix timestamp converter",
      "epoch converter",
      "timestamp to date",
      "date to timestamp",
      "unix time"
    ],
    "howto": [
      "Enter a Unix timestamp to convert it to a date, or pick a date to convert it to a timestamp.",
      "Choose seconds or milliseconds.",
      "View the result in your local time zone and in UTC."
    ],
    "faq": [
      [
        "What is a Unix timestamp?",
        "It's the number of seconds (or milliseconds) that have passed since January 1, 1970 (UTC) \u2014 a common way computers store dates."
      ],
      [
        "Does this account for time zones?",
        "Yes \u2014 results are shown in both your local time zone and UTC so you can compare."
      ],
      [
        "Can I convert the current time?",
        "Yes \u2014 there's a button to instantly fill in the current timestamp and date."
      ]
    ],
    "note": null
  },
  {
    "id": "sort-lines",
    "name": "Sort Lines",
    "category": "text-tools",
    "icon": "sort",
    "status": "standard",
    "short": "Sort a list of lines alphabetically, numerically, or in reverse.",
    "description": "Paste in a list and instantly sort it alphabetically (A\u2013Z or Z\u2013A), numerically, or by length \u2014 with options to remove blank lines and ignore case.",
    "keywords": [
      "sort lines",
      "alphabetize list",
      "sort text alphabetically",
      "line sorter",
      "sort list online"
    ],
    "howto": [
      "Paste your list, one item per line.",
      "Choose a sort order \u2014 A\u2013Z, Z\u2013A, numeric, or by length.",
      "Click Sort.",
      "Copy the sorted list."
    ],
    "faq": [
      [
        "Can it sort numbers correctly, not just alphabetically?",
        "Yes \u2014 the numeric option sorts by actual numeric value rather than treating numbers as text (so 9 comes before 10)."
      ],
      [
        "Does it remove duplicate lines too?",
        "Not by default, but you can run the result through ToolziHub's Remove Duplicate Lines tool afterward."
      ],
      [
        "Can I ignore capitalization when sorting?",
        "Yes, there's a case-insensitive option so 'Apple' and 'apple' sort together predictably."
      ]
    ],
    "note": null
  },
  {
    "id": "text-diff-checker",
    "name": "Text Diff Checker",
    "category": "text-tools",
    "icon": "diff",
    "status": "standard",
    "short": "Compare two blocks of text and see exactly what changed.",
    "description": "Paste two versions of a text and instantly see the differences highlighted line by line \u2014 additions, removals, and unchanged lines are all clearly marked.",
    "keywords": [
      "text diff checker",
      "compare text",
      "text comparison tool",
      "diff checker",
      "find differences between text"
    ],
    "howto": [
      "Paste the original text on the left.",
      "Paste the changed text on the right.",
      "Click Compare.",
      "Review the highlighted differences line by line."
    ],
    "faq": [
      [
        "Does it compare word-by-word or line-by-line?",
        "Line-by-line \u2014 each line is compared as a whole, which is clearest for documents, code, and lists."
      ],
      [
        "Can I compare large documents?",
        "Yes, though very large texts may take a moment longer to process since everything runs in your browser."
      ],
      [
        "Is my text uploaded anywhere?",
        "No \u2014 both texts are compared entirely on your device and never leave your browser."
      ]
    ],
    "note": null
  },
  {
    "id": "text-to-speech",
    "name": "Text to Speech",
    "category": "voice-tools",
    "icon": "volume",
    "status": "standard",
    "short": "Turn text into natural speech with AI voices and download the audio.",
    "description": "Paste up to 1,500 words (about 10 minutes of audio), choose one of 28 AI neural voices or a voice from your own device, and listen instantly. AI voices run inside your browser and can be saved as a WAV file \u2014 free, with no account and no API key.",
    "keywords": [
      "text to speech",
      "tts online",
      "read text aloud",
      "ai voice generator",
      "text to audio",
      "text to mp3",
      "free text to speech"
    ],
    "howto": [
      "Type or paste your text (up to 1,500 words, about 10 minutes of audio).",
      "Pick a voice engine: AI neural voices, or the voices already on your device.",
      "Press Play sample, or browse all AI voices, to hear how a voice sounds before you choose it.",
      "Press Speak to listen, then download the audio as a WAV file if you used an AI voice."
    ],
    "faq": [
      [
        "Can I hear a voice before choosing it?",
        "Yes. Press Play sample next to the voice menu, or open the voice list and press Play on any AI voice. The first AI sample loads the voice model, then every sample after that is quick."
      ],
      [
        "How much text can I convert at once?",
        "Up to 1,500 words, which comes to roughly 10 minutes of speech at a normal pace. If you paste more, ToolziHub trims it to the limit so you always get a complete, clean result."
      ],
      [
        "Is it really free, with no API key?",
        "Yes. The AI voices are open-source models that run inside your browser, so there are no accounts, credits, API keys or per-character fees."
      ],
      [
        "Why does the first AI voice take longer?",
        "The first time you use AI voices, your browser downloads a voice model of about 90 MB and keeps it for next time. After that, speech is generated on your device without sending your text anywhere."
      ],
      [
        "Can I download the audio?",
        "Yes for AI voices \u2014 you get a WAV file. Device voices play straight through your speakers and browsers don\u2019t allow them to be saved as a file."
      ],
      [
        "Which languages and voices are available?",
        "The AI engine offers 28 English voices (American and British, female and male). The device engine lists every voice installed on your phone or computer, which usually covers many more languages such as Japanese, French (Canada), Spanish, Hindi and Urdu."
      ]
    ],
    "note": null
  },
  {
    "id": "speech-to-text",
    "name": "Speech to Text",
    "category": "voice-tools",
    "icon": "mic",
    "status": "standard",
    "short": "Dictate with your microphone or transcribe an audio file into text.",
    "description": "Speak and watch your words appear live in 10 languages and accents \u2014 including English (US, UK and Canada), French (Canada) and Japanese \u2014 or upload an audio file and let an open-source AI Whisper model write the transcript in your browser.",
    "keywords": [
      "speech to text",
      "voice to text",
      "dictation online",
      "audio to text",
      "transcribe audio",
      "voice typing",
      "mp3 to text"
    ],
    "howto": [
      "Choose live microphone dictation or an audio file.",
      "Pick the language or accent you will speak.",
      "Press Start and speak, or upload your recording and press Transcribe.",
      "Edit the text if needed, then copy it or download it as a .txt file."
    ],
    "faq": [
      [
        "Which languages are supported?",
        "Ten options: English (US), English (UK), English (Canada), French (Canada), Japanese, Spanish, German, Hindi, Urdu and Arabic."
      ],
      [
        "Is my voice uploaded anywhere?",
        "It depends on the mode. Live microphone dictation uses your browser\u2019s built-in speech recognition, which in Chrome and Edge is handled by the browser maker\u2019s speech service. Audio-file transcription uses the AI Whisper model that runs entirely in your browser, so the file never leaves your device."
      ],
      [
        "Why is the first file transcription slow?",
        "The first time, your browser downloads the AI model (about 40\u2013150 MB depending on the accuracy you choose) and keeps it for next time. Longer recordings also take longer to process."
      ],
      [
        "Which browsers work for live dictation?",
        "Chrome, Edge and Safari support it. If yours doesn\u2019t, use the audio-file option, which works in any modern browser."
      ],
      [
        "How accurate is it?",
        "Clear audio and a good microphone give the best results. Pick the \u201cBetter accuracy\u201d model for noisy or accented recordings, and always proofread important text."
      ]
    ],
    "note": null
  },
  {
    "id": "split-pdf",
    "name": "Split PDF",
    "category": "pdf-tools",
    "icon": "scissors",
    "status": "standard",
    "short": "Split a PDF into single pages or custom page ranges.",
    "description": "Break one PDF into separate files \u2014 every page on its own, or the exact page ranges you choose. Everything happens in your browser, so your file is never uploaded.",
    "keywords": [
      "split pdf",
      "separate pdf pages",
      "extract pages from pdf",
      "divide pdf",
      "pdf splitter"
    ],
    "howto": [
      "Upload the PDF you want to split.",
      "Choose to split every page, or enter custom ranges such as 1-3, 4-6, 7-.",
      "Press Split PDF.",
      "Download your files \u2014 several results are bundled together in one ZIP."
    ],
    "faq": [
      [
        "Is my PDF uploaded to a server?",
        "No. The PDF is split inside your browser, so the file never leaves your device."
      ],
      [
        "How do I write page ranges?",
        "Separate ranges with commas. For example 1-3, 4-6, 7- creates three PDFs: pages 1 to 3, pages 4 to 6, and page 7 to the end."
      ],
      [
        "Can I split a password-protected PDF?",
        "Files that need a password to open can\u2019t be split here. Remove the password first, then try again."
      ]
    ],
    "note": null
  },
  {
    "id": "images-to-pdf",
    "name": "Images to PDF",
    "category": "pdf-tools",
    "icon": "image",
    "status": "standard",
    "short": "Combine JPG, PNG and other images into one PDF.",
    "description": "Turn photos and screenshots into a single PDF. Add your images, put them in the order you want, choose the page size, and download \u2014 all inside your browser.",
    "keywords": [
      "jpg to pdf",
      "image to pdf",
      "png to pdf",
      "photos to pdf",
      "combine images into pdf"
    ],
    "howto": [
      "Add your images (JPG, PNG, WebP and more).",
      "Use the arrows to put them in the right order.",
      "Pick a page size and margin.",
      "Press Create PDF to download it."
    ],
    "faq": [
      [
        "Which image types work?",
        "JPG, PNG, WebP, GIF and BMP. Other formats are converted automatically before they are added."
      ],
      [
        "Will my pictures lose quality?",
        "JPG and PNG images are placed in the PDF as they are, so there is no extra compression."
      ],
      [
        "What does \u201cFit to image\u201d mean?",
        "Each page is sized to match its picture exactly, with no empty borders. Choose A4 or Letter if you want standard paper sizes."
      ]
    ],
    "note": null
  },
  {
    "id": "pdf-to-images",
    "name": "PDF to Images",
    "category": "pdf-tools",
    "icon": "file-pdf-arrow",
    "status": "standard",
    "short": "Convert every PDF page into a PNG or JPG image.",
    "description": "Turn each page of a PDF into a sharp PNG or JPG image. Choose the quality, preview the pages, and download them one by one or all together in a ZIP.",
    "keywords": [
      "pdf to jpg",
      "pdf to png",
      "convert pdf to image",
      "pdf pages to images",
      "pdf to picture"
    ],
    "howto": [
      "Upload your PDF.",
      "Choose PNG or JPG and the image quality.",
      "Press Convert to images.",
      "Download single pages or everything as a ZIP."
    ],
    "faq": [
      [
        "How many pages can I convert?",
        "The first 100 pages are converted in one go, which keeps your browser fast."
      ],
      [
        "PNG or JPG \u2014 which should I pick?",
        "Choose PNG for sharp text and graphics, and JPG for smaller files when the pages are mostly photos."
      ],
      [
        "Is my PDF uploaded?",
        "No. The pages are drawn and saved inside your browser."
      ]
    ],
    "note": null
  },
  {
    "id": "rotate-pdf",
    "name": "Rotate PDF",
    "category": "pdf-tools",
    "icon": "rotate",
    "status": "standard",
    "short": "Rotate all or selected pages of a PDF.",
    "description": "Fix sideways or upside-down pages. Rotate every page, or just the ones you pick, by 90, 180 or 270 degrees and save the corrected PDF.",
    "keywords": [
      "rotate pdf",
      "turn pdf pages",
      "fix sideways pdf",
      "flip pdf pages",
      "pdf rotator"
    ],
    "howto": [
      "Upload your PDF.",
      "Choose how far to rotate.",
      "Leave the page box empty to rotate everything, or type pages such as 2, 4-6.",
      "Press Rotate PDF and download the result."
    ],
    "faq": [
      [
        "Can I rotate only some pages?",
        "Yes. Type the page numbers or ranges, for example 2, 4-6. Leave the box empty to rotate all pages."
      ],
      [
        "Does rotating reduce quality?",
        "No. Only the page orientation changes; the content is not re-compressed."
      ],
      [
        "Is my PDF uploaded?",
        "No. Everything happens in your browser."
      ]
    ],
    "note": null
  },
  {
    "id": "organize-pdf-pages",
    "name": "Delete, Extract & Reorder PDF Pages",
    "category": "pdf-tools",
    "icon": "layers",
    "status": "standard",
    "short": "Delete, extract or rearrange pages in a PDF.",
    "description": "Take control of your PDF pages. Keep only the pages you need, delete the ones you don\u2019t, or put pages in a new order \u2014 just type the page numbers.",
    "keywords": [
      "delete pdf pages",
      "extract pdf pages",
      "reorder pdf pages",
      "rearrange pdf",
      "remove pages from pdf"
    ],
    "howto": [
      "Upload your PDF.",
      "Choose \u201cKeep these pages\u201d or \u201cDelete these pages\u201d.",
      "Type page numbers and ranges, for example 3, 1, 2, 5-7.",
      "Press Create PDF and download the new file."
    ],
    "faq": [
      [
        "How do I change the order of pages?",
        "Choose \u201cKeep these pages\u201d and type the pages in the order you want, such as 3, 1, 2. The new PDF follows that order."
      ],
      [
        "Can I use the same page twice?",
        "Yes. In \u201cKeep these pages\u201d mode, typing a page more than once repeats it."
      ],
      [
        "Is my PDF uploaded?",
        "No. The PDF is edited inside your browser."
      ]
    ],
    "note": null
  },
  {
    "id": "pdf-watermark",
    "name": "Add Watermark to PDF",
    "category": "pdf-tools",
    "icon": "droplet",
    "status": "standard",
    "short": "Stamp text such as CONFIDENTIAL on every PDF page.",
    "description": "Add a text watermark to every page of a PDF. Choose the text, size, colour, angle and transparency, place it in the centre or repeat it across the page.",
    "keywords": [
      "watermark pdf",
      "add watermark to pdf",
      "pdf stamp",
      "confidential watermark",
      "draft watermark"
    ],
    "howto": [
      "Upload your PDF.",
      "Type the watermark text, for example CONFIDENTIAL or DRAFT.",
      "Adjust size, colour, angle and transparency.",
      "Press Add watermark and download the PDF."
    ],
    "faq": [
      [
        "Can I use any language?",
        "Watermark text supports standard Latin letters, numbers and symbols. Other scripts aren\u2019t supported yet."
      ],
      [
        "Can I make the watermark lighter?",
        "Yes \u2014 lower the transparency slider until it looks right."
      ],
      [
        "Is my PDF uploaded?",
        "No. The watermark is added inside your browser."
      ]
    ],
    "note": null
  },
  {
    "id": "background-remover",
    "name": "Background Remover",
    "category": "image-tools",
    "icon": "sparkles",
    "status": "popular",
    "short": "Remove a photo background with free in-browser AI.",
    "description": "Cut the background out of a photo with an open-source AI model that runs right in your browser. Get a transparent PNG, or swap in a plain colour \u2014 no account, no watermark.",
    "keywords": [
      "remove background",
      "background remover",
      "transparent background",
      "cut out image",
      "remove bg free"
    ],
    "howto": [
      "Upload a photo (portraits work best).",
      "Press Remove background and wait a few seconds.",
      "Pick a transparent, white, black or custom colour background.",
      "Download your PNG."
    ],
    "faq": [
      [
        "Is it free and private?",
        "Yes. The AI model runs inside your browser, so your photo is never uploaded to a server."
      ],
      [
        "Why is the first run slow?",
        "The first time, your browser downloads an AI model of about 25 MB and keeps it for next time."
      ],
      [
        "What kinds of photos work best?",
        "This model is designed for people and portraits. Objects and products can work too, but edges may be less clean."
      ]
    ],
    "note": null,
    "rank": 5
  },
  {
    "id": "image-cropper",
    "name": "Crop Image",
    "category": "image-tools",
    "icon": "crop",
    "status": "standard",
    "short": "Crop a photo to any size or ratio, free and private.",
    "description": "Drag to choose the part of the picture you want to keep, lock a ratio such as 1:1 or 16:9, and download the cropped image as PNG or JPG.",
    "keywords": [
      "crop image",
      "photo cropper",
      "crop picture online",
      "crop to square",
      "image crop 16:9"
    ],
    "howto": [
      "Upload your image.",
      "Drag on the picture to select the area to keep, and pick a ratio if you need one.",
      "Choose PNG or JPG.",
      "Press Crop & download."
    ],
    "faq": [
      [
        "Can I crop to a square or 16:9?",
        "Yes. Pick a ratio such as 1:1, 4:3 or 16:9 and your selection stays in that shape."
      ],
      [
        "Does cropping reduce quality?",
        "No. The crop is taken from your original full-resolution image."
      ],
      [
        "Is my image uploaded?",
        "No. Everything happens in your browser."
      ]
    ],
    "note": null
  },
  {
    "id": "image-rotate-flip",
    "name": "Rotate & Flip Image",
    "category": "image-tools",
    "icon": "flip",
    "status": "standard",
    "short": "Rotate or mirror a picture and save it.",
    "description": "Turn a sideways photo upright, flip it horizontally or vertically, and download the result as PNG or JPG \u2014 instantly and privately.",
    "keywords": [
      "rotate image",
      "flip image",
      "mirror image",
      "rotate photo online",
      "flip picture"
    ],
    "howto": [
      "Upload your image.",
      "Use the rotate and flip buttons until it looks right.",
      "Choose PNG or JPG.",
      "Press Download image."
    ],
    "faq": [
      [
        "Can I flip a photo to mirror it?",
        "Yes. Use Flip horizontal for a left-right mirror or Flip vertical for top-bottom."
      ],
      [
        "Does it reduce image quality?",
        "The image is saved at its full original size. JPG files are saved at high quality."
      ],
      [
        "Is my image uploaded?",
        "No. All the editing happens in your browser."
      ]
    ],
    "note": null
  },
  {
    "id": "heic-to-jpg",
    "name": "HEIC to JPG Converter",
    "category": "image-tools",
    "icon": "convert",
    "status": "standard",
    "short": "Convert iPhone HEIC photos to JPG.",
    "description": "Turn HEIC and HEIF photos from an iPhone or iPad into standard JPG files that open anywhere. Convert one photo or a whole batch and download them together.",
    "keywords": [
      "heic to jpg",
      "convert heic",
      "iphone photo converter",
      "heif to jpg",
      "heic converter free"
    ],
    "howto": [
      "Add your HEIC photos.",
      "Choose the JPG quality.",
      "Press Convert to JPG.",
      "Download each photo, or all of them as a ZIP."
    ],
    "faq": [
      [
        "Why can\u2019t I open HEIC photos on my computer?",
        "HEIC is the format iPhones use by default. Many Windows apps and websites don\u2019t support it, so converting to JPG makes the photo work everywhere."
      ],
      [
        "Can I convert many photos at once?",
        "Yes. Add as many as you like and download them together in a ZIP."
      ],
      [
        "Are my photos uploaded?",
        "No. The conversion runs inside your browser."
      ]
    ],
    "note": null
  },
  {
    "id": "passport-photo-maker",
    "name": "Passport Photo Maker",
    "category": "image-tools",
    "icon": "id-card",
    "status": "standard",
    "short": "Make passport and visa photos to the right size, then print them.",
    "description": "Crop a portrait to the official size for US, UK, Canada, Schengen, India, Pakistan, Australia or China, choose the background, and download a 300 DPI photo or a ready-to-print 4 \u00d7 6 in sheet.",
    "keywords": [
      "passport photo maker",
      "visa photo",
      "passport size photo",
      "id photo online",
      "2x2 photo",
      "passport photo print"
    ],
    "howto": [
      "Choose your country and photo size.",
      "Upload a clear, front-facing photo.",
      "Use the zoom and position sliders to line up your face with the guide.",
      "Download the single photo or the 4 \u00d7 6 in print sheet."
    ],
    "faq": [
      [
        "Will this photo be accepted?",
        "Photo rules vary and change over time, including background colour, head size and expression. Always check the official requirements for your document before printing."
      ],
      [
        "What resolution is the photo?",
        "Photos are made at 300 DPI, the usual print resolution."
      ],
      [
        "How do I print several copies?",
        "Download the 4 \u00d7 6 in print sheet, which repeats your photo as many times as fit, and print it at a photo shop or on your own printer at 100% size."
      ],
      [
        "Is my photo uploaded?",
        "No. Everything happens in your browser."
      ]
    ],
    "note": null
  },
  {
    "id": "paycheck-calculator",
    "name": "Paycheck Calculator (US, UK, Canada)",
    "category": "calculator-tools",
    "icon": "wallet",
    "status": "standard",
    "short": "Estimate your take-home pay after tax in the US, UK or Canada.",
    "description": "Enter your yearly salary to see an estimate of your take-home pay after income tax and social contributions, using 2026 rates for the US, UK (England, Wales and Northern Ireland) and Canada.",
    "keywords": [
      "paycheck calculator",
      "take home pay calculator",
      "salary after tax",
      "net pay calculator",
      "uk salary calculator",
      "canada paycheck"
    ],
    "howto": [
      "Choose your country.",
      "Enter your gross yearly salary and how often you are paid.",
      "Add any pre-tax retirement contribution and your state or provincial tax rate if you have one.",
      "Read your estimated take-home pay and the tax breakdown."
    ],
    "faq": [
      [
        "How accurate is this?",
        "It is an estimate for planning, using 2026 federal rates for the US and Canada and 2026/27 rates for the UK. Your employer\u2019s payroll may differ because of tax codes, benefits, deductions and local taxes."
      ],
      [
        "Why are state or provincial taxes not included automatically?",
        "State and provincial taxes vary a lot, so you enter your own estimated rate. Leave it at 0 to see federal tax only."
      ],
      [
        "What isn\u2019t covered?",
        "Scottish tax rates, Quebec, student loans, other benefits and credits, and filing statuses other than single or married filing jointly in the US."
      ],
      [
        "Is my salary stored anywhere?",
        "No. The calculation runs in your browser."
      ]
    ],
    "note": null
  },
  {
    "id": "mortgage-calculator",
    "name": "Mortgage Calculator",
    "category": "calculator-tools",
    "icon": "home",
    "status": "standard",
    "short": "Work out your monthly mortgage payment and total interest.",
    "description": "See your monthly mortgage payment, including property tax, insurance and fees, plus the total interest you will pay and a year-by-year breakdown of the loan.",
    "keywords": [
      "mortgage calculator",
      "monthly mortgage payment",
      "home loan calculator",
      "mortgage interest calculator",
      "amortization"
    ],
    "howto": [
      "Enter the home price, your down payment and the interest rate.",
      "Set the loan term in years.",
      "Add property tax, insurance and any monthly fees if you want the full monthly cost.",
      "Read your monthly payment and the yearly breakdown."
    ],
    "faq": [
      [
        "What does the monthly payment include?",
        "The main figure adds principal and interest to your property tax, home insurance and monthly fees. Principal and interest are also shown on their own."
      ],
      [
        "Can I use my own currency?",
        "Yes. Choose from every world currency at the top."
      ],
      [
        "Is this a loan offer?",
        "No. It is an estimate to help you plan; your lender\u2019s figures may differ."
      ]
    ],
    "note": null
  },
  {
    "id": "tip-calculator",
    "name": "Tip Calculator & Bill Splitter",
    "category": "calculator-tools",
    "icon": "coins",
    "status": "standard",
    "short": "Calculate the tip and split the bill between friends.",
    "description": "Enter the bill, pick a tip percentage and the number of people, and see the tip, the total and what each person pays \u2014 with an option to round up each share.",
    "keywords": [
      "tip calculator",
      "bill splitter",
      "split the bill",
      "restaurant tip",
      "gratuity calculator"
    ],
    "howto": [
      "Enter the bill amount.",
      "Tap a tip percentage or type your own.",
      "Enter how many people are sharing.",
      "Read the tip, the total and each person\u2019s share."
    ],
    "faq": [
      [
        "How much should I tip?",
        "Customs differ by country and venue. Many people tip 15\u201320% in the US and Canada, and 10\u201312.5% in the UK when service isn\u2019t already added."
      ],
      [
        "Can I round up the shares?",
        "Yes. Turn on the round-up option and each person\u2019s share is rounded up to a whole number."
      ],
      [
        "Can I use another currency?",
        "Yes. Pick any world currency at the top."
      ]
    ],
    "note": null
  },
  {
    "id": "gpa-calculator",
    "name": "GPA Calculator",
    "category": "calculator-tools",
    "icon": "graduation",
    "status": "standard",
    "short": "Calculate your semester and cumulative GPA.",
    "description": "Add your courses, credits and letter grades to get your GPA on the common 4.0 scale. Add your previous GPA and credits to see your cumulative GPA too.",
    "keywords": [
      "gpa calculator",
      "grade point average",
      "college gpa",
      "cumulative gpa",
      "semester gpa calculator"
    ],
    "howto": [
      "Add each course with its credits and grade.",
      "Optionally enter your current GPA and credits earned so far.",
      "Read your semester GPA and cumulative GPA instantly."
    ],
    "faq": [
      [
        "Which scale does it use?",
        "The standard US 4.0 scale: A and A+ = 4.0, A- = 3.7, B+ = 3.3, and so on down to F = 0."
      ],
      [
        "Does it work for Canada or the UK?",
        "Many Canadian schools use a 4.0 or 4.3 scale; check your school\u2019s conversion chart. UK degree classifications don\u2019t use GPA."
      ],
      [
        "How is GPA calculated?",
        "Each grade\u2019s points are multiplied by the course credits, added up, and divided by the total credits."
      ]
    ],
    "note": null
  },
  {
    "id": "compound-interest-calculator",
    "name": "Compound Interest Calculator",
    "category": "calculator-tools",
    "icon": "trending-up",
    "status": "standard",
    "short": "See how savings or investments grow with compound interest.",
    "description": "Enter a starting amount, regular monthly savings, an interest rate and a time period to see how your money can grow, with a year-by-year table of what you paid in and what you earned.",
    "keywords": [
      "compound interest calculator",
      "savings calculator",
      "investment growth",
      "interest calculator",
      "future value"
    ],
    "howto": [
      "Enter your starting amount and monthly contribution.",
      "Set the yearly interest rate and the number of years.",
      "Choose how often interest is compounded.",
      "Read your final balance and the yearly table."
    ],
    "faq": [
      [
        "What is compound interest?",
        "It is interest earned on both your original money and on the interest already added, so growth builds on itself over time."
      ],
      [
        "Are the results guaranteed?",
        "No. Real returns vary and may be lower or negative. This calculator shows what would happen at a steady rate."
      ],
      [
        "Can I use my own currency?",
        "Yes. Choose any world currency at the top."
      ]
    ],
    "note": null
  },
  {
    "id": "sales-tax-calculator",
    "name": "Sales Tax, VAT & GST Calculator",
    "category": "calculator-tools",
    "icon": "tag",
    "status": "standard",
    "short": "Add or remove sales tax, VAT or GST from any price.",
    "description": "Add tax to a price, or work backwards from a price that already includes tax. Handy for VAT in the UK and Europe, GST and HST in Canada, Australia and India, and sales tax in the US.",
    "keywords": [
      "vat calculator",
      "gst calculator",
      "sales tax calculator",
      "add vat",
      "remove vat",
      "hst calculator"
    ],
    "howto": [
      "Choose whether to add tax or remove it from a total.",
      "Enter the amount and the tax rate (or pick a common rate).",
      "Read the price before tax, the tax amount and the total."
    ],
    "faq": [
      [
        "How do I remove VAT from a price?",
        "Choose \u201cRemove tax\u201d and enter the price that includes tax. The calculator divides it by 1 plus the rate to find the price before tax."
      ],
      [
        "Are the preset rates up to date?",
        "The presets are common standard rates, but tax rates change. Always confirm the current rate for your country, state or province."
      ],
      [
        "What about US sales tax?",
        "US sales tax varies by state and city, so enter your local combined rate in the rate box."
      ]
    ],
    "note": null
  },
  {
    "id": "hourly-to-salary-calculator",
    "name": "Hourly to Salary Calculator",
    "category": "calculator-tools",
    "icon": "clock",
    "status": "standard",
    "short": "Convert an hourly wage to a yearly salary, or the other way round.",
    "description": "Turn an hourly rate into daily, weekly, monthly and yearly pay, or enter a yearly salary to find your hourly rate. Adjust your hours per week and weeks per year.",
    "keywords": [
      "hourly to salary",
      "salary to hourly",
      "hourly wage calculator",
      "annual salary calculator",
      "pay calculator"
    ],
    "howto": [
      "Choose hourly to salary, or salary to hourly.",
      "Enter the amount, your hours per week and weeks worked per year.",
      "Read your pay for every period."
    ],
    "faq": [
      [
        "How is yearly pay worked out?",
        "Hourly rate \u00d7 hours per week \u00d7 weeks per year. A full-time job of 40 hours for 52 weeks is 2,080 hours a year."
      ],
      [
        "Is this before or after tax?",
        "Before tax. For take-home pay, try the Paycheck Calculator."
      ],
      [
        "What if I take unpaid time off?",
        "Lower the weeks per year, for example 50 if you take two unpaid weeks."
      ]
    ],
    "note": null
  },
  {
    "id": "calorie-calculator",
    "name": "Calorie & TDEE Calculator",
    "category": "calculator-tools",
    "icon": "flame",
    "status": "standard",
    "short": "Estimate how many calories your body uses each day.",
    "description": "Estimate your basal metabolic rate (BMR) and total daily energy expenditure (TDEE) from your age, height, weight and activity level, using the widely used Mifflin\u2013St Jeor equation.",
    "keywords": [
      "calorie calculator",
      "tdee calculator",
      "bmr calculator",
      "daily calorie needs",
      "maintenance calories"
    ],
    "howto": [
      "Choose metric or imperial units.",
      "Enter your sex, age, height and weight.",
      "Pick your usual activity level.",
      "Read your estimated daily calories."
    ],
    "faq": [
      [
        "What are BMR and TDEE?",
        "BMR is the energy your body uses at rest. TDEE multiplies BMR by an activity factor to estimate the calories you burn in a typical day."
      ],
      [
        "How accurate is it?",
        "It is an estimate for adults. Real needs vary with muscle mass, health and lifestyle, so treat it as a starting point."
      ],
      [
        "Is this medical advice?",
        "No. For weight goals, medical conditions or if you are under 18, talk to a doctor or registered dietitian."
      ]
    ],
    "note": null
  },
  {
    "id": "remove-extra-spaces",
    "name": "Remove Extra Spaces & Line Breaks",
    "category": "text-tools",
    "icon": "eraser",
    "status": "standard",
    "short": "Clean up messy text: extra spaces, tabs and blank lines.",
    "description": "Paste your text and tidy it in one click: collapse repeated spaces, trim every line, delete empty lines or join everything into one paragraph. Results update as you type.",
    "keywords": [
      "remove extra spaces",
      "remove line breaks",
      "clean text",
      "delete blank lines",
      "text cleaner"
    ],
    "howto": [
      "Paste your text into the box.",
      "Switch on the clean-up options you need.",
      "Check the cleaned text below, which updates instantly.",
      "Copy it or download it as a .txt file."
    ],
    "faq": [
      [
        "How do I remove all line breaks?",
        "Turn on \u201cJoin lines into one paragraph\u201d. Every line break becomes a single space."
      ],
      [
        "Does it change my words?",
        "No. Only spaces, tabs and line breaks are changed."
      ],
      [
        "Is my text uploaded?",
        "No. The cleaning happens in your browser."
      ]
    ],
    "note": null
  },
  {
    "id": "markdown-to-html",
    "name": "Markdown to HTML Converter",
    "category": "developer-tools",
    "icon": "code",
    "status": "standard",
    "short": "Convert Markdown to clean HTML with a live preview.",
    "description": "Write or paste Markdown and get clean HTML straight away, with a live preview. Supports headings, bold, italics, links, images, lists, quotes and code blocks.",
    "keywords": [
      "markdown to html",
      "markdown converter",
      "md to html",
      "markdown preview",
      "convert markdown"
    ],
    "howto": [
      "Type or paste your Markdown on the left.",
      "Watch the live preview update.",
      "Copy the generated HTML, or download it as a file."
    ],
    "faq": [
      [
        "Which Markdown features are supported?",
        "Headings, bold, italic, strikethrough, inline code, code blocks, links, images, bullet and numbered lists, block quotes and horizontal rules."
      ],
      [
        "Is the HTML safe to paste into my site?",
        "Any HTML typed in the Markdown is escaped, and unsafe link types are blocked. Always review output before publishing."
      ],
      [
        "Is my text uploaded?",
        "No. The conversion runs in your browser."
      ]
    ],
    "note": null
  },
  {
    "id": "css-gradient-generator",
    "name": "CSS Gradient Generator",
    "category": "developer-tools",
    "icon": "swatch",
    "status": "standard",
    "short": "Design a CSS gradient visually and copy the code.",
    "description": "Build linear, radial and conic CSS gradients with up to six colours, adjust the angle and positions, preview the result, and copy the CSS.",
    "keywords": [
      "css gradient generator",
      "gradient maker",
      "linear gradient css",
      "background gradient",
      "radial gradient"
    ],
    "howto": [
      "Pick a gradient type.",
      "Choose your colours and drag the sliders to set where each one sits.",
      "Adjust the angle for linear and conic gradients.",
      "Copy the CSS and paste it into your stylesheet."
    ],
    "faq": [
      [
        "How many colours can I use?",
        "Up to six colour stops."
      ],
      [
        "Will the CSS work in all browsers?",
        "Yes. Linear, radial and conic gradients are supported by all modern browsers."
      ],
      [
        "Can I get a surprise?",
        "Press Randomize for a new gradient."
      ]
    ],
    "note": null
  },
  {
    "id": "jwt-decoder",
    "name": "JWT Decoder",
    "category": "developer-tools",
    "icon": "key",
    "status": "standard",
    "short": "Decode a JSON Web Token and read its header and claims.",
    "description": "Paste a JWT to see its header, payload and claims in readable form, including issued and expiry times and whether the token has expired. Decoding happens locally in your browser.",
    "keywords": [
      "jwt decoder",
      "decode jwt",
      "json web token",
      "jwt parser",
      "jwt expiry"
    ],
    "howto": [
      "Paste your JWT into the box.",
      "Read the decoded header and payload.",
      "Check the expiry status and times."
    ],
    "faq": [
      [
        "Does this verify the signature?",
        "No. It only decodes the token so you can read it. Verifying a signature needs the secret or public key."
      ],
      [
        "Is my token sent anywhere?",
        "No. It is decoded entirely in your browser. Even so, avoid pasting live production tokens into any website you don\u2019t fully trust."
      ],
      [
        "What does \u201cexp\u201d mean?",
        "It is the time the token expires, shown here as a readable date."
      ]
    ],
    "note": null
  },
  {
    "id": "barcode-generator",
    "name": "Barcode Generator",
    "category": "generator-tools",
    "icon": "barcode",
    "status": "standard",
    "short": "Create Code 128, EAN, UPC and other barcodes as PNG or SVG.",
    "description": "Generate scannable barcodes in popular formats \u2014 Code 128, EAN-13, EAN-8, UPC-A, Code 39 and ITF-14. Adjust the size, then download as PNG or SVG.",
    "keywords": [
      "barcode generator",
      "create barcode",
      "ean 13 generator",
      "upc barcode",
      "code 128 generator"
    ],
    "howto": [
      "Choose a barcode format.",
      "Type the number or text to encode.",
      "Adjust the bar width and height if you like.",
      "Download the barcode as PNG or SVG."
    ],
    "faq": [
      [
        "Which format should I use?",
        "Code 128 works for any text. Use EAN-13 or UPC-A for retail products, and ITF-14 for shipping cartons."
      ],
      [
        "Why does it say my value is invalid?",
        "Some formats only accept certain characters or lengths. The hint under the format menu tells you what is allowed."
      ],
      [
        "Are check digits added automatically?",
        "Yes, for EAN, UPC and ITF-14 the last digit is calculated for you."
      ]
    ],
    "note": null
  },
  {
    "id": "resume-builder",
    "name": "Resume Builder",
    "category": "career-tools",
    "icon": "briefcase",
    "status": "standard",
    "short": "Build a clean, ATS-friendly resume and download it as a PDF.",
    "description": "Fill in your details, see your resume update live, choose a classic or modern layout, and download a clean text-based PDF that applicant tracking systems can read.",
    "keywords": [
      "resume builder",
      "cv maker",
      "free resume",
      "ats resume",
      "create resume pdf",
      "cv builder"
    ],
    "howto": [
      "Add your contact details and a short summary.",
      "Add your work experience, education and skills.",
      "Pick a template, colour and text size.",
      "Press Download PDF."
    ],
    "faq": [
      [
        "Is the resume ATS-friendly?",
        "Yes. The PDF uses real, selectable text in a simple single-column layout, which applicant tracking systems read well."
      ],
      [
        "Is my information stored or uploaded?",
        "No. Your resume is built in your browser and nothing is saved on our servers."
      ],
      [
        "Can I use non-English letters?",
        "The PDF uses a standard font that supports Latin letters and common symbols. Other scripts aren\u2019t supported yet."
      ],
      [
        "Can I try it with sample data?",
        "Yes. Press \u201cFill with an example\u201d to see how a finished resume looks."
      ]
    ],
    "note": null
  },
  {
    "id": "temp-mail",
    "name": "Temp Mail (Disposable Email)",
    "category": "email-tools",
    "icon": "mail",
    "status": "popular",
    "short": "Get a free temporary email address and read incoming mail instantly.",
    "description": "Create a disposable email address in one click, use it to sign up or receive a verification email, and read the inbox right here. New mail appears automatically, and verification codes and links are picked out for you.",
    "keywords": [
      "temp mail",
      "temporary email",
      "disposable email",
      "fake email address",
      "10 minute mail",
      "throwaway email"
    ],
    "howto": [
      "Choose a domain and a name (or press Create address for a random one).",
      "Copy your new address and use it on the website or form.",
      "Wait a few seconds \u2014 incoming emails appear in the inbox automatically.",
      "Open a message to read it, and copy the verification code or link with one click."
    ],
    "faq": [
      [
        "Is it free?",
        "Yes. There is no sign-up and no cost."
      ],
      [
        "Will every website accept it?",
        "Not always. Some websites block well-known disposable email domains. If one is refused, create a new address on a different domain from the list."
      ],
      [
        "Can I get an address that ends in .edu?",
        "No. Addresses ending in .edu belong to schools and universities and can only be issued by them. Domains in this tool are public mail domains such as .com, .net or .org, and which ones are available depends on the mail service."
      ],
      [
        "Is my inbox private?",
        "Anyone who knows the address can read its mail, so never use it for banking, work or accounts you want to keep. Inboxes are temporary and can be deleted by the mail service at any time."
      ],
      [
        "What is the \u201csmart\u201d part?",
        "When you open an email, ToolziHub looks for one-time codes and verification links and puts them at the top so you can copy them quickly."
      ]
    ],
    "note": null,
    "rank": 3
  },
  {
    "id": "screen-recorder",
    "name": "Screen Recorder",
    "category": "media-tools",
    "icon": "film",
    "status": "new",
    "short": "Record your screen with sound, free and without installing anything.",
    "description": "Record your whole screen, a window or a browser tab, with optional system sound and microphone. Pause and resume, then preview and download the video. It all stays on your device.",
    "keywords": [
      "screen recorder",
      "record screen online",
      "screen capture video",
      "free screen recorder",
      "record my screen"
    ],
    "howto": [
      "Choose your quality and whether to record sound.",
      "Press Start recording and pick the screen, window or tab to share.",
      "Use Pause or Stop when you are done.",
      "Preview the video and download it."
    ],
    "faq": [
      [
        "Does it work on phones?",
        "Screen recording from the browser works on computers (Chrome, Edge, Firefox). Most phone browsers don\u2019t allow it."
      ],
      [
        "How do I record the computer\u2019s sound?",
        "Turn on \u201cRecord system sound\u201d and, in the sharing window, tick the option to share audio (it is available when sharing a tab or, on some systems, the whole screen)."
      ],
      [
        "Is my recording uploaded?",
        "No. The video is created inside your browser and never leaves your device."
      ],
      [
        "What format is the video?",
        "WebM in most browsers (MP4 where the browser supports it). WebM plays in Chrome, Firefox, VLC and most video apps."
      ]
    ],
    "note": null
  },
  {
    "id": "compress-image-to-kb",
    "name": "Compress Image to KB",
    "category": "image-tools",
    "icon": "shrink",
    "status": "new",
    "short": "Shrink a photo to an exact size such as 50 KB, 100 KB or 200 KB.",
    "description": "Need a picture under 100 KB for a form or job application? Enter the size you need and ToolziHub finds the best quality that fits, shrinking the dimensions only if it has to.",
    "keywords": [
      "compress image to 100kb",
      "reduce image size to 50kb",
      "image under 200kb",
      "resize photo to kb",
      "compress jpg to kb"
    ],
    "howto": [
      "Upload your image.",
      "Type the largest size you can use, in KB.",
      "Press Compress to size.",
      "Check the result and download it."
    ],
    "faq": [
      [
        "How does it reach an exact size?",
        "It tries different quality levels to find the highest one that fits your limit. If that isn\u2019t enough, it makes the picture slightly smaller and tries again."
      ],
      [
        "JPG or WebP?",
        "JPG works everywhere and is what most forms expect. WebP is smaller at the same quality but not accepted everywhere."
      ],
      [
        "Is my image uploaded?",
        "No. It is compressed in your browser."
      ]
    ],
    "note": null
  },
  {
    "id": "currency-converter",
    "name": "Currency Converter",
    "category": "calculator-tools",
    "icon": "coins",
    "status": "new",
    "short": "Convert between world currencies using live exchange rates.",
    "description": "Convert money between about 150 currencies using up-to-date daily exchange rates. Swap currencies in one tap and see the rate both ways.",
    "keywords": [
      "currency converter",
      "exchange rate",
      "usd to pkr",
      "convert currency",
      "forex calculator",
      "money converter"
    ],
    "howto": [
      "Enter the amount.",
      "Choose the currency you have and the one you want.",
      "Read the converted amount and the exchange rate.",
      "Press the swap button to reverse the conversion."
    ],
    "faq": [
      [
        "Where do the rates come from?",
        "From a free public exchange-rate service that updates daily. Rates are indicative; banks and card providers add their own margin."
      ],
      [
        "How many currencies are supported?",
        "Around 150 world currencies."
      ],
      [
        "Do I need to be online?",
        "Yes, live rates are fetched when you use the tool."
      ]
    ],
    "note": null
  },
  {
    "id": "email-address-checker",
    "name": "Email Address Checker",
    "category": "email-tools",
    "icon": "shield",
    "status": "new",
    "short": "Check email addresses for mistakes, typos and temporary-mail domains.",
    "description": "Paste one or many email addresses to check their format, spot common typos like gmial.com, flag disposable and role-based addresses, and confirm that the domain can actually receive mail.",
    "keywords": [
      "email checker",
      "email validator",
      "verify email address",
      "check email format",
      "email syntax check",
      "mx lookup"
    ],
    "howto": [
      "Paste your email addresses, one per line (up to 50).",
      "Choose whether to also look up the domain\u2019s mail server.",
      "Press Check emails.",
      "Read the result and notes for each address."
    ],
    "faq": [
      [
        "Can it tell me if a mailbox really exists?",
        "No. Only the mail provider knows that. This tool checks the format, common typos, disposable domains and whether the domain is set up to receive mail."
      ],
      [
        "How does the mail server check work?",
        "It asks a public DNS service for the domain\u2019s MX records, which say where its mail is delivered. Only the domain name is sent \u2014 never the full address."
      ],
      [
        "What is a role-based address?",
        "Addresses such as info@, support@ or admin@ that go to a team instead of one person."
      ]
    ],
    "note": null
  },
  {
    "id": "email-extractor",
    "name": "Email Extractor",
    "category": "email-tools",
    "icon": "eraser",
    "status": "new",
    "short": "Pull every email address out of any text or document.",
    "description": "Paste text, a web page source or a messy list and instantly collect all the email addresses in it. Remove duplicates, sort them, and copy or download the list.",
    "keywords": [
      "email extractor",
      "extract emails from text",
      "email finder",
      "email list",
      "collect email addresses"
    ],
    "howto": [
      "Paste your text into the box.",
      "Choose whether to lowercase, remove duplicates and sort.",
      "Copy the list, copy it as comma-separated, or download a CSV."
    ],
    "faq": [
      [
        "Does it work on large text?",
        "Yes. Everything runs in your browser, so even long text is processed instantly."
      ],
      [
        "Is my text uploaded?",
        "No. Nothing leaves your device."
      ],
      [
        "Please use it responsibly",
        "Only collect and use email addresses in ways that respect privacy and anti-spam laws."
      ]
    ],
    "note": null
  },
  {
    "id": "email-signature-generator",
    "name": "Email Signature Generator",
    "category": "email-tools",
    "icon": "quote",
    "status": "new",
    "short": "Design a professional email signature and copy it into Gmail or Outlook.",
    "description": "Fill in your details, pick a style and colour, and get a clean email signature that works in Gmail, Outlook and Apple Mail. Copy it with formatting, or copy the HTML code.",
    "keywords": [
      "email signature generator",
      "email signature maker",
      "gmail signature",
      "outlook signature",
      "html email signature"
    ],
    "howto": [
      "Enter your name, job title, contact details and an optional photo link.",
      "Pick a style and accent colour.",
      "Press Copy signature.",
      "Paste it into your email app\u2019s signature settings."
    ],
    "faq": [
      [
        "How do I use it in Gmail?",
        "Press Copy signature, open Gmail Settings, find Signature, and paste. Save your changes."
      ],
      [
        "Can I add a photo or logo?",
        "Yes, paste a link to an image that is already online (a web address starting with https). Images are not uploaded by ToolziHub."
      ],
      [
        "Why a table layout?",
        "Email apps are fussy about styling, so the signature uses a simple table with inline styles, which looks the same almost everywhere."
      ]
    ],
    "note": null
  },
  {
    "id": "email-header-analyzer",
    "name": "Email Header Analyzer",
    "category": "email-tools",
    "icon": "search",
    "status": "new",
    "short": "Read raw email headers: sender checks, route and delays.",
    "description": "Paste the raw headers of an email to see who really sent it, whether SPF, DKIM and DMARC passed, and the route the message took with the time spent at every hop.",
    "keywords": [
      "email header analyzer",
      "email header checker",
      "trace email",
      "spf dkim dmarc check",
      "read email headers"
    ],
    "howto": [
      "Open the email and choose \u201cShow original\u201d, \u201cView source\u201d or \u201cView message headers\u201d.",
      "Copy the header text and paste it into the box.",
      "Read the SPF, DKIM and DMARC results and the hop-by-hop journey."
    ],
    "faq": [
      [
        "Where do I find the headers?",
        "In Gmail open the message, press the three dots and choose \u201cShow original\u201d. In Outlook, open the message properties or choose \u201cView message source\u201d."
      ],
      [
        "What do SPF, DKIM and DMARC mean?",
        "They are checks that help show an email really came from the domain it claims. \u201cPass\u201d is good; \u201cfail\u201d can mean the message was forged."
      ],
      [
        "Is my email uploaded?",
        "No. The headers are read inside your browser."
      ]
    ],
    "note": null
  },
  {
    "id": "mailto-link-generator",
    "name": "Mailto Link Generator",
    "category": "email-tools",
    "icon": "link",
    "status": "new",
    "short": "Create a clickable email link with subject and message pre-filled.",
    "description": "Build a mailto link that opens your visitor\u2019s email app with the recipient, subject and message already filled in. Copy the link or ready-made HTML.",
    "keywords": [
      "mailto link generator",
      "mailto generator",
      "email link html",
      "create mailto",
      "email link with subject"
    ],
    "howto": [
      "Enter the recipient and, if you like, cc, bcc, subject and message.",
      "Type the text for the link.",
      "Copy the link or the HTML.",
      "Press Test link to try it."
    ],
    "faq": [
      [
        "Does it work with every email app?",
        "A mailto link opens the visitor\u2019s default email app, so it works on any device that has one set up."
      ],
      [
        "Can I add several recipients?",
        "Yes, separate addresses with commas."
      ],
      [
        "Why are some characters changed?",
        "Spaces and special characters are encoded, as the mailto format requires."
      ]
    ],
    "note": null
  },
  {
    "id": "voice-recorder",
    "name": "Voice Recorder",
    "category": "media-tools",
    "icon": "mic",
    "status": "new",
    "short": "Record audio from your microphone and download it.",
    "description": "Record your voice with a live level meter, pause and resume, play it back and download the recording. Save the original file or convert it to WAV.",
    "keywords": [
      "voice recorder",
      "audio recorder online",
      "record voice",
      "microphone test",
      "online mic recorder"
    ],
    "howto": [
      "Allow microphone access when your browser asks.",
      "Press Start recording and speak.",
      "Pause or stop when you are done.",
      "Play it back and download the audio."
    ],
    "faq": [
      [
        "Is my recording uploaded?",
        "No. It is recorded and stored only in your browser until you download it."
      ],
      [
        "Why does the level meter matter?",
        "It shows whether your microphone is picking up sound, so you can check it before you record."
      ],
      [
        "What formats can I download?",
        "The original recording (WebM, OGG or M4A, depending on your browser) and a WAV file that works almost everywhere."
      ]
    ],
    "note": null
  },
  {
    "id": "video-to-mp3",
    "name": "Video to MP3 Converter",
    "category": "media-tools",
    "icon": "volume",
    "status": "new",
    "short": "Extract the audio from a video file and save it as MP3 or WAV.",
    "description": "Turn a video you already have into an audio file. Choose MP3 or WAV, pick the quality, and download \u2014 the conversion happens in your browser, so your file stays private.",
    "keywords": [
      "video to mp3",
      "extract audio from video",
      "mp4 to mp3",
      "convert video to audio",
      "audio extractor"
    ],
    "howto": [
      "Choose a video or audio file from your device.",
      "Pick MP3 or WAV, and the quality for MP3.",
      "Press Convert.",
      "Your audio file downloads automatically."
    ],
    "faq": [
      [
        "What files can I use?",
        "MP4, WebM, MOV (where your browser supports it), MP3, WAV, M4A and OGG. Support depends on your browser."
      ],
      [
        "Is there a size limit?",
        "Files up to about 400 MB work best, because the audio is processed in your browser\u2019s memory."
      ],
      [
        "Is my file uploaded?",
        "No. The conversion happens on your device."
      ],
      [
        "Is this a downloader?",
        "No. It converts a file you already have. Only use it with videos you own or have permission to use."
      ]
    ],
    "note": null
  },
  {
    "id": "audio-trimmer",
    "name": "Audio Cutter & Trimmer",
    "category": "media-tools",
    "icon": "scissors",
    "status": "new",
    "short": "Cut a section out of an audio file and save it as MP3 or WAV.",
    "description": "Load a song, voice note or recording, drag the start and end to choose the part you want, preview it, and download the cut as MP3 or WAV with an optional fade.",
    "keywords": [
      "audio cutter",
      "mp3 cutter",
      "audio trimmer",
      "cut audio online",
      "trim audio",
      "ringtone maker"
    ],
    "howto": [
      "Upload an audio file.",
      "Move the start and end sliders to choose the part you want to keep.",
      "Press Preview to listen.",
      "Choose MP3 or WAV and press Download."
    ],
    "faq": [
      [
        "Which files can I trim?",
        "MP3, WAV, M4A, OGG and other audio formats your browser can play."
      ],
      [
        "Can I make a ringtone?",
        "Yes. Cut the 20\u201330 seconds you like and download it as MP3."
      ],
      [
        "Is my audio uploaded?",
        "No. Everything happens in your browser."
      ]
    ],
    "note": null
  },
  {
    "id": "favicon-generator",
    "name": "Favicon Generator",
    "category": "image-tools",
    "icon": "star",
    "status": "new",
    "short": "Turn any picture into a full favicon set with .ico, PNG and Apple icons.",
    "description": "Upload a logo or picture and get every favicon size a website needs: favicon.ico, PNG icons from 16 to 512 pixels, the Apple touch icon, a web manifest and the HTML to paste into your site.",
    "keywords": [
      "favicon generator",
      "favicon.ico maker",
      "create favicon",
      "website icon generator",
      "apple touch icon"
    ],
    "howto": [
      "Upload a square logo or picture.",
      "Choose a background (or keep it transparent).",
      "Press Generate favicons.",
      "Download the ZIP and paste the HTML into your site\u2019s head."
    ],
    "faq": [
      [
        "What image should I upload?",
        "A square picture at least 512 \u00d7 512 pixels gives the best results. Non-square pictures are cropped to the centre."
      ],
      [
        "What is in the ZIP?",
        "favicon.ico, PNG icons (16, 32, 48, 64, 180, 192 and 512 px), apple-touch-icon.png and a site.webmanifest file."
      ],
      [
        "Is my image uploaded?",
        "No. The icons are created in your browser."
      ]
    ],
    "note": null
  },
  {
    "id": "image-color-picker",
    "name": "Image Color Picker",
    "category": "image-tools",
    "icon": "swatch",
    "status": "new",
    "short": "Pick exact colours from any image and get a colour palette.",
    "description": "Upload a picture, move over it to see the colour under your pointer, click to save it, and copy the HEX, RGB or HSL code. A palette of the main colours is created automatically.",
    "keywords": [
      "image color picker",
      "color picker from image",
      "get hex from image",
      "extract colors from image",
      "color palette from photo"
    ],
    "howto": [
      "Upload an image.",
      "Move your pointer (or finger) over it to preview colours.",
      "Click to save a colour, then copy its HEX, RGB or HSL.",
      "Use the palette to grab the main colours quickly."
    ],
    "faq": [
      [
        "What colour formats are shown?",
        "HEX (like #0EA5EC), RGB and HSL \u2014 click any box to copy."
      ],
      [
        "How is the palette made?",
        "The most common colours in the picture are grouped and the six most distinct ones are shown."
      ],
      [
        "Is my image uploaded?",
        "No. It stays in your browser."
      ]
    ],
    "note": null
  },
  {
    "id": "discount-calculator",
    "name": "Discount Calculator",
    "category": "calculator-tools",
    "icon": "percent",
    "status": "new",
    "short": "Work out the sale price, the savings or the original price.",
    "description": "Find out what you will pay after a discount (or two), how much you save, what the original price was, or what percentage off a deal really is. Optionally add tax.",
    "keywords": [
      "discount calculator",
      "sale price calculator",
      "percent off calculator",
      "calculate discount",
      "original price calculator"
    ],
    "howto": [
      "Choose what you want to find.",
      "Enter the prices and discount percentages.",
      "Optionally add sales tax or VAT.",
      "Read what you pay and what you save."
    ],
    "faq": [
      [
        "How are two discounts combined?",
        "They are applied one after the other, so 20% off and then a further 10% off is 28% off in total, not 30%."
      ],
      [
        "Can I find the original price?",
        "Yes. Choose \u201cFind the original price\u201d and enter the price you paid and the discount."
      ],
      [
        "Is tax included?",
        "Only if you enter a tax rate; it is added to the final price."
      ]
    ],
    "note": null
  },
  {
    "id": "timer-stopwatch",
    "name": "Online Timer, Stopwatch & Pomodoro",
    "category": "calculator-tools",
    "icon": "clock",
    "status": "new",
    "short": "A countdown timer, stopwatch and Pomodoro timer with an alarm.",
    "description": "Set a countdown with an alarm, time something with a stopwatch and laps, or stay focused with a Pomodoro timer that switches between work and break sessions.",
    "keywords": [
      "online timer",
      "countdown timer",
      "stopwatch online",
      "pomodoro timer",
      "timer with alarm"
    ],
    "howto": [
      "Choose Timer, Stopwatch or Pomodoro.",
      "Set the time (or use a preset) and press Start.",
      "Pause, resume or reset any time.",
      "An alarm sounds when the time is up."
    ],
    "faq": [
      [
        "Will the alarm sound if I switch tabs?",
        "Yes, as long as the page stays open. The remaining time also shows in the browser tab title."
      ],
      [
        "What is the Pomodoro technique?",
        "Work for 25 minutes, take a 5-minute break, and after four rounds take a longer break. You can change all the lengths."
      ],
      [
        "Is the stopwatch accurate?",
        "Yes. It measures real elapsed time, so it stays accurate even if the page is busy."
      ]
    ],
    "note": null
  },
  {
    "id": "random-picker",
    "name": "Random Number, Dice & Name Picker",
    "category": "generator-tools",
    "icon": "sparkles",
    "status": "new",
    "short": "Pick random numbers, roll dice, flip a coin or choose a winner from a list.",
    "description": "Generate random numbers in any range, roll one or many dice, flip a coin, or draw winners from a list of names. Uses your device\u2019s secure random generator, so every pick is fair.",
    "keywords": [
      "random number generator",
      "dice roller",
      "coin flip",
      "random name picker",
      "raffle winner picker",
      "pick a random name"
    ],
    "howto": [
      "Choose what you want: numbers, dice, coin or a list.",
      "Set the options (range, number of dice, or paste your names).",
      "Press the button and watch the result.",
      "Copy the result if you need it."
    ],
    "faq": [
      [
        "Is it really random?",
        "It uses your browser\u2019s cryptographic random generator, which is much stronger than a simple random function, and avoids bias when picking from a range."
      ],
      [
        "Can I pick several winners?",
        "Yes. In the list mode, set how many winners to draw; each name can be picked only once."
      ],
      [
        "Can I get numbers without repeats?",
        "Yes. Turn on \u201cUnique numbers only\u201d."
      ]
    ],
    "note": null
  }
];
