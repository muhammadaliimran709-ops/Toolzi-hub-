// Category data — single source of truth read by search.js and main.js.
var TZ_CATEGORIES = [
  {
    "id": "pdf-tools",
    "name": "PDF Tools",
    "icon": "file-text",
    "color": "blue",
    "short": "Merge, split, compress, convert and edit PDF files without installing anything.",
    "description": "Everything you need to work with PDF files, done locally in your browser. Merge, split, rotate, watermark and reorder pages, compress a file before you email it, turn pages into images or images into a PDF, pull the text out of a document, or move content between PDF and Word."
  },
  {
    "id": "image-tools",
    "name": "Image Tools",
    "icon": "image",
    "color": "green",
    "short": "Resize, crop, compress, convert and clean up images, or read text from them.",
    "description": "Prepare images for the web, a form, or an email attachment. Resize, crop, rotate and flip, shrink file size, convert between JPG, PNG, WebP and iPhone HEIC, remove a photo background, make passport photos, or pull text out of a scan with on-device OCR. You can also shrink a photo to an exact size in KB, create a favicon set, or pick colours from a picture."
  },
  {
    "id": "text-tools",
    "name": "Text Tools",
    "icon": "type",
    "color": "purple",
    "short": "Count, clean, and reformat text for writing and editing tasks.",
    "description": "Small utilities for anyone who works with text: get an accurate word and character count, switch between capitalization styles, clear duplicate lines, sort lines, compare two texts, or tidy extra spaces and line breaks."
  },
  {
    "id": "developer-tools",
    "name": "Developer Tools",
    "icon": "code",
    "color": "navy",
    "short": "Format, validate, decode and clean up code and web data.",
    "description": "Everyday utilities for building and debugging software: format and validate JSON, encode or decode URLs and Base64, hash text and test regular expressions, convert colours and timestamps, decode JWTs, convert Markdown to HTML, build CSS gradients, and shrink HTML, CSS or JavaScript before it ships."
  },
  {
    "id": "calculator-tools",
    "name": "Calculator Tools",
    "icon": "calculator",
    "color": "teal",
    "short": "Quick calculators for pay, loans, savings, health and everyday numbers.",
    "description": "Fast answers for the numbers people look up all the time: percentages, exact age, the time between two dates, unit conversions, BMI and daily calories, mortgages and loans, savings growth, tips, GPA, sales tax take-home pay, currency conversion, discounts and timers."
  },
  {
    "id": "generator-tools",
    "name": "Generator Tools",
    "icon": "receipt",
    "color": "amber",
    "short": "Create passwords, QR codes, barcodes, invoices and more in moments.",
    "description": "Tools that create something new from a few inputs: strong passwords, QR codes and barcodes, UUIDs, placeholder text, and professional invoices in any currency. Need a fair pick? Roll dice, flip a coin or draw a winner at random."
  },
  {
    "id": "voice-tools",
    "name": "Voice Tools",
    "icon": "volume",
    "color": "rose",
    "short": "Turn text into natural speech and speech into text, right in your browser.",
    "description": "Give your words a voice or write down what you hear. Listen to your text read aloud by AI neural voices and download the audio, or dictate and transcribe speech in English, Japanese, Canadian French and more \u2014 free, with no account and no API key."
  },
  {
    "id": "career-tools",
    "name": "Career Tools",
    "icon": "briefcase",
    "color": "indigo",
    "short": "Build a polished resume and get ready for your next job.",
    "description": "Tools for your working life. Create an ATS-friendly resume with a live preview and download it as a PDF \u2014 free, with nothing stored on our servers. More career tools are planned as ToolziHub grows."
  },
  {
    "id": "email-tools",
    "name": "Email Tools",
    "icon": "mail",
    "color": "cyan",
    "short": "Temporary inboxes, email checks, signatures and header tools.",
    "description": "Everything for email in one place. Get a free temporary email address and read incoming mail, check whether addresses are valid, extract emails from text, design an email signature, build mailto links, and analyse raw email headers."
  },
  {
    "id": "media-tools",
    "name": "Media Tools",
    "icon": "film",
    "color": "orange",
    "short": "Record your screen or voice and work with audio, in your browser.",
    "description": "Record your screen or microphone, pull the audio out of a video, and cut audio into just the part you need. Everything runs on your device, so your recordings stay private."
  }
];
