/* =========================================================
   TOOLZIHUB \u2014 main.js
   Shared site behavior: navigation, dynamic section rendering,
   FAQ accordions, and small utilities reused by every tool.
   Depends on: icons.js, categories-data.js, tools-data.js
   ========================================================= */

(function () {
  "use strict";

  document.addEventListener("DOMContentLoaded", function () {
    initMobileNav();
    initNavDropdown();
    initFaqAccordions();
    setFooterYear();
    renderDynamicSections();
    initScrollReveal();
  });

  /* ---------------------------- utilities ---------------------------- */

  function escapeHtml(str) {
    return String(str)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function formatBytes(bytes) {
    if (bytes === 0 || !isFinite(bytes)) return "0 KB";
    const units = ["B", "KB", "MB", "GB"];
    let i = 0;
    let val = bytes;
    while (val >= 1024 && i < units.length - 1) {
      val /= 1024;
      i++;
    }
    const decimals = val < 10 && i > 0 ? 1 : 0;
    return val.toFixed(decimals) + " " + units[i];
  }

  function debounce(fn, wait) {
    let t;
    return function () {
      clearTimeout(t);
      const args = arguments;
      const ctx = this;
      t = setTimeout(function () {
        fn.apply(ctx, args);
      }, wait);
    };
  }

  function downloadBlob(blob, filename) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(function () {
      URL.revokeObjectURL(url);
    }, 2000);
  }

  function downloadText(text, filename, mime) {
    downloadBlob(new Blob([text], { type: mime || "text/plain" }), filename);
  }

  function showToast(message, opts) {
    let toast = document.getElementById("tz-toast");
    if (!toast) {
      // Some tool pages ship without a toast element — create one so feedback always shows.
      toast = document.createElement("div");
      toast.className = "toast";
      toast.id = "tz-toast";
      toast.setAttribute("role", "status");
      toast.setAttribute("aria-live", "polite");
      toast.innerHTML = '<span id="tz-toast-text"></span>';
      document.body.appendChild(toast);
    }
    const textEl = document.getElementById("tz-toast-text");
    if (textEl) textEl.textContent = message;
    toast.classList.add("show");
    clearTimeout(toast._hideTimer);
    toast._hideTimer = setTimeout(function () {
      toast.classList.remove("show");
    }, (opts && opts.duration) || 2400);
  }

  function copyToClipboard(text, successMessage) {
    const done = function (ok) {
      showToast(ok ? successMessage || "Copied to clipboard" : "Couldn\u2019t copy \u2014 try selecting manually");
    };
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(text).then(function () {
        done(true);
      }, function () {
        done(false);
      });
    } else {
      try {
        const ta = document.createElement("textarea");
        ta.value = text;
        ta.style.position = "fixed";
        ta.style.opacity = "0";
        document.body.appendChild(ta);
        ta.focus();
        ta.select();
        document.execCommand("copy");
        ta.remove();
        done(true);
      } catch (e) {
        done(false);
      }
    }
  }

  window.TZ = window.TZ || {};
  Object.assign(window.TZ, {
    escapeHtml: escapeHtml,
    formatBytes: formatBytes,
    debounce: debounce,
    downloadBlob: downloadBlob,
    downloadText: downloadText,
    showToast: showToast,
    copyToClipboard: copyToClipboard,
  });

  // Shared coordinator so only one header/nav menu is ever open at a time —
  // used by the mobile nav drawer, the desktop Categories dropdown, and the
  // header search panel (see search.js).
  TZ._activeMenuClose = null;
  TZ.openMenu = function (closeFn) {
    if (TZ._activeMenuClose && TZ._activeMenuClose !== closeFn) TZ._activeMenuClose();
    TZ._activeMenuClose = closeFn;
  };
  TZ.menuClosed = function (closeFn) {
    if (TZ._activeMenuClose === closeFn) TZ._activeMenuClose = null;
  };

  /* ---------------------------- nav: mobile drawer ---------------------------- */

  function initMobileNav() {
    const toggle = document.querySelector(".menu-toggle");
    const nav = document.getElementById("tz-mobile-nav");
    if (!toggle || !nav) return;
    const closeEls = nav.querySelectorAll("[data-close-nav]");
    const catBtn = document.getElementById("tz-mnav-cat-btn");
    const catPanel = document.getElementById("tz-mnav-cat-panel");
    const open = function () {
      TZ.openMenu(close);
      nav.classList.add("open");
      toggle.setAttribute("aria-expanded", "true");
      document.body.style.overflow = "hidden";
      if (catBtn && catPanel) {
        catBtn.setAttribute("aria-expanded", "false");
        catPanel.classList.remove("open");
      }
    };
    const close = function () {
      TZ.menuClosed(close);
      nav.classList.remove("open");
      toggle.setAttribute("aria-expanded", "false");
      document.body.style.overflow = "";
    };
    toggle.addEventListener("click", function () {
      nav.classList.contains("open") ? close() : open();
    });
    closeEls.forEach(function (el) {
      el.addEventListener("click", close);
    });
    if (catBtn && catPanel) {
      catBtn.addEventListener("click", function () {
        const willOpen = !catPanel.classList.contains("open");
        catPanel.classList.toggle("open", willOpen);
        catBtn.setAttribute("aria-expanded", willOpen ? "true" : "false");
      });
    }
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape") close();
    });
  }

  /* ---------------------------- nav: categories dropdown (desktop) ---------------------------- */

  function initNavDropdown() {
    const dd = document.querySelector(".nav-dropdown");
    if (!dd) return;
    const btn = dd.querySelector(".nav-dropdown-btn");
    const close = function () {
      TZ.menuClosed(close);
      dd.classList.remove("open");
      btn.setAttribute("aria-expanded", "false");
    };
    btn.addEventListener("click", function (e) {
      e.stopPropagation();
      const willOpen = !dd.classList.contains("open");
      if (willOpen) TZ.openMenu(close);
      dd.classList.toggle("open", willOpen);
      btn.setAttribute("aria-expanded", String(willOpen));
    });
    document.addEventListener("click", function (e) {
      if (!dd.contains(e.target)) close();
    });
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape") close();
    });
  }

  /* ---------------------------- FAQ accordions ---------------------------- */

  function initFaqAccordions() {
    document.querySelectorAll(".faq-item").forEach(function (item) {
      const q = item.querySelector(".faq-q");
      if (!q) return;
      q.addEventListener("click", function () {
        const wasOpen = item.classList.contains("open");
        item.closest(".faq-list")
          .querySelectorAll(".faq-item.open")
          .forEach(function (openItem) {
            openItem.classList.remove("open");
          });
        if (!wasOpen) item.classList.add("open");
      });
    });
  }

  function setFooterYear() {
    const el = document.getElementById("tz-year");
    if (el) el.textContent = new Date().getFullYear();
  }

  /* ---------------------------- icon color helper ---------------------------- */

  function iconClass(color) {
    return "ic-" + (color || "blue");
  }

  /* ---------------------------- card renderers ---------------------------- */

  function badgeHtml(status) {
    if (status === "popular") return '<span class="tool-badge popular">POPULAR</span>';
    if (status === "new") return '<span class="tool-badge new">NEW</span>';
    return "";
  }

  function toolCardHtml(tool) {
    const cat = (window.TZ_CATEGORIES || []).find(function (c) {
      return c.id === tool.category;
    });
    const color = cat ? cat.color : "blue";
    return (
      '<a class="tool-card" href="/tools/' + tool.id + '.html">' +
      '<div class="tool-card-top">' +
      '<div class="tool-icon ' + iconClass(color) + '">' + tzIcon(tool.icon) + "</div>" +
      badgeHtml(tool.status) +
      "</div>" +
      "<h3>" + escapeHtml(tool.name) + "</h3>" +
      "<p>" + escapeHtml(tool.short) + "</p>" +
      '<span class="tool-card-action">Use tool ' + tzIcon("arrow-right") + "</span>" +
      "</a>"
    );
  }

  function categoryCardHtml(cat) {
    const count = (window.TZ_TOOLS || []).filter(function (t) {
      return t.category === cat.id;
    }).length;
    return (
      '<a class="category-card" href="/categories/' + cat.id + '.html">' +
      '<div class="category-icon ' + iconClass(cat.color) + '">' + tzIcon(cat.icon) + "</div>" +
      "<h3>" + escapeHtml(cat.name) + "</h3>" +
      "<p>" + escapeHtml(cat.short) + "</p>" +
      '<span class="count">' + tzIcon("grid") + count + " tool" + (count === 1 ? "" : "s") + "</span>" +
      "</a>"
    );
  }

  window.TZ.toolCardHtml = toolCardHtml;
  window.TZ.categoryCardHtml = categoryCardHtml;

  /* ---------------------------- dynamic section rendering ---------------------------- */

  function renderDynamicSections() {
    const TOOLS = window.TZ_TOOLS || [];
    const CATEGORIES = window.TZ_CATEGORIES || [];

    // Homepage: category grid
    const catGrid = document.getElementById("tz-categories-grid");
    if (catGrid) {
      catGrid.innerHTML = CATEGORIES.map(categoryCardHtml).join("");
    }

    // Homepage: popular tools
    const popularGrid = document.getElementById("tz-popular-tools");
    if (popularGrid) {
      // Home page shows only the top 6 most popular tools (ordered by "rank" in tools-data.js).
      const popular = TOOLS.filter(function (t) { return t.status === "popular"; })
        .sort(function (a, b) { return (a.rank || 99) - (b.rank || 99); }).slice(0, 6);
      popularGrid.innerHTML = popular.map(toolCardHtml).join("");
    }

    // Homepage: recently added tools (falls back gracefully if none flagged "new")
    const recentGrid = document.getElementById("tz-recent-tools");
    if (recentGrid) {
      let recent = TOOLS.filter(function (t) { return t.status === "new"; });
      if (recent.length === 0) recent = TOOLS.slice(-4);
      recentGrid.innerHTML = recent.slice(0, 4).map(toolCardHtml).join("");
    }

    // Category page: "explore other categories" grid (all categories except the current one)
    const otherCatsEl = document.querySelector("[data-other-categories]");
    if (otherCatsEl) {
      const currentCatId = otherCatsEl.getAttribute("data-other-categories");
      const others = CATEGORIES.filter(function (c) { return c.id !== currentCatId; });
      otherCatsEl.innerHTML = others.map(categoryCardHtml).join("");
    }

    // Category page: tool grid scoped to one category
    const catToolsEl = document.querySelector("[data-category-tools]");
    if (catToolsEl) {
      const catId = catToolsEl.getAttribute("data-category-tools");
      const list = TOOLS.filter(function (t) { return t.category === catId; });
      catToolsEl.innerHTML = list.map(toolCardHtml).join("");
      const countEl = document.getElementById("tz-category-count");
      if (countEl) countEl.textContent = list.length + " tool" + (list.length === 1 ? "" : "s");
    }

    // All Tools page
    const allToolsGrid = document.getElementById("tz-all-tools-grid");
    if (allToolsGrid) {
      initAllToolsPage(TOOLS, CATEGORIES, allToolsGrid);
    }

    // Related tools on a tool page
    const relatedEl = document.getElementById("tz-related-tools");
    if (relatedEl) {
      const toolId = relatedEl.getAttribute("data-tool-id");
      const current = TOOLS.find(function (t) { return t.id === toolId; });
      let related = [];
      if (current) {
        related = TOOLS.filter(function (t) { return t.category === current.category && t.id !== toolId; }).slice(0, 3);
      }
      if (related.length === 0) {
        related = TOOLS.filter(function (t) { return t.id !== toolId; }).slice(0, 3);
      }
      relatedEl.innerHTML = related.map(toolCardHtml).join("");
    }
  }

  // Subtle scroll-triggered reveal for card grids and the "How it works" steps.
  // Safety: .reveal-pending (the only class that hides anything) is added by
  // this function itself, never present in static/generated markup — so if
  // JS fails or IntersectionObserver is unsupported, nothing is ever hidden.
  // v13: scroll reveal rewritten. Elements are pre-hidden by CSS (set up by a tiny script in <head>) so
  // they never flash, then slide up one after another as they enter the screen. If this code never runs
  // (slow or failed script load) CSS shows everything after 5 seconds, so nothing stays hidden.
  function initScrollReveal() {
    const root = document.documentElement;
    const reduced = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduced || !("IntersectionObserver" in window)) { root.classList.add("tz-ready"); return; }
    const SELECTOR = "main .section-head, main .tool-card, main .category-card, main .steps-row > *, main .howto-item, main .faq-item, main .trust-item, main .prose > h2, main .filter-sidebar";
    const seen = new WeakSet();
    const io = new IntersectionObserver(function (entries) {
      const vis = entries.filter(function (e) { return e.isIntersecting; }).sort(function (a, b) {
        return a.boundingClientRect.top - b.boundingClientRect.top || a.boundingClientRect.left - b.boundingClientRect.left;
      });
      vis.forEach(function (entry, i) {
        const el = entry.target;
        io.unobserve(el);
        el.style.setProperty("--d", Math.min(i * 90, 540) + "ms");
        requestAnimationFrame(function () { el.classList.add("tz-in"); });
        setTimeout(function () {
          el.classList.remove("tz-reveal", "tz-in");
          el.style.removeProperty("--d");
        }, 1500 + Math.min(i * 90, 540));
      });
    }, { threshold: 0.12, rootMargin: "0px 0px -6% 0px" });

    function register(list) {
      list.forEach(function (el) {
        if (seen.has(el)) return;
        seen.add(el);
        if (el.closest(".tool-shell, .search-results, .hero")) return;
        el.classList.add("tz-reveal");
        io.observe(el);
      });
    }
    register(Array.prototype.slice.call(document.querySelectorAll(SELECTOR)));
    root.classList.add("tz-ready");           // un-hide: elements now carry .tz-reveal and animate in

    // cards that get drawn later (related tools, filters, search) are picked up too
    const mo = new MutationObserver(function () {
      register(Array.prototype.slice.call(document.querySelectorAll(SELECTOR)));   // runs before the next paint
    });
    mo.observe(document.body, { childList: true, subtree: true });
  }

  function initAllToolsPage(TOOLS, CATEGORIES, gridEl) {
    const params = new URLSearchParams(window.location.search);
    let activeCat = params.get("category") || "all";

    const sidebar = document.getElementById("tz-filter-sidebar");
    function renderSidebar() {
      if (!sidebar) return;
      const allCount = TOOLS.length;
      let html = '<a href="/all-tools.html" data-cat="all" class="' + (activeCat === "all" ? "active" : "") + '">All tools <span>' + allCount + "</span></a>";
      CATEGORIES.forEach(function (c) {
        const count = TOOLS.filter(function (t) { return t.category === c.id; }).length;
        html += '<a href="/all-tools.html?category=' + c.id + '" data-cat="' + c.id + '" class="' + (activeCat === c.id ? "active" : "") + '">' + escapeHtml(c.name) + " <span>" + count + "</span></a>";
      });
      sidebar.innerHTML = html;
      sidebar.querySelectorAll("a").forEach(function (a) {
        a.addEventListener("click", function (e) {
          e.preventDefault();
          activeCat = a.getAttribute("data-cat");
          const url = new URL(window.location.href);
          if (activeCat === "all") url.searchParams.delete("category");
          else url.searchParams.set("category", activeCat);
          window.history.pushState({}, "", url);
          renderSidebar();
          renderGrid();
        });
      });
    }

    function renderGrid() {
      const list = activeCat === "all" ? TOOLS : TOOLS.filter(function (t) { return t.category === activeCat; });
      const heading = document.getElementById("tz-all-tools-heading");
      if (heading) {
        const cat = CATEGORIES.find(function (c) { return c.id === activeCat; });
        heading.textContent = cat ? cat.name : "All tools";
      }
      if (list.length === 0) {
        gridEl.innerHTML = "";
        gridEl.insertAdjacentHTML(
          "afterend",
          '<div class="empty-state" id="tz-empty">' + tzIcon("compass", "") + "<h3>No tools here yet</h3><p>Try a different category.</p></div>"
        );
      } else {
        const existingEmpty = document.getElementById("tz-empty");
        if (existingEmpty) existingEmpty.remove();
        gridEl.innerHTML = list.map(toolCardHtml).join("");
      }
    }

    renderSidebar();
    renderGrid();
  }
})();

/* =========================================================
   v12 — theme toggle, scroll progress, back-to-top, ripple,
   page-leave transition, keyboard shortcuts
   ========================================================= */
(function () {
  "use strict";
  var root = document.documentElement;
  var reduced = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  function ready(fn) {
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", fn);
    else fn();
  }

  /* ---- Theme toggle (saved in this browser only) ---- */
  function currentTheme() { return root.getAttribute("data-theme") === "dark" ? "dark" : "light"; }
  function applyTheme(t, animate) {
    if (animate && !reduced) {
      root.classList.add("tz-theme-anim");
      setTimeout(function () { root.classList.remove("tz-theme-anim"); }, 450);
    }
    if (t === "dark") root.setAttribute("data-theme", "dark"); else root.removeAttribute("data-theme");
    var meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute("content", t === "dark" ? "#09121F" : "#ffffff");
  }
  function initThemeToggle() {
    var actions = document.querySelector(".header-actions");
    if (!actions || actions.querySelector(".theme-toggle")) return;
    var btn = document.createElement("button");
    btn.type = "button";
    btn.className = "theme-toggle";
    btn.setAttribute("aria-label", "Switch between light and dark theme");
    btn.innerHTML =
      '<svg class="i-moon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z"/></svg>' +
      '<svg class="i-sun" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>';
    actions.insertBefore(btn, actions.firstChild);
    btn.addEventListener("click", function () {
      var next = currentTheme() === "dark" ? "light" : "dark";
      applyTheme(next, true);
      try { localStorage.setItem("tz-theme", next); } catch (e) {}
      btn.classList.remove("spin");
      void btn.offsetWidth;
      if (!reduced) btn.classList.add("spin");
    });
    // Follow the system setting until the visitor picks one themselves.
    if (window.matchMedia) {
      var mq = window.matchMedia("(prefers-color-scheme: dark)");
      var onChange = function (e) {
        var saved = null;
        try { saved = localStorage.getItem("tz-theme"); } catch (err) {}
        if (!saved) applyTheme(e.matches ? "dark" : "light", true);
      };
      if (mq.addEventListener) mq.addEventListener("change", onChange);
    }
  }

  /* ---- Scroll progress bar + back-to-top ---- */
  function initScrollUi() {
    var bar = document.createElement("div");
    bar.className = "tz-scroll-progress";
    bar.setAttribute("aria-hidden", "true");
    var top = document.createElement("button");
    top.type = "button";
    top.className = "tz-top-btn";
    top.setAttribute("aria-label", "Back to top");
    top.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M12 19V5M5 12l7-7 7 7"/></svg>';
    document.body.appendChild(bar);
    document.body.appendChild(top);
    var ticking = false;
    function update() {
      var h = document.documentElement.scrollHeight - window.innerHeight;
      var y = window.pageYOffset || document.documentElement.scrollTop;
      bar.style.transform = "scaleX(" + (h > 0 ? Math.min(1, y / h) : 0) + ")";
      top.classList.toggle("show", y > 600);
      ticking = false;
    }
    window.addEventListener("scroll", function () {
      if (!ticking) { ticking = true; window.requestAnimationFrame(update); }
    }, { passive: true });
    window.addEventListener("resize", update);
    top.addEventListener("click", function () {
      window.scrollTo({ top: 0, behavior: reduced ? "auto" : "smooth" });
    });
    update();
  }

  /* ---- Button ripple ---- */
  function initRipple() {
    if (reduced) return;
    document.addEventListener("pointerdown", function (e) {
      var btn = e.target.closest && e.target.closest(".btn");
      if (!btn || btn.disabled) return;
      var r = btn.getBoundingClientRect();
      var s = document.createElement("span");
      s.className = "tz-ripple";
      s.style.left = (e.clientX - r.left) + "px";
      s.style.top = (e.clientY - r.top) + "px";
      btn.appendChild(s);
      setTimeout(function () { if (s.parentNode) s.parentNode.removeChild(s); }, 650);
    }, { passive: true });
  }

  /* ---- Fade the page out before following an internal link ---- */
  function initPageLeave() {
    if (reduced) return;
    // Browsers with cross-page view transitions animate this themselves.
    if (window.CSSViewTransitionRule) return;
    document.addEventListener("click", function (e) {
      var a = e.target.closest && e.target.closest("a[href]");
      if (!a || e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
      if (a.target && a.target !== "_self") return;
      if (a.hasAttribute("download")) return;
      var url;
      try { url = new URL(a.href, window.location.href); } catch (err) { return; }
      if (url.origin !== window.location.origin) return;
      if (url.pathname === window.location.pathname && url.search === window.location.search) return;
      e.preventDefault();
      root.classList.add("tz-leaving");
      setTimeout(function () { window.location.href = url.href; }, 170);
    });
    window.addEventListener("pageshow", function () { root.classList.remove("tz-leaving"); });
  }

  /* ---- Keyboard shortcuts: "/" or Ctrl/Cmd+K opens search ---- */
  function initShortcuts() {
    document.addEventListener("keydown", function (e) {
      var tag = (e.target && e.target.tagName || "").toLowerCase();
      var typing = tag === "input" || tag === "textarea" || tag === "select" || (e.target && e.target.isContentEditable);
      var wantsSearch = (e.key === "/" && !typing && !e.metaKey && !e.ctrlKey) || ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k");
      if (!wantsSearch) return;
      var btn = document.getElementById("tz-header-search-btn");
      var panel = document.getElementById("tz-header-search-panel");
      var heroInput = document.querySelector(".hero-search input");
      if (heroInput && heroInput.offsetParent !== null) { e.preventDefault(); heroInput.focus(); return; }
      if (btn && panel && !panel.classList.contains("open")) { e.preventDefault(); btn.click(); }
      else if (panel && panel.classList.contains("open")) { e.preventDefault(); var i = panel.querySelector("input"); if (i) i.focus(); }
    });
  }

  ready(function () {
    initThemeToggle();
    initScrollUi();
    initRipple();
    initPageLeave();
    initShortcuts();
  });
})();
