/* =========================================================
   TOOLZIHUB \u2014 search.js
   Live, no-Enter-required search. Homepage/header search scans
   every tool; a category page's own search box is scoped to
   only that category's tools (see data-scope on .search-box).
   Depends on: icons.js, categories-data.js, tools-data.js
   ========================================================= */

(function () {
  "use strict";

  document.addEventListener("DOMContentLoaded", function () {
    document.querySelectorAll(".search-box[data-scope]").forEach(initSearchBox);
    initHeaderSearchToggle();
  });

  function categoryName(catId) {
    const c = (window.TZ_CATEGORIES || []).find(function (x) { return x.id === catId; });
    return c ? c.name : "";
  }

  function categoryColor(catId) {
    const c = (window.TZ_CATEGORIES || []).find(function (x) { return x.id === catId; });
    return c ? c.color : "blue";
  }

  function tokenize(str) {
    return str.toLowerCase().split(/[^a-z0-9]+/).filter(Boolean);
  }

  function loosePrefixMatch(a, b) {
    if (a.length < 3 || b.length < 3) return a === b;
    const n = Math.min(a.length, b.length);
    let common = 0;
    while (common < n && a[common] === b[common]) common++;
    return common >= Math.min(5, n);
  }

  function searchTools(query, scopeCategory) {
    const TOOLS = window.TZ_TOOLS || [];
    const q = query.trim().toLowerCase();
    let pool = TOOLS.slice();
    if (scopeCategory && scopeCategory !== "all") {
      pool = pool.filter(function (t) { return t.category === scopeCategory; });
    }
    if (!q) return [];
    const qTokens = tokenize(q);
    const scored = [];
    pool.forEach(function (t) {
      const name = t.name.toLowerCase();
      const haystackStr = [t.name, t.short, t.description || "", (t.keywords || []).join(" "), categoryName(t.category)]
        .join(" ")
        .toLowerCase();
      const haystackWords = tokenize(haystackStr);
      let score = 0;
      if (name === q) score += 100;
      else if (name.startsWith(q)) score += 55;
      else if (name.includes(q)) score += 35;
      const kws = (t.keywords || []).map(function (k) { return k.toLowerCase(); });
      if (kws.indexOf(q) !== -1) score += 45;
      else if (kws.some(function (k) { return k.includes(q); })) score += 25;
      if (q.length > 2 && haystackStr.includes(q)) score += 8;
      let tokenHits = 0;
      qTokens.forEach(function (tok) {
        if (haystackWords.some(function (w) { return loosePrefixMatch(tok, w); })) tokenHits++;
      });
      if (qTokens.length && tokenHits === qTokens.length) score += 10 + tokenHits * 4;
      else if (tokenHits > 0) score += tokenHits * 2;
      if (score > 0) scored.push({ tool: t, score: score });
    });
    scored.sort(function (a, b) {
      return b.score - a.score || a.tool.name.localeCompare(b.tool.name);
    });
    return scored.map(function (s) { return s.tool; });
  }

  function resultRowHtml(tool) {
    const color = categoryColor(tool.category);
    return (
      '<a class="search-result-item" href="/tools/' + tool.id + '.html">' +
      '<div class="search-result-icon ic-' + color + '">' + tzIcon(tool.icon) + "</div>" +
      '<div class="search-result-text"><strong>' + TZ.escapeHtml(tool.name) + "</strong><span>" + TZ.escapeHtml(tool.short) + "</span></div>" +
      '<span class="search-result-cat">' + TZ.escapeHtml(categoryName(tool.category)) + "</span>" +
      "</a>"
    );
  }

  function defaultSuggestions(scopeCategory) {
    const TOOLS = window.TZ_TOOLS || [];
    let pool = TOOLS;
    if (scopeCategory && scopeCategory !== "all") pool = pool.filter(function (t) { return t.category === scopeCategory; });
    let picks = pool.filter(function (t) { return t.status === "popular"; })
      .sort(function (a, b) { return (a.rank || 99) - (b.rank || 99); });
    if (picks.length === 0) picks = pool.slice();
    return picks.slice(0, 5);
  }

  function initSearchBox(box) {
    const scope = box.getAttribute("data-scope") || "all";
    const input = box.querySelector("input");
    const resultsEl = box.querySelector(".search-results");
    const clearBtn = box.querySelector(".search-clear");
    if (!input || !resultsEl) return;

    let hideTimer = null;

    function labelForScope() {
      return scope === "all" ? "Popular tools" : "Popular in " + categoryName(scope);
    }

    function renderDefault() {
      const picks = defaultSuggestions(scope);
      resultsEl.innerHTML =
        '<div class="search-section-label">' + labelForScope() + "</div>" + picks.map(resultRowHtml).join("");
    }

    function renderNoResults(q) {
      const suggestions = defaultSuggestions(scope).slice(0, 3);
      const browseHref = scope === "all" ? "/all-tools.html" : "/categories/" + scope + ".html";
      const browseLabel = scope === "all" ? "Browse all tools" : "Browse " + categoryName(scope);
      resultsEl.innerHTML =
        '<div class="search-empty">' +
        tzIcon("search", "") +
        "<h4>No tools found for \u201c" + TZ.escapeHtml(q) + "\u201d</h4>" +
        "<p>Try a different word, or explore these instead.</p>" +
        "</div>" +
        (suggestions.length ? '<div class="search-section-label">You might want</div>' + suggestions.map(resultRowHtml).join("") : "") +
        '<a class="search-result-item" href="' + browseHref + '" style="justify-content:center;font-weight:700;color:var(--blue-600);">' +
        browseLabel +
        "</a>";
    }

    function render(q) {
      if (!q) {
        renderDefault();
        return;
      }
      const results = searchTools(q, scope);
      if (results.length === 0) {
        renderNoResults(q);
        return;
      }
      resultsEl.innerHTML =
        '<div class="search-section-label">' + results.length + " result" + (results.length === 1 ? "" : "s") + "</div>" +
        results.slice(0, 8).map(resultRowHtml).join("");
    }

    function openResults() {
      clearTimeout(hideTimer);
      resultsEl.classList.remove("closing");
      render(input.value.trim());
      resultsEl.classList.add("show");
    }

    function closeResults() {
      resultsEl.classList.add("closing");
      hideTimer = setTimeout(function () {
        resultsEl.classList.remove("show", "closing");
      }, 200);
    }

    input.addEventListener("focus", openResults);
    input.addEventListener(
      "input",
      TZ.debounce(function () {
        clearBtn && clearBtn.classList.toggle("show", input.value.length > 0);
        render(input.value.trim());
        resultsEl.classList.add("show");
      }, 60)
    );
    input.addEventListener("blur", closeResults);
    resultsEl.addEventListener("mousedown", function () {
      clearTimeout(hideTimer);
    });
    function items() {
      return Array.prototype.slice.call(resultsEl.querySelectorAll(".search-result-item"));
    }
    function setActive(idx) {
      const list = items();
      list.forEach(function (el, i) { el.classList.toggle("active", i === idx); });
      if (list[idx]) list[idx].scrollIntoView({ block: "nearest" });
    }

    input.addEventListener("keydown", function (e) {
      if (e.key === "Escape") {
        input.blur();
        closeResults();
        return;
      }
      const list = items();
      if (!list.length) return;
      const activeIdx = list.findIndex(function (el) { return el.classList.contains("active"); });
      if (e.key === "ArrowDown") {
        e.preventDefault();
        setActive(activeIdx < list.length - 1 ? activeIdx + 1 : 0);
      } else if (e.key === "ArrowUp") {
        e.preventDefault();
        setActive(activeIdx > 0 ? activeIdx - 1 : list.length - 1);
      } else if (e.key === "Enter") {
        e.preventDefault();
        const target = list[activeIdx] || list[0];
        if (target) window.location.href = target.getAttribute("href");
      }
    });

    if (clearBtn) {
      clearBtn.addEventListener("click", function () {
        input.value = "";
        clearBtn.classList.remove("show");
        input.focus();
        render("");
      });
    }
  }

  /* ---------------------------- header search toggle (mobile + desktop icon) ---------------------------- */

  function initHeaderSearchToggle() {
    const btn = document.getElementById("tz-header-search-btn");
    const panel = document.getElementById("tz-header-search-panel");
    const backdrop = document.getElementById("tz-header-search-backdrop");
    if (!btn || !panel) return;
    function closeSelf() { setOpen(false); }
    function setOpen(willOpen) {
      if (willOpen && window.TZ && TZ.openMenu) TZ.openMenu(closeSelf);
      if (!willOpen && window.TZ && TZ.menuClosed) TZ.menuClosed(closeSelf);
      panel.classList.toggle("open", willOpen);
      if (backdrop) backdrop.classList.toggle("open", willOpen);
      btn.setAttribute("aria-expanded", willOpen ? "true" : "false");
      if (willOpen) {
        const input = panel.querySelector("input");
        if (input) setTimeout(function () { input.focus(); }, 50);
      }
    }
    btn.addEventListener("click", function () {
      setOpen(!panel.classList.contains("open"));
    });
    if (backdrop) backdrop.addEventListener("click", function () { setOpen(false); });
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape") setOpen(false);
    });
  }
})();
