/* =========================================================
   TOOLZIHUB \u2014 tools-logic.js
   Real, working implementations for every tool. Everything
   here runs client-side; files are never uploaded anywhere.
   Namespace: window.TZTools.<toolKey>.init()
   ========================================================= */

(function () {
  "use strict";

  const PDFJS_WORKER = "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js";
  const $ = function (id) { return document.getElementById(id); };
  const on = function (el, ev, fn) { if (el) el.addEventListener(ev, fn); };

  function ensurePdfJs() {
    if (window.pdfjsLib) {
      window.pdfjsLib.GlobalWorkerOptions.workerSrc = PDFJS_WORKER;
      return true;
    }
    return false;
  }

  function libMissingMessage(name) {
    return (
      "ToolziHub couldn\u2019t load " + name + ". This tool needs an internet connection the " +
      "first time you use it (to load its processing engine) \u2014 please check your connection and try again."
    );
  }

  function setProgress(pct) {
    const bar = $("tz-progress");
    const fill = $("tz-progress-fill");
    if (!bar || !fill) return;
    if (pct === null) {
      bar.classList.remove("show");
      fill.style.width = "0%";
      return;
    }
    bar.classList.add("show");
    fill.style.width = Math.max(0, Math.min(100, pct)) + "%";
  }

  function showResult(el, html, kind) {
    if (!el) return;
    el.style.display = "block";
    el.className = "result-box" + (kind ? " " + kind : "");
    el.innerHTML = html;
  }

  function setBtnLoading(btn, loading, loadingLabel) {
    if (!btn) return;
    if (loading) {
      btn.dataset.originalHtml = btn.innerHTML;
      btn.disabled = true;
      btn.innerHTML = "<span>" + (loadingLabel || "Working\u2026") + "</span>";
    } else {
      btn.disabled = false;
      if (btn.dataset.originalHtml) btn.innerHTML = btn.dataset.originalHtml;
    }
  }

  /* ---------------------------- generic single-file upload ---------------------------- */

  function setupSingleUpload(opts) {
    // opts: { accept, onFile(file), zoneId, inputId, listId, iconKey }
    const zone = $(opts.zoneId || "tz-upload-zone");
    const input = $(opts.inputId || "tz-file-input");
    const listEl = $(opts.listId || "tz-file-list");
    if (!zone || !input) return { clear: function () {} };
    let currentFile = null;

    function renderChip(file) {
      if (!listEl) return;
      if (!file) {
        listEl.innerHTML = "";
        return;
      }
      listEl.innerHTML =
        '<div class="file-chip">' +
        tzIcon(opts.iconKey || "file-text") +
        '<span class="name">' + TZ.escapeHtml(file.name) + " \u00b7 " + TZ.formatBytes(file.size) + "</span>" +
        '<button type="button" id="tz-file-remove" aria-label="Remove file">' + tzIcon("close") + "</button>" +
        "</div>";
      on($("tz-file-remove"), "click", function () {
        currentFile = null;
        input.value = "";
        renderChip(null);
        if (opts.onFile) opts.onFile(null);
      });
    }

    function accept(file) {
      currentFile = file;
      renderChip(file);
      if (opts.onFile) opts.onFile(file);
    }

    on(zone, "click", function () { input.click(); });
    on(zone, "keydown", function (e) {
      if (e.key === "Enter" || e.key === " ") { e.preventDefault(); input.click(); }
    });
    on(input, "change", function () {
      if (input.files && input.files[0]) accept(input.files[0]);
    });
    ["dragenter", "dragover"].forEach(function (ev) {
      on(zone, ev, function (e) {
        e.preventDefault();
        zone.classList.add("dragover");
      });
    });
    ["dragleave", "drop"].forEach(function (ev) {
      on(zone, ev, function (e) {
        e.preventDefault();
        zone.classList.remove("dragover");
      });
    });
    on(zone, "drop", function (e) {
      const file = e.dataTransfer.files && e.dataTransfer.files[0];
      if (file) accept(file);
    });

    return {
      getFile: function () { return currentFile; },
      clear: function () { currentFile = null; renderChip(null); },
    };
  }

  function fileToArrayBuffer(file) {
    return new Promise(function (resolve, reject) {
      const reader = new FileReader();
      reader.onload = function () { resolve(reader.result); };
      reader.onerror = reject;
      reader.readAsArrayBuffer(file);
    });
  }

  function fileToDataUrl(file) {
    return new Promise(function (resolve, reject) {
      const reader = new FileReader();
      reader.onload = function () { resolve(reader.result); };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }

  function loadImage(src) {
    return new Promise(function (resolve, reject) {
      const img = new Image();
      img.onload = function () { resolve(img); };
      img.onerror = reject;
      img.src = src;
    });
  }

  window.TZTools = window.TZTools || {};

  const TZ_CURRENCY_CODES = ["AED", "AFN", "ALL", "AMD", "AOA", "ARS", "AUD", "AWG", "AZN", "BAM", "BBD", "BDT", "BHD", "BIF", "BMD", "BND", "BOB", "BRL", "BSD", "BTN", "BWP", "BYN", "BZD", "CAD", "CDF", "CHF", "CLP", "CNY", "COP", "CRC", "CUP", "CVE", "CZK", "DJF", "DKK", "DOP", "DZD", "EGP", "ERN", "ETB", "EUR", "FJD", "FKP", "GBP", "GEL", "GHS", "GIP", "GMD", "GNF", "GTQ", "GYD", "HKD", "HNL", "HTG", "HUF", "IDR", "ILS", "INR", "IQD", "IRR", "ISK", "JMD", "JOD", "JPY", "KES", "KGS", "KHR", "KMF", "KPW", "KRW", "KWD", "KYD", "KZT", "LAK", "LBP", "LKR", "LRD", "LSL", "LYD", "MAD", "MDL", "MGA", "MKD", "MMK", "MNT", "MOP", "MRU", "MUR", "MVR", "MWK", "MXN", "MYR", "MZN", "NAD", "NGN", "NIO", "NOK", "NPR", "NZD", "OMR", "PAB", "PEN", "PGK", "PHP", "PKR", "PLN", "PYG", "QAR", "RON", "RSD", "RUB", "RWF", "SAR", "SBD", "SCR", "SDG", "SEK", "SGD", "SHP", "SLE", "SOS", "SRD", "SSP", "STN", "SVC", "SYP", "SZL", "THB", "TJS", "TMT", "TND", "TOP", "TRY", "TTD", "TWD", "TZS", "UAH", "UGX", "USD", "UYU", "UZS", "VES", "VND", "VUV", "WST", "XAF", "XCD", "XCG", "XOF", "XPF", "YER", "ZAR", "ZMW", "ZWG"];
  const TZ_POPULAR_CURRENCIES = ["USD", "EUR", "GBP", "CAD", "AUD", "PKR", "INR", "AED", "SAR", "JPY"];

  function currencyName(code) {
    try { return new Intl.DisplayNames(["en"], { type: "currency" }).of(code) || code; } catch (e) { return code; }
  }
  // Decimal places follow ISO 4217 (some browsers round PKR, COP etc. to 0 decimals, which is wrong for billing).
  const TZ_ZERO_DECIMAL = ["BIF", "CLP", "DJF", "GNF", "ISK", "JPY", "KMF", "KRW", "PYG", "RWF", "UGX", "VND", "VUV", "XAF", "XOF", "XPF"];
  const TZ_THREE_DECIMAL = ["BHD", "IQD", "JOD", "KWD", "LYD", "OMR", "TND"];
  function currencyDigits(code) {
    if (TZ_ZERO_DECIMAL.indexOf(code) !== -1) return 0;
    if (TZ_THREE_DECIMAL.indexOf(code) !== -1) return 3;
    return 2;
  }
  // On-screen amount, e.g. "$1,250.00" or "PKR 1,250.00".
  function formatMoney(n, code) {
    const d = currencyDigits(code);
    try { return new Intl.NumberFormat(undefined, { style: "currency", currency: code, minimumFractionDigits: d, maximumFractionDigits: d }).format(n); }
    catch (e) { return code + " " + n.toFixed(d); }
  }
  // PDF amount uses the 3-letter code (e.g. "PKR 1,250.00") so every currency prints correctly in the PDF font.
  function formatMoneyPdf(n, code) {
    const d = currencyDigits(code);
    let num;
    try { num = new Intl.NumberFormat("en-US", { minimumFractionDigits: d, maximumFractionDigits: d }).format(n); }
    catch (e) { num = n.toFixed(d); }
    return code + " " + num;
  }


  /* ============================================================= PDF TO TEXT */

  window.TZTools.pdfToText = {
    init: function () {
      const upload = setupSingleUpload({ accept: ".pdf", iconKey: "file-text", onFile: function () {} });
      const output = $("tz-output");
      const runBtn = $("tz-run");

      on(runBtn, "click", function () {
        const file = upload.getFile();
        if (!file) { TZ.showToast("Choose a PDF file first"); return; }
        if (!ensurePdfJs()) { output.value = libMissingMessage("the PDF engine"); return; }
        setBtnLoading(runBtn, true, "Reading\u2026");
        setProgress(5);
        fileToArrayBuffer(file)
          .then(function (buf) { return window.pdfjsLib.getDocument({ data: buf }).promise; })
          .then(function (pdf) {
            let text = "";
            let p = 0;
            function next() {
              p++;
              return pdf.getPage(p).then(function (page) {
                return page.getTextContent();
              }).then(function (content) {
                const strings = content.items.map(function (it) { return it.str; });
                text += strings.join(" ") + "\n\n";
                setProgress(Math.round((p / pdf.numPages) * 100));
                if (p < pdf.numPages) return next();
              });
            }
            return next().then(function () { return text; });
          })
          .then(function (text) {
            output.value = text.trim() || "No selectable text was found in this PDF. It may be a scanned document \u2014 try Image to Text (OCR) instead.";
            setProgress(null);
            setBtnLoading(runBtn, false);
          })
          .catch(function (err) {
            console.error(err);
            output.value = "Couldn\u2019t read this PDF. Make sure it isn\u2019t password-protected or corrupted.";
            setProgress(null);
            setBtnLoading(runBtn, false);
          });
      });

      on($("tz-reset"), "click", function () {
        upload.clear();
        output.value = "";
      });
      on($("tz-copy"), "click", function () {
        if (!output.value) { TZ.showToast("Nothing to copy yet"); return; }
        TZ.copyToClipboard(output.value, "Text copied");
      });
      on($("tz-download"), "click", function () {
        if (!output.value) { TZ.showToast("Nothing to download yet"); return; }
        TZ.downloadText(output.value, "extracted-text.txt");
      });
    },
  };

  /* ============================================================= PDF TO WORD */

  function escapeXml(str) {
    return String(str)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&apos;");
  }

  function buildDocx(paragraphs) {
    const zip = new JSZip();
    const contentTypes =
      '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
      '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">' +
      '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>' +
      '<Default Extension="xml" ContentType="application/xml"/>' +
      '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>' +
      "</Types>";
    const rels =
      '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
      '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
      '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>' +
      "</Relationships>";
    const bodyParas = paragraphs
      .map(function (p) {
        const safe = escapeXml(p).replace(/\n/g, "</w:t></w:r></w:p><w:p><w:r><w:t xml:space=\"preserve\">");
        return '<w:p><w:r><w:t xml:space="preserve">' + safe + "</w:t></w:r></w:p>";
      })
      .join("");
    const documentXml =
      '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
      '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">' +
      "<w:body>" + bodyParas + '<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1417" w:right="1417" w:bottom="1417" w:left="1417"/></w:sectPr>' +
      "</w:body></w:document>";
    zip.file("[Content_Types].xml", contentTypes);
    zip.file("_rels/.rels", rels);
    zip.file("word/document.xml", documentXml);
    return zip.generateAsync({
      type: "blob",
      mimeType: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    });
  }

  window.TZTools.pdfToWord = {
    init: function () {
      const upload = setupSingleUpload({ accept: ".pdf", iconKey: "file-text", onFile: function () {} });
      const output = $("tz-output");
      const runBtn = $("tz-run");
      let paragraphs = [];

      on(runBtn, "click", function () {
        const file = upload.getFile();
        if (!file) { TZ.showToast("Choose a PDF file first"); return; }
        if (!ensurePdfJs()) { output.value = libMissingMessage("the PDF engine"); return; }
        if (typeof JSZip === "undefined") { output.value = libMissingMessage("the document builder"); return; }
        setBtnLoading(runBtn, true, "Converting\u2026");
        setProgress(5);
        fileToArrayBuffer(file)
          .then(function (buf) { return window.pdfjsLib.getDocument({ data: buf }).promise; })
          .then(function (pdf) {
            paragraphs = [];
            let p = 0;
            function next() {
              p++;
              return pdf.getPage(p).then(function (page) { return page.getTextContent(); }).then(function (content) {
                const strings = content.items.map(function (it) { return it.str; });
                paragraphs.push(strings.join(" "));
                setProgress(Math.round((p / pdf.numPages) * 100));
                if (p < pdf.numPages) return next();
              });
            }
            return next();
          })
          .then(function () {
            output.value = paragraphs.join("\n\n").trim() || "No selectable text was found in this PDF.";
            setProgress(null);
            setBtnLoading(runBtn, false);
            TZ.showToast("Ready \u2014 you can download the Word file now");
          })
          .catch(function (err) {
            console.error(err);
            output.value = "Couldn\u2019t read this PDF. Make sure it isn\u2019t password-protected or corrupted.";
            setProgress(null);
            setBtnLoading(runBtn, false);
          });
      });

      on($("tz-download"), "click", function () {
        if (!paragraphs.length) { TZ.showToast("Convert a PDF first"); return; }
        buildDocx(paragraphs).then(function (blob) {
          TZ.downloadBlob(blob, "converted-document.docx");
        });
      });
    },
  };

  /* ============================================================= WORD TO PDF */

  window.TZTools.wordToPdf = {
    init: function () {
      const upload = setupSingleUpload({ accept: ".docx", iconKey: "file-word", onFile: function () {} });
      const output = $("tz-output");
      const runBtn = $("tz-run");
      let extractedText = "";

      on(runBtn, "click", function () {
        const file = upload.getFile();
        if (!file) { TZ.showToast("Choose a .docx file first"); return; }
        if (typeof mammoth === "undefined") { output.value = libMissingMessage("the Word reader"); return; }
        setBtnLoading(runBtn, true, "Reading\u2026");
        fileToArrayBuffer(file)
          .then(function (buf) { return mammoth.extractRawText({ arrayBuffer: buf }); })
          .then(function (result) {
            extractedText = result.value || "";
            output.value = extractedText.trim() || "No text was found in this document.";
            setBtnLoading(runBtn, false);
            TZ.showToast("Ready \u2014 you can download the PDF now");
          })
          .catch(function (err) {
            console.error(err);
            output.value = "Couldn\u2019t read this .docx file. Make sure it\u2019s a valid Word document.";
            setBtnLoading(runBtn, false);
          });
      });

      on($("tz-download"), "click", function () {
        if (!extractedText.trim()) { TZ.showToast("Convert a document first"); return; }
        if (!window.jspdf) { TZ.showToast(libMissingMessage("the PDF writer")); return; }
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF({ unit: "pt", format: "a4" });
        const margin = 56;
        const pageWidth = doc.internal.pageSize.getWidth();
        const pageHeight = doc.internal.pageSize.getHeight();
        const maxWidth = pageWidth - margin * 2;
        doc.setFont("helvetica", "normal");
        doc.setFontSize(11);
        const paragraphs = extractedText.split(/\n{1,}/).filter(function (p) { return p.trim().length; });
        let y = margin;
        const lineHeight = 15;
        paragraphs.forEach(function (para) {
          const lines = doc.splitTextToSize(para, maxWidth);
          lines.forEach(function (line) {
            if (y > pageHeight - margin) {
              doc.addPage();
              y = margin;
            }
            doc.text(line, margin, y);
            y += lineHeight;
          });
          y += lineHeight * 0.6;
        });
        doc.save("converted-document.pdf");
      });
    },
  };

  /* ============================================================= PDF COMPRESSOR */

  window.TZTools.pdfCompressor = {
    init: function () {
      const upload = setupSingleUpload({ accept: ".pdf", iconKey: "file-text", onFile: function (file) {
        $("tz-stat-original").textContent = file ? TZ.formatBytes(file.size) : "\u2014";
        $("tz-stat-compressed").textContent = "\u2014";
        $("tz-stat-reduction").textContent = "\u2014";
      }});
      const runBtn = $("tz-run");
      let compressedBlob = null;

      on(runBtn, "click", function () {
        const file = upload.getFile();
        if (!file) { TZ.showToast("Choose a PDF file first"); return; }
        if (!ensurePdfJs() || !window.jspdf) { TZ.showToast(libMissingMessage("the PDF engine")); return; }
        const quality = parseFloat((document.querySelector('input[name="tz-quality"]:checked') || {}).value || "0.6");
        setBtnLoading(runBtn, true, "Compressing\u2026");
        setProgress(5);
        const { jsPDF } = window.jspdf;
        let outDoc = null;

        fileToArrayBuffer(file)
          .then(function (buf) { return window.pdfjsLib.getDocument({ data: buf }).promise; })
          .then(function (pdf) {
            let p = 0;
            function next() {
              p++;
              return pdf.getPage(p).then(function (page) {
                const viewport = page.getViewport({ scale: 1.6 });
                const canvas = document.createElement("canvas");
                canvas.width = viewport.width;
                canvas.height = viewport.height;
                const ctx = canvas.getContext("2d");
                return page.render({ canvasContext: ctx, viewport: viewport }).promise.then(function () {
                  const imgData = canvas.toDataURL("image/jpeg", quality);
                  const pageViewport = page.getViewport({ scale: 1 });
                  if (!outDoc) {
                    outDoc = new jsPDF({ unit: "pt", format: [pageViewport.width, pageViewport.height] });
                  } else {
                    outDoc.addPage([pageViewport.width, pageViewport.height]);
                  }
                  outDoc.addImage(imgData, "JPEG", 0, 0, pageViewport.width, pageViewport.height);
                  setProgress(Math.round((p / pdf.numPages) * 100));
                  if (p < pdf.numPages) return next();
                });
              });
            }
            return next();
          })
          .then(function () {
            compressedBlob = outDoc.output("blob");
            $("tz-stat-compressed").textContent = TZ.formatBytes(compressedBlob.size);
            const reduction = Math.max(0, Math.round((1 - compressedBlob.size / file.size) * 100));
            $("tz-stat-reduction").textContent = reduction + "%";
            setProgress(null);
            setBtnLoading(runBtn, false);
            TZ.showToast("Compressed \u2014 ready to download");
          })
          .catch(function (err) {
            console.error(err);
            setProgress(null);
            setBtnLoading(runBtn, false);
            TZ.showToast("Couldn\u2019t compress this PDF");
          });
      });

      on($("tz-download"), "click", function () {
        if (!compressedBlob) { TZ.showToast("Compress a PDF first"); return; }
        TZ.downloadBlob(compressedBlob, "compressed.pdf");
      });
    },
  };

  /* ============================================================= MERGE PDF */

  window.TZTools.pdfMerge = {
    init: function () {
      const zone = $("tz-upload-zone");
      const input = $("tz-file-input");
      const listEl = $("tz-file-list");
      const runBtn = $("tz-run");
      let files = [];

      function render() {
        if (!files.length) { listEl.innerHTML = ""; return; }
        listEl.innerHTML = files
          .map(function (f, i) {
            return (
              '<div class="file-chip">' +
              tzIcon("file-merge") +
              '<span class="name">' + (i + 1) + ". " + TZ.escapeHtml(f.name) + " \u00b7 " + TZ.formatBytes(f.size) + "</span>" +
              '<button type="button" data-act="up" data-i="' + i + '" aria-label="Move up"' + (i === 0 ? " disabled" : "") + ">" + tzIcon("chevron-up") + "</button>" +
              '<button type="button" data-act="down" data-i="' + i + '" aria-label="Move down"' + (i === files.length - 1 ? " disabled" : "") + ">" + tzIcon("chevron-down") + "</button>" +
              '<button type="button" data-act="remove" data-i="' + i + '" aria-label="Remove">' + tzIcon("close") + "</button>" +
              "</div>"
            );
          })
          .join("");
      }

      on(listEl, "click", function (e) {
        const btn = e.target.closest("button[data-act]");
        if (!btn) return;
        const i = parseInt(btn.getAttribute("data-i"), 10);
        const act = btn.getAttribute("data-act");
        if (act === "remove") files.splice(i, 1);
        if (act === "up" && i > 0) { const t = files[i - 1]; files[i - 1] = files[i]; files[i] = t; }
        if (act === "down" && i < files.length - 1) { const t = files[i + 1]; files[i + 1] = files[i]; files[i] = t; }
        render();
      });

      on(zone, "click", function () { input.click(); });
      on(input, "change", function () {
        Array.prototype.forEach.call(input.files, function (f) { files.push(f); });
        input.value = "";
        render();
      });
      ["dragenter", "dragover"].forEach(function (ev) {
        on(zone, ev, function (e) { e.preventDefault(); zone.classList.add("dragover"); });
      });
      ["dragleave", "drop"].forEach(function (ev) {
        on(zone, ev, function (e) { e.preventDefault(); zone.classList.remove("dragover"); });
      });
      on(zone, "drop", function (e) {
        Array.prototype.forEach.call(e.dataTransfer.files, function (f) { files.push(f); });
        render();
      });

      let mergedBlob = null;
      on(runBtn, "click", function () {
        if (files.length < 2) { TZ.showToast("Add at least two PDF files"); return; }
        if (typeof PDFLib === "undefined") { TZ.showToast(libMissingMessage("the PDF engine")); return; }
        setBtnLoading(runBtn, true, "Merging\u2026");
        setProgress(10);
        const { PDFDocument } = PDFLib;
        PDFDocument.create().then(function (mergedPdf) {
          let chain = Promise.resolve();
          files.forEach(function (file, idx) {
            chain = chain
              .then(function () { return fileToArrayBuffer(file); })
              .then(function (buf) { return PDFDocument.load(buf); })
              .then(function (srcDoc) { return mergedPdf.copyPages(srcDoc, srcDoc.getPageIndices()); })
              .then(function (pages) {
                pages.forEach(function (p) { mergedPdf.addPage(p); });
                setProgress(Math.round(((idx + 1) / files.length) * 100));
              });
          });
          return chain.then(function () { return mergedPdf.save(); });
        }).then(function (bytes) {
          mergedBlob = new Blob([bytes], { type: "application/pdf" });
          setProgress(null);
          setBtnLoading(runBtn, false);
          TZ.showToast("Merged \u2014 ready to download");
        }).catch(function (err) {
          console.error(err);
          setProgress(null);
          setBtnLoading(runBtn, false);
          TZ.showToast("Couldn\u2019t merge these files \u2014 make sure they\u2019re valid PDFs");
        });
      });

      on($("tz-download"), "click", function () {
        if (!mergedBlob) { TZ.showToast("Merge your files first"); return; }
        TZ.downloadBlob(mergedBlob, "merged.pdf");
      });
    },
  };

  /* ============================================================= IMAGE TO TEXT (OCR) */

  window.TZTools.imageOcr = {
    init: function () {
      const upload = setupSingleUpload({ accept: "image/*", iconKey: "image", onFile: function () {} });
      const output = $("tz-output");
      const runBtn = $("tz-run");
      const progressLabel = $("tz-progress-label");

      on(runBtn, "click", function () {
        const file = upload.getFile();
        if (!file) { TZ.showToast("Choose an image first"); return; }
        if (typeof Tesseract === "undefined") { output.value = libMissingMessage("the text-recognition engine"); return; }
        const lang = $("tz-lang").value;
        setBtnLoading(runBtn, true, "Reading\u2026");
        progressLabel.style.display = "block";
        progressLabel.textContent = "Loading recognition engine\u2026";
        setProgress(2);
        Tesseract.recognize(file, lang, {
          logger: function (m) {
            if (m.status && typeof m.progress === "number") {
              progressLabel.textContent = m.status.charAt(0).toUpperCase() + m.status.slice(1) + "\u2026";
              setProgress(Math.round(m.progress * 100));
            }
          },
        })
          .then(function (result) {
            output.value = (result.data.text || "").trim() || "No text was recognized in this image.";
            setProgress(null);
            progressLabel.style.display = "none";
            setBtnLoading(runBtn, false);
          })
          .catch(function (err) {
            console.error(err);
            output.value = "Couldn\u2019t read text from this image. Try a clearer, higher-contrast photo.";
            setProgress(null);
            progressLabel.style.display = "none";
            setBtnLoading(runBtn, false);
          });
      });

      on($("tz-copy"), "click", function () {
        if (!output.value) { TZ.showToast("Nothing to copy yet"); return; }
        TZ.copyToClipboard(output.value, "Text copied");
      });
      on($("tz-download"), "click", function () {
        if (!output.value) { TZ.showToast("Nothing to download yet"); return; }
        TZ.downloadText(output.value, "extracted-text.txt");
      });
    },
  };

  /* ============================================================= IMAGE COMPRESSOR */

  window.TZTools.imageCompressor = {
    init: function () {
      let originalFile = null;
      let originalImg = null;
      let resultBlob = null;
      const qualityInput = $("tz-quality");
      const qualityVal = $("tz-quality-val");
      const preview = $("tz-preview");

      function recompress() {
        if (!originalImg) return;
        const canvas = document.createElement("canvas");
        canvas.width = originalImg.naturalWidth;
        canvas.height = originalImg.naturalHeight;
        const ctx = canvas.getContext("2d");
        const isPng = originalFile.type === "image/png";
        if (!isPng) {
          ctx.fillStyle = "#fff";
          ctx.fillRect(0, 0, canvas.width, canvas.height);
        }
        ctx.drawImage(originalImg, 0, 0);
        const mime = isPng ? "image/png" : (originalFile.type === "image/webp" ? "image/webp" : "image/jpeg");
        const q = parseInt(qualityInput.value, 10) / 100;
        canvas.toBlob(function (blob) {
          resultBlob = blob;
          $("tz-stat-compressed").textContent = TZ.formatBytes(blob.size);
          const reduction = Math.max(0, Math.round((1 - blob.size / originalFile.size) * 100));
          $("tz-stat-reduction").textContent = reduction + "%";
        }, mime, q);
      }

      const upload = setupSingleUpload({
        accept: "image/*",
        iconKey: "image",
        onFile: function (file) {
          resultBlob = null;
          if (!file) {
            preview.style.display = "none";
            $("tz-stat-original").textContent = "\u2014";
            $("tz-stat-compressed").textContent = "\u2014";
            $("tz-stat-reduction").textContent = "\u2014";
            return;
          }
          originalFile = file;
          $("tz-stat-original").textContent = TZ.formatBytes(file.size);
          $("tz-stat-compressed").textContent = "\u2014";
          $("tz-stat-reduction").textContent = "\u2014";
          fileToDataUrl(file).then(function (dataUrl) {
            return loadImage(dataUrl);
          }).then(function (img) {
            originalImg = img;
            preview.src = img.src;
            preview.style.display = "block";
          });
        },
      });

      on(qualityInput, "input", function () {
        qualityVal.textContent = qualityInput.value;
      });

      on($("tz-run"), "click", function () {
        if (!originalImg) { TZ.showToast("Choose an image first"); return; }
        recompress();
      });

      on($("tz-download"), "click", function () {
        if (!resultBlob) { TZ.showToast("Compress an image first"); return; }
        const ext = resultBlob.type === "image/png" ? "png" : (resultBlob.type === "image/webp" ? "webp" : "jpg");
        TZ.downloadBlob(resultBlob, "compressed." + ext);
      });
    },
  };

  /* ============================================================= IMAGE RESIZER */

  window.TZTools.imageResizer = {
    init: function () {
      let originalFile = null;
      let originalImg = null;
      let resultBlob = null;
      const widthInput = $("tz-width");
      const heightInput = $("tz-height");
      const lockRatio = $("tz-lock-ratio");
      const preview = $("tz-preview");
      let ratio = 1;
      let updating = false;

      const upload = setupSingleUpload({
        accept: "image/*",
        iconKey: "image",
        onFile: function (file) {
          resultBlob = null;
          if (!file) {
            preview.style.display = "none";
            $("tz-stat-original").textContent = "\u2014";
            $("tz-stat-new").textContent = "\u2014";
            return;
          }
          originalFile = file;
          fileToDataUrl(file).then(function (dataUrl) { return loadImage(dataUrl); }).then(function (img) {
            originalImg = img;
            ratio = img.naturalWidth / img.naturalHeight;
            widthInput.value = img.naturalWidth;
            heightInput.value = img.naturalHeight;
            preview.src = img.src;
            preview.style.display = "block";
            $("tz-stat-original").textContent = img.naturalWidth + " \u00d7 " + img.naturalHeight;
            $("tz-stat-new").textContent = "\u2014";
          });
        },
      });

      on(widthInput, "input", function () {
        if (updating || !lockRatio.checked || !ratio) return;
        updating = true;
        heightInput.value = Math.round(widthInput.value / ratio);
        updating = false;
      });
      on(heightInput, "input", function () {
        if (updating || !lockRatio.checked || !ratio) return;
        updating = true;
        widthInput.value = Math.round(heightInput.value * ratio);
        updating = false;
      });

      on($("tz-run"), "click", function () {
        if (!originalImg) { TZ.showToast("Choose an image first"); return; }
        const w2 = parseInt(widthInput.value, 10);
        const h2 = parseInt(heightInput.value, 10);
        if (!w2 || !h2 || w2 < 1 || h2 < 1) { TZ.showToast("Enter a valid width and height"); return; }
        const canvas = document.createElement("canvas");
        canvas.width = w2;
        canvas.height = h2;
        const ctx = canvas.getContext("2d");
        if (originalFile.type !== "image/png") {
          ctx.fillStyle = "#fff";
          ctx.fillRect(0, 0, w2, h2);
        }
        ctx.drawImage(originalImg, 0, 0, w2, h2);
        const mime = originalFile.type === "image/png" ? "image/png" : (originalFile.type === "image/webp" ? "image/webp" : "image/jpeg");
        canvas.toBlob(function (blob) {
          resultBlob = blob;
          $("tz-stat-new").textContent = w2 + " \u00d7 " + h2;
          TZ.showToast("Resized \u2014 ready to download");
        }, mime, 0.92);
      });

      on($("tz-download"), "click", function () {
        if (!resultBlob) { TZ.showToast("Resize an image first"); return; }
        const ext = resultBlob.type === "image/png" ? "png" : (resultBlob.type === "image/webp" ? "webp" : "jpg");
        TZ.downloadBlob(resultBlob, "resized." + ext);
      });
    },
  };

  /* ============================================================= IMAGE CONVERTER */

  window.TZTools.imageConverter = {
    init: function () {
      let originalFile = null;
      let originalImg = null;
      let resultBlob = null;
      const preview = $("tz-preview");
      const qualityField = $("tz-quality-field");
      const qualityInput = $("tz-quality");
      const qualityVal = $("tz-quality-val");

      function currentFormat() {
        const el = document.querySelector('input[name="tz-format"]:checked');
        return el ? el.value : "jpeg";
      }

      function syncQualityVisibility() {
        qualityField.style.display = currentFormat() === "png" ? "none" : "block";
      }
      document.querySelectorAll('input[name="tz-format"]').forEach(function (r) {
        on(r, "change", syncQualityVisibility);
      });
      syncQualityVisibility();
      on(qualityInput, "input", function () { qualityVal.textContent = qualityInput.value; });

      setupSingleUpload({
        accept: "image/*",
        iconKey: "image",
        onFile: function (file) {
          resultBlob = null;
          if (!file) { preview.style.display = "none"; return; }
          originalFile = file;
          fileToDataUrl(file).then(function (dataUrl) { return loadImage(dataUrl); }).then(function (img) {
            originalImg = img;
            preview.src = img.src;
            preview.style.display = "block";
          });
        },
      });

      on($("tz-run"), "click", function () {
        if (!originalImg) { TZ.showToast("Choose an image first"); return; }
        const format = currentFormat();
        const mime = format === "jpeg" ? "image/jpeg" : format === "webp" ? "image/webp" : "image/png";
        const canvas = document.createElement("canvas");
        canvas.width = originalImg.naturalWidth;
        canvas.height = originalImg.naturalHeight;
        const ctx = canvas.getContext("2d");
        if (format === "jpeg") {
          ctx.fillStyle = "#fff";
          ctx.fillRect(0, 0, canvas.width, canvas.height);
        }
        ctx.drawImage(originalImg, 0, 0);
        const q = parseInt(qualityInput.value, 10) / 100;
        canvas.toBlob(function (blob) {
          resultBlob = blob;
          TZ.showToast("Converted \u2014 ready to download");
        }, mime, format === "png" ? undefined : q);
      });

      on($("tz-download"), "click", function () {
        if (!resultBlob) { TZ.showToast("Convert an image first"); return; }
        const ext = currentFormat() === "jpeg" ? "jpg" : currentFormat();
        TZ.downloadBlob(resultBlob, "converted." + ext);
      });
    },
  };

  /* ============================================================= WORD & CHARACTER COUNTER */

  window.TZTools.wordCounter = {
    init: function () {
      const input = $("tz-input");
      function update() {
        const text = input.value;
        const trimmed = text.trim();
        const words = trimmed ? (trimmed.match(/[^\s]+/g) || []).length : 0;
        const chars = text.length;
        const charsNoSpaces = text.replace(/\s/g, "").length;
        const sentences = trimmed ? (trimmed.match(/[.!?]+(?=\s|$)/g) || []).length || (trimmed ? 1 : 0) : 0;
        const paragraphs = trimmed ? trimmed.split(/\n\s*\n/).filter(function (p) { return p.trim().length; }).length : 0;
        const readingMins = words / 200;
        const readingLabel = words === 0 ? "0 sec" : readingMins < 1 ? Math.max(1, Math.round(readingMins * 60)) + " sec" : Math.round(readingMins) + " min";
        $("tz-stat-words").textContent = words.toLocaleString();
        $("tz-stat-chars").textContent = chars.toLocaleString();
        $("tz-stat-chars-ns").textContent = charsNoSpaces.toLocaleString();
        $("tz-stat-sentences").textContent = sentences.toLocaleString();
        $("tz-stat-paragraphs").textContent = paragraphs.toLocaleString();
        $("tz-stat-reading").textContent = readingLabel;
      }
      on(input, "input", update);
      on($("tz-reset"), "click", function () { input.value = ""; update(); input.focus(); });
      update();
    },
  };

  /* ============================================================= CASE CONVERTER */

  function toTitleCase(str) {
    const smallWords = /^(a|an|and|as|at|but|by|en|for|if|in|is|nor|of|on|or|per|the|to|vs?\.?|via)$/i;
    const words = str.toLowerCase().split(/(\s+)/);
    return words
      .map(function (w, i) {
        if (/^\s+$/.test(w)) return w;
        if (i !== 0 && i !== words.length - 1 && smallWords.test(w)) return w;
        return w.charAt(0).toUpperCase() + w.slice(1);
      })
      .join("");
  }
  function toSentenceCase(str) {
    const lower = str.toLowerCase();
    return lower.replace(/(^\s*[a-z])|([.!?]\s+[a-z])/g, function (m) { return m.toUpperCase(); });
  }
  function toCamelCase(str) {
    return str
      .toLowerCase()
      .replace(/[^a-zA-Z0-9]+(.)/g, function (_, c) { return c.toUpperCase(); })
      .replace(/^[A-Z]/, function (c) { return c.toLowerCase(); });
  }
  function toSnakeCase(str) {
    return str
      .trim()
      .replace(/([a-z])([A-Z])/g, "$1_$2")
      .replace(/[^a-zA-Z0-9]+/g, "_")
      .replace(/^_+|_+$/g, "")
      .toLowerCase();
  }

  window.TZTools.caseConverter = {
    init: function () {
      const input = $("tz-input");
      const output = $("tz-output");
      function currentCase() {
        const el = document.querySelector('input[name="tz-case"]:checked');
        return el ? el.value : "upper";
      }
      function convert() {
        const text = input.value;
        let result = text;
        switch (currentCase()) {
          case "upper": result = text.toUpperCase(); break;
          case "lower": result = text.toLowerCase(); break;
          case "title": result = toTitleCase(text); break;
          case "sentence": result = toSentenceCase(text); break;
          case "camel": result = toCamelCase(text); break;
          case "snake": result = toSnakeCase(text); break;
        }
        output.value = result;
      }
      on(input, "input", convert);
      document.querySelectorAll('input[name="tz-case"]').forEach(function (r) { on(r, "change", convert); });
      on($("tz-copy"), "click", function () {
        if (!output.value) { TZ.showToast("Nothing to copy yet"); return; }
        TZ.copyToClipboard(output.value, "Copied");
      });
      convert();
    },
  };

  /* ============================================================= REMOVE DUPLICATE LINES */

  window.TZTools.dedupeLines = {
    init: function () {
      const input = $("tz-input");
      const output = $("tz-output");
      function run() {
        const caseSensitive = $("tz-case-sensitive").checked;
        const trim = $("tz-trim").checked;
        const removeBlank = $("tz-remove-blank").checked;
        let lines = input.value.split(/\r\n|\r|\n/);
        const before = lines.length;
        if (trim) lines = lines.map(function (l) { return l.trim(); });
        if (removeBlank) lines = lines.filter(function (l) { return l.trim().length > 0; });
        const seen = new Set();
        const result = [];
        lines.forEach(function (line) {
          const key = caseSensitive ? line : line.toLowerCase();
          if (!seen.has(key)) {
            seen.add(key);
            result.push(line);
          }
        });
        output.value = result.join("\n");
        $("tz-stat-before").textContent = before.toLocaleString();
        $("tz-stat-after").textContent = result.length.toLocaleString();
        $("tz-stat-removed").textContent = (before - result.length).toLocaleString();
      }
      on($("tz-run"), "click", run);
      on($("tz-copy"), "click", function () {
        if (!output.value) { TZ.showToast("Nothing to copy yet"); return; }
        TZ.copyToClipboard(output.value, "Copied");
      });
      on($("tz-download"), "click", function () {
        if (!output.value) { TZ.showToast("Nothing to download yet"); return; }
        TZ.downloadText(output.value, "deduplicated.txt");
      });
    },
  };

  /* ============================================================= JSON FORMATTER & VALIDATOR */

  window.TZTools.jsonFormatter = {
    init: function () {
      const input = $("tz-input");
      const output = $("tz-output");
      const status = $("tz-status");

      function showStatus(ok, message) {
        status.style.display = "flex";
        status.innerHTML = tzIcon(ok ? "check-circle" : "alert") + "<p>" + TZ.escapeHtml(message) + "</p>";
        status.style.background = ok ? "var(--success-bg)" : "var(--danger-bg)";
        status.style.borderColor = ok ? "#bfe6cd" : "#f5c6c6";
        status.style.color = ok ? "var(--success)" : "var(--danger)";
      }

      function parseOrError() {
        try {
          const value = JSON.parse(input.value);
          return { ok: true, value: value };
        } catch (err) {
          return { ok: false, error: err.message };
        }
      }

      function format() {
        if (!input.value.trim()) { TZ.showToast("Paste some JSON first"); return; }
        const r = parseOrError();
        if (!r.ok) {
          showStatus(false, "Invalid JSON \u2014 " + r.error);
          output.value = "";
          return;
        }
        output.value = JSON.stringify(r.value, null, 2);
        showStatus(true, "Valid JSON");
      }

      function minify() {
        if (!input.value.trim()) { TZ.showToast("Paste some JSON first"); return; }
        const r = parseOrError();
        if (!r.ok) {
          showStatus(false, "Invalid JSON \u2014 " + r.error);
          output.value = "";
          return;
        }
        output.value = JSON.stringify(r.value);
        showStatus(true, "Valid JSON");
      }

      on($("tz-format"), "click", format);
      on($("tz-minify"), "click", minify);
      on($("tz-reset"), "click", function () {
        input.value = "";
        output.value = "";
        status.style.display = "none";
      });
      on($("tz-copy"), "click", function () {
        if (!output.value) { TZ.showToast("Nothing to copy yet"); return; }
        TZ.copyToClipboard(output.value, "Copied");
      });
    },
  };

  /* ============================================================= URL ENCODER / DECODER */

  window.TZTools.urlEncoderDecoder = {
    init: function () {
      const input = $("tz-input");
      const output = $("tz-output");
      function mode() {
        const el = document.querySelector('input[name="tz-mode"]:checked');
        return el ? el.value : "encode";
      }
      function convert() {
        const text = input.value;
        if (!text) { output.value = ""; return; }
        if (mode() === "encode") {
          output.value = encodeURIComponent(text);
        } else {
          try {
            output.value = decodeURIComponent(text.replace(/\+/g, "%20"));
          } catch (e) {
            output.value = "This text doesn\u2019t look like it\u2019s percent-encoded, or it contains an invalid sequence.";
          }
        }
      }
      on(input, "input", convert);
      document.querySelectorAll('input[name="tz-mode"]').forEach(function (r) { on(r, "change", convert); });
      on($("tz-copy"), "click", function () {
        if (!output.value) { TZ.showToast("Nothing to copy yet"); return; }
        TZ.copyToClipboard(output.value, "Copied");
      });
    },
  };

  /* ============================================================= HTML / CSS / JS MINIFIER */

  function minifyCss(src) {
    return src
      .replace(/\/\*[\s\S]*?\*\//g, "")
      .replace(/\s*([{}:;,])\s*/g, "$1")
      .replace(/;}/g, "}")
      .replace(/[ \t\r\n]+/g, " ")
      .trim();
  }

  function minifyHtml(src) {
    const blocks = [];
    let out = src.replace(/<(script|style|pre|textarea)([^>]*)>([\s\S]*?)<\/\1>/gi, function (m) {
      blocks.push(m);
      return "\u0000B" + (blocks.length - 1) + "\u0000";
    });
    out = out.replace(/<!--[\s\S]*?-->/g, "");
    out = out.replace(/>\s+</g, "><");
    out = out.replace(/[ \t\r\n]+/g, " ").trim();
    out = out.replace(/\u0000B(\d+)\u0000/g, function (_, i) { return blocks[parseInt(i, 10)]; });
    return out;
  }

  function minifyJs(src) {
    // Careful, string/template/comment-aware pass: strips comments only, then
    // trims each line's leading/trailing whitespace and removes blank lines.
    // Interior spacing is left untouched so tokens can never merge.
    let out = "";
    let i = 0;
    const n = src.length;
    let inStr = null;
    while (i < n) {
      const c = src[i];
      const c2 = src[i + 1];
      if (inStr) {
        out += c;
        if (c === "\\") { out += c2 || ""; i += 2; continue; }
        if (c === inStr) inStr = null;
        i++;
        continue;
      }
      if (c === '"' || c === "'" || c === "`") { inStr = c; out += c; i++; continue; }
      if (c === "/" && c2 === "/") {
        while (i < n && src[i] !== "\n") i++;
        continue;
      }
      if (c === "/" && c2 === "*") {
        i += 2;
        while (i < n && !(src[i] === "*" && src[i + 1] === "/")) i++;
        i += 2;
        continue;
      }
      out += c;
      i++;
    }
    return out
      .split("\n")
      .map(function (l) { return l.trim(); })
      .filter(function (l) { return l.length > 0; })
      .join("\n");
  }

  window.TZTools.codeMinifier = {
    init: function () {
      const input = $("tz-input");
      const output = $("tz-output");
      function currentLang() {
        const el = document.querySelector('input[name="tz-lang"]:checked');
        return el ? el.value : "html";
      }
      on($("tz-run"), "click", function () {
        const src = input.value;
        if (!src.trim()) { TZ.showToast("Paste some code first"); return; }
        let result = "";
        const lang = currentLang();
        if (lang === "html") result = minifyHtml(src);
        else if (lang === "css") result = minifyCss(src);
        else result = minifyJs(src);
        output.value = result;
        const before = new Blob([src]).size;
        const after = new Blob([result]).size;
        $("tz-stat-original").textContent = TZ.formatBytes(before);
        $("tz-stat-min").textContent = TZ.formatBytes(after);
        $("tz-stat-reduction").textContent = before ? Math.max(0, Math.round((1 - after / before) * 100)) + "%" : "0%";
      });
      on($("tz-copy"), "click", function () {
        if (!output.value) { TZ.showToast("Nothing to copy yet"); return; }
        TZ.copyToClipboard(output.value, "Copied");
      });
      on($("tz-download"), "click", function () {
        if (!output.value) { TZ.showToast("Nothing to download yet"); return; }
        const lang = currentLang();
        const ext = lang === "html" ? "html" : lang === "css" ? "css" : "js";
        TZ.downloadText(output.value, "minified." + ext, "text/plain");
      });
    },
  };

  /* ============================================================= PERCENTAGE CALCULATOR */

  window.TZTools.percentageCalculator = {
    init: function () {
      function mode() {
        const el = document.querySelector('input[name="tz-mode"]:checked');
        return el ? el.value : "of";
      }
      function showMode() {
        $("tz-panel-of").style.display = mode() === "of" ? "block" : "none";
        $("tz-panel-is-what").style.display = mode() === "is-what" ? "block" : "none";
        $("tz-panel-change").style.display = mode() === "change" ? "block" : "none";
        compute();
      }
      function fmt(n) {
        if (!isFinite(n)) return "\u2014";
        return Math.round(n * 100) / 100;
      }
      function compute() {
        const resultEl = $("tz-stat-result");
        const sentenceEl = $("tz-result-sentence");
        const m = mode();
        if (m === "of") {
          const pct = parseFloat($("tz-of-pct").value);
          const num = parseFloat($("tz-of-num").value);
          if (isNaN(pct) || isNaN(num)) { resultEl.textContent = "\u2014"; sentenceEl.textContent = ""; return; }
          const r = (pct / 100) * num;
          resultEl.textContent = fmt(r);
          sentenceEl.textContent = pct + "% of " + num + " is " + fmt(r) + ".";
        } else if (m === "is-what") {
          const x = parseFloat($("tz-isw-x").value);
          const y = parseFloat($("tz-isw-y").value);
          if (isNaN(x) || isNaN(y) || y === 0) { resultEl.textContent = "\u2014"; sentenceEl.textContent = y === 0 ? "Y can\u2019t be zero." : ""; return; }
          const r = (x / y) * 100;
          resultEl.textContent = fmt(r) + "%";
          sentenceEl.textContent = x + " is " + fmt(r) + "% of " + y + ".";
        } else {
          const from = parseFloat($("tz-chg-from").value);
          const to = parseFloat($("tz-chg-to").value);
          if (isNaN(from) || isNaN(to) || from === 0) { resultEl.textContent = "\u2014"; sentenceEl.textContent = from === 0 ? "Original value can\u2019t be zero." : ""; return; }
          const r = ((to - from) / from) * 100;
          resultEl.textContent = (r >= 0 ? "+" : "") + fmt(r) + "%";
          sentenceEl.textContent = "That\u2019s " + (r >= 0 ? "an increase" : "a decrease") + " of " + fmt(Math.abs(r)) + "%.";
        }
      }
      document.querySelectorAll('input[name="tz-mode"]').forEach(function (r) { on(r, "change", showMode); });
      ["tz-of-pct", "tz-of-num", "tz-isw-x", "tz-isw-y", "tz-chg-from", "tz-chg-to"].forEach(function (id) {
        on($(id), "input", compute);
      });
      showMode();
    },
  };

  /* ---------------------------- shared calendar-accurate date diff ---------------------------- */
  // Adds `n` months to `date`, clamping the day-of-month to the last valid day
  // of the target month (e.g. Jan 31 + 1 month = Feb 28/29, never rolls into March).
  function addMonthsClamped(date, n) {
    const y = date.getFullYear();
    const m = date.getMonth() + n;
    const targetYear = y + Math.floor(m / 12);
    const targetMonth = ((m % 12) + 12) % 12;
    const lastDay = new Date(targetYear, targetMonth + 1, 0).getDate();
    const day = Math.min(date.getDate(), lastDay);
    return new Date(targetYear, targetMonth, day, date.getHours(), date.getMinutes(), date.getSeconds());
  }
  // Calendar-accurate years/months/days between two dates (end must be >= start).
  function diffYMD(start, end) {
    let months = (end.getFullYear() - start.getFullYear()) * 12 + (end.getMonth() - start.getMonth());
    let candidate = addMonthsClamped(start, months);
    while (candidate > end) {
      months--;
      candidate = addMonthsClamped(start, months);
    }
    const days = Math.round((end - candidate) / 86400000);
    return { years: Math.floor(months / 12), months: months % 12, days: days };
  }

  /* ============================================================= AGE CALCULATOR */

  window.TZTools.ageCalculator = {
    init: function () {
      const dob = $("tz-dob");
      const asof = $("tz-asof");
      const todayStr = new Date().toISOString().slice(0, 10);
      asof.value = todayStr;

      function compute() {
        if (!dob.value || !asof.value) return;
        const start = new Date(dob.value + "T00:00:00");
        const end = new Date(asof.value + "T00:00:00");
        if (end < start) {
          ["tz-stat-years", "tz-stat-months", "tz-stat-days", "tz-stat-next-bday"].forEach(function (id) { $(id).textContent = "\u2014"; });
          return;
        }
        const d = diffYMD(start, end);
        const years = d.years, months = d.months, days = d.days;
        $("tz-stat-years").textContent = years;
        $("tz-stat-months").textContent = months;
        $("tz-stat-days").textContent = days;

        let nextBday = new Date(end.getFullYear(), start.getMonth(), start.getDate());
        if (nextBday < end) {
          nextBday = new Date(end.getFullYear() + 1, start.getMonth(), start.getDate());
        }
        const msPerDay = 24 * 60 * 60 * 1000;
        const daysUntil = Math.round((nextBday - end) / msPerDay);
        $("tz-stat-next-bday").textContent = daysUntil === 0 ? "Today!" : daysUntil + " day" + (daysUntil === 1 ? "" : "s");
      }
      on(dob, "change", compute);
      on(asof, "change", compute);
    },
  };

  /* ============================================================= DATE & TIME DURATION CALCULATOR */

  window.TZTools.dateDuration = {
    init: function () {
      const startEl = $("tz-start");
      const endEl = $("tz-end");
      const status = $("tz-status");
      const now = new Date();
      const pad = function (n) { return String(n).padStart(2, "0"); };
      const nowStr = now.getFullYear() + "-" + pad(now.getMonth() + 1) + "-" + pad(now.getDate()) + "T" + pad(now.getHours()) + ":" + pad(now.getMinutes());
      startEl.value = nowStr;

      function compute() {
        if (!startEl.value || !endEl.value) return;
        const start = new Date(startEl.value);
        const end = new Date(endEl.value);
        if (end < start) {
          status.style.display = "flex";
          status.innerHTML = tzIcon("alert") + "<p>The end date is before the start date \u2014 try swapping them.</p>";
          ["tz-stat-breakdown", "tz-stat-days", "tz-stat-hours", "tz-stat-minutes"].forEach(function (id) { $(id).textContent = "\u2014"; });
          return;
        }
        status.style.display = "none";
        const ms = end - start;
        const totalMinutes = Math.floor(ms / 60000);
        const totalHours = Math.floor(ms / 3600000);
        const totalDays = Math.floor(ms / 86400000);
        const d = diffYMD(start, end);
        const parts = [];
        if (d.years) parts.push(d.years + "y");
        if (d.months) parts.push(d.months + "m");
        parts.push(d.days + "d");
        $("tz-stat-breakdown").textContent = parts.join(" ");
        $("tz-stat-days").textContent = totalDays.toLocaleString();
        $("tz-stat-hours").textContent = totalHours.toLocaleString();
        $("tz-stat-minutes").textContent = totalMinutes.toLocaleString();
      }
      on(startEl, "change", compute);
      on(endEl, "change", compute);
    },
  };

  /* ============================================================= UNIT CONVERTER */

  const UNIT_DATA = {
    length: { base: "m", units: { m: 1, km: 1000, cm: 0.01, mm: 0.001, mi: 1609.344, yd: 0.9144, ft: 0.3048, in: 0.0254, nmi: 1852 },
      labels: { m: "Meters", km: "Kilometers", cm: "Centimeters", mm: "Millimeters", mi: "Miles", yd: "Yards", ft: "Feet", in: "Inches", nmi: "Nautical miles" } },
    weight: { base: "kg", units: { kg: 1, g: 0.001, mg: 0.000001, t: 1000, lb: 0.45359237, oz: 0.028349523125, st: 6.35029318 },
      labels: { kg: "Kilograms", g: "Grams", mg: "Milligrams", t: "Metric tons", lb: "Pounds", oz: "Ounces", st: "Stone" } },
    volume: { base: "l", units: { l: 1, ml: 0.001, m3: 1000, gal: 3.785411784, qt: 0.946352946, pt: 0.473176473, cup: 0.2365882365, floz: 0.0295735295625 },
      labels: { l: "Liters", ml: "Milliliters", m3: "Cubic meters", gal: "Gallons (US)", qt: "Quarts (US)", pt: "Pints (US)", cup: "Cups (US)", floz: "Fluid ounces (US)" } },
    area: { base: "m2", units: { m2: 1, km2: 1000000, cm2: 0.0001, ha: 10000, mi2: 2589988.110336, acre: 4046.8564224, ft2: 0.09290304, yd2: 0.83612736 },
      labels: { m2: "Sq. meters", km2: "Sq. kilometers", cm2: "Sq. centimeters", ha: "Hectares", mi2: "Sq. miles", acre: "Acres", ft2: "Sq. feet", yd2: "Sq. yards" } },
    speed: { base: "mps", units: { mps: 1, kmh: 0.277778, mph: 0.44704, knot: 0.514444, fps: 0.3048 },
      labels: { mps: "Meters/second", kmh: "Kilometers/hour", mph: "Miles/hour", knot: "Knots", fps: "Feet/second" } },
    time: { base: "s", units: { s: 1, ms: 0.001, min: 60, hr: 3600, day: 86400, week: 604800, month: 2629800, year: 31557600 },
      labels: { s: "Seconds", ms: "Milliseconds", min: "Minutes", hr: "Hours", day: "Days", week: "Weeks", month: "Months (avg)", year: "Years (avg)" } },
    digital: { base: "b", units: { b: 1, kb: 1000, mb: 1000000, gb: 1000000000, tb: 1000000000000, byte: 8, kib: 8192, mib: 8388608 },
      labels: { b: "Bits", byte: "Bytes", kb: "Kilobits", kib: "Kilobytes", mb: "Megabits", mib: "Megabytes", gb: "Gigabits", tb: "Terabits" } },
  };

  function celsiusFrom(unit, v) {
    if (unit === "c") return v;
    if (unit === "f") return (v - 32) * (5 / 9);
    if (unit === "k") return v - 273.15;
  }
  function celsiusTo(unit, c) {
    if (unit === "c") return c;
    if (unit === "f") return c * (9 / 5) + 32;
    if (unit === "k") return c + 273.15;
  }

  window.TZTools.unitConverter = {
    init: function () {
      const categorySel = $("tz-category");
      const fromSel = $("tz-from-unit");
      const toSel = $("tz-to-unit");
      const fromVal = $("tz-from-value");
      const toVal = $("tz-to-value");

      function populateUnits(cat) {
        fromSel.innerHTML = "";
        toSel.innerHTML = "";
        if (cat === "temperature") {
          const opts = [["c", "Celsius"], ["f", "Fahrenheit"], ["k", "Kelvin"]];
          opts.forEach(function (o) {
            fromSel.insertAdjacentHTML("beforeend", '<option value="' + o[0] + '">' + o[1] + "</option>");
            toSel.insertAdjacentHTML("beforeend", '<option value="' + o[0] + '">' + o[1] + "</option>");
          });
          fromSel.value = "c";
          toSel.value = "f";
          return;
        }
        const data = UNIT_DATA[cat];
        Object.keys(data.units).forEach(function (u) {
          const label = data.labels[u] || u;
          fromSel.insertAdjacentHTML("beforeend", '<option value="' + u + '">' + label + "</option>");
          toSel.insertAdjacentHTML("beforeend", '<option value="' + u + '">' + label + "</option>");
        });
        const keys = Object.keys(data.units);
        fromSel.value = keys[0];
        toSel.value = keys[1] || keys[0];
      }

      function compute() {
        const cat = categorySel.value;
        const v = parseFloat(fromVal.value);
        if (isNaN(v)) { toVal.textContent = "\u2014"; return; }
        let result;
        if (cat === "temperature") {
          const c = celsiusFrom(fromSel.value, v);
          result = celsiusTo(toSel.value, c);
        } else {
          const data = UNIT_DATA[cat];
          const base = v * data.units[fromSel.value];
          result = base / data.units[toSel.value];
        }
        const rounded = Math.abs(result) >= 1000 ? Math.round(result * 100) / 100 : Math.round(result * 100000) / 100000;
        toVal.textContent = rounded.toLocaleString(undefined, { maximumFractionDigits: 6 });
      }

      on(categorySel, "change", function () { populateUnits(categorySel.value); compute(); });
      on(fromSel, "change", compute);
      on(toSel, "change", compute);
      on(fromVal, "input", compute);
      on($("tz-swap"), "click", function () {
        const f = fromSel.value;
        fromSel.value = toSel.value;
        toSel.value = f;
        compute();
      });

      populateUnits(categorySel.value);
      compute();
    },
  };

  window.TZ_TOOLS_INTERNAL = { setupSingleUpload, fileToArrayBuffer, fileToDataUrl, loadImage, setBtnLoading, setProgress, ensurePdfJs, libMissingMessage, $, on };

  /* ============================================================= INVOICE GENERATOR */

  window.TZTools.invoiceGenerator = {
    init: function () {
      const tbody = $("tz-line-items-body");
      const taxRateInput = $("tz-tax-rate");
      const currencySel = $("tz-currency");
      const money = function (n) { return formatMoney(n, currencySel.value || "USD"); };
      const pad = function (n) { return String(n).padStart(2, "0"); };
      const toDateInput = function (d) { return d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate()); };

      function createRow(desc, qty, price) {
        const tr = document.createElement("tr");
        tr.innerHTML =
          '<td><input type="text" class="input-field li-desc" aria-label="Line item description" placeholder="Item or service description"></td>' +
          '<td><input type="number" class="input-field li-qty" aria-label="Quantity" min="0" step="any" value="1"></td>' +
          '<td><input type="number" class="input-field li-price" aria-label="Price" min="0" step="any" value="0"></td>' +
          '<td class="li-amount" style="font-weight:700;padding-top:14px;white-space:nowrap;">' + money(0) + '</td>' +
          '<td><button type="button" class="line-item-remove" aria-label="Remove line item">' + tzIcon("trash") + "</button></td>";
        if (desc) tr.querySelector(".li-desc").value = desc;
        if (qty != null) tr.querySelector(".li-qty").value = qty;
        if (price != null) tr.querySelector(".li-price").value = price;
        return tr;
      }

      function computeTotals() {
        let subtotal = 0;
        tbody.querySelectorAll("tr").forEach(function (tr) {
          const qty = parseFloat(tr.querySelector(".li-qty").value) || 0;
          const price = parseFloat(tr.querySelector(".li-price").value) || 0;
          const amount = qty * price;
          tr.querySelector(".li-amount").textContent = money(amount);
          subtotal += amount;
        });
        const taxRate = parseFloat(taxRateInput.value) || 0;
        const tax = subtotal * (taxRate / 100);
        const total = subtotal + tax;
        $("tz-stat-subtotal").textContent = money(subtotal);
        $("tz-stat-tax").textContent = money(tax);
        $("tz-stat-total").textContent = money(total);
        return { subtotal: subtotal, tax: tax, total: total, taxRate: taxRate };
      }

      on(tbody, "input", computeTotals);
      on(tbody, "click", function (e) {
        const btn = e.target.closest(".line-item-remove");
        if (!btn) return;
        btn.closest("tr").remove();
        computeTotals();
      });
      on($("tz-add-line"), "click", function () {
        tbody.appendChild(createRow());
        computeTotals();
      });
      on(taxRateInput, "input", computeTotals);

      // Currency selector: every active ISO 4217 currency, popular ones first.
      (function fillCurrencies() {
        const popular = document.createElement("optgroup");
        popular.label = "Popular";
        const all = document.createElement("optgroup");
        all.label = "All currencies (A\u2013Z)";
        const opt = function (c) {
          const o = document.createElement("option");
          o.value = c;
          o.textContent = c + " \u2014 " + currencyName(c);
          return o;
        };
        TZ_POPULAR_CURRENCIES.forEach(function (c) { popular.appendChild(opt(c)); });
        TZ_CURRENCY_CODES.slice().sort().forEach(function (c) { all.appendChild(opt(c)); });
        currencySel.appendChild(popular);
        currencySel.appendChild(all);
        currencySel.value = "USD";
      })();
      on(currencySel, "change", computeTotals);

      function resetForm() {
        tbody.innerHTML = "";
        tbody.appendChild(createRow());
        const today = new Date();
        const due = new Date(today.getTime() + 14 * 86400000);
        $("tz-inv-number").value = "INV-0001";
        $("tz-inv-date").value = toDateInput(today);
        $("tz-due-date").value = toDateInput(due);
        taxRateInput.value = "0";
        ["tz-from-name", "tz-from-email", "tz-from-phone", "tz-from-address", "tz-to-name", "tz-to-email", "tz-to-phone", "tz-to-address", "tz-notes"].forEach(function (id) {
          $(id).value = "";
        });
        computeTotals();
      }
      on($("tz-reset"), "click", resetForm);
      resetForm();

      on($("tz-run"), "click", function () {
        if (!window.jspdf) { TZ.showToast(libMissingMessage("the PDF writer")); return; }
        const rows = Array.prototype.slice.call(tbody.querySelectorAll("tr")).map(function (tr) {
          return {
            desc: tr.querySelector(".li-desc").value || "\u2014",
            qty: parseFloat(tr.querySelector(".li-qty").value) || 0,
            price: parseFloat(tr.querySelector(".li-price").value) || 0,
          };
        }).filter(function (r) { return r.desc !== "\u2014" || r.qty || r.price; });

        if (rows.length === 0) { TZ.showToast("Add at least one line item"); return; }

        const totals = computeTotals();
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF({ unit: "pt", format: "a4" });
        const pageW = doc.internal.pageSize.getWidth();
        const pageH = doc.internal.pageSize.getHeight();
        const margin = 48;
        let y = margin;

        doc.setFont("helvetica", "bold");
        doc.setFontSize(24);
        doc.setTextColor(4, 27, 69);
        doc.text("INVOICE", margin, y + 10);
        doc.setFontSize(10);
        doc.setFont("helvetica", "normal");
        doc.setTextColor(90, 90, 90);
        const invNumber = $("tz-inv-number").value || "\u2014";
        doc.text("Invoice #" + invNumber, pageW - margin, y - 6, { align: "right" });
        doc.text("Date: " + ($("tz-inv-date").value || "\u2014"), pageW - margin, y + 8, { align: "right" });
        doc.text("Due: " + ($("tz-due-date").value || "\u2014"), pageW - margin, y + 22, { align: "right" });
        y += 50;

        doc.setDrawColor(225, 229, 240);
        doc.line(margin, y, pageW - margin, y);
        y += 24;

        function addressBlock(x, label, name, email, phone, address) {
          doc.setFont("helvetica", "bold");
          doc.setFontSize(9);
          doc.setTextColor(140, 148, 165);
          doc.text(label.toUpperCase(), x, y);
          doc.setFont("helvetica", "bold");
          doc.setFontSize(12);
          doc.setTextColor(20, 25, 40);
          doc.text(name || "\u2014", x, y + 16);
          doc.setFont("helvetica", "normal");
          doc.setFontSize(10);
          doc.setTextColor(70, 78, 95);
          let yy = y + 32;
          if (email) { doc.text(email, x, yy); yy += 14; }
          if (phone) { doc.text(phone, x, yy); yy += 14; }
          (address || "").split("\n").filter(Boolean).forEach(function (line) {
            doc.text(line, x, yy);
            yy += 14;
          });
          return yy;
        }
        const leftBottom = addressBlock(margin, "From", $("tz-from-name").value, $("tz-from-email").value, $("tz-from-phone").value, $("tz-from-address").value);
        const rightBottom = addressBlock(pageW / 2 + 10, "Bill to", $("tz-to-name").value, $("tz-to-email").value, $("tz-to-phone").value, $("tz-to-address").value);
        y = Math.max(leftBottom, rightBottom) + 20;

        const colX = { desc: margin, qty: pageW - margin - 250, price: pageW - margin - 140, amount: pageW - margin };
        doc.setFillColor(4, 27, 69);
        doc.rect(margin, y, pageW - margin * 2, 26, "F");
        doc.setFont("helvetica", "bold");
        doc.setFontSize(9);
        doc.setTextColor(255, 255, 255);
        doc.text("DESCRIPTION", colX.desc + 8, y + 17);
        doc.text("QTY", colX.qty, y + 17, { align: "right" });
        doc.text("PRICE", colX.price, y + 17, { align: "right" });
        doc.text("AMOUNT", colX.amount, y + 17, { align: "right" });
        y += 26;

        doc.setFont("helvetica", "normal");
        doc.setFontSize(10);
        rows.forEach(function (r, i) {
          if (y > pageH - 160) { doc.addPage(); y = margin; }
          const rowH = 24;
          if (i % 2 === 1) {
            doc.setFillColor(246, 248, 252);
            doc.rect(margin, y, pageW - margin * 2, rowH, "F");
          }
          doc.setTextColor(30, 35, 50);
          const descLines = doc.splitTextToSize(r.desc, colX.qty - colX.desc - 30);
          doc.text(descLines[0] || "", colX.desc + 8, y + 16);
          const cur = currencySel.value || "USD";
          doc.text(String(r.qty), colX.qty, y + 16, { align: "right" });
          doc.text(formatMoneyPdf(r.price, cur), colX.price, y + 16, { align: "right" });
          doc.text(formatMoneyPdf(r.qty * r.price, cur), colX.amount, y + 16, { align: "right" });
          y += rowH;
        });

        y += 14;
        if (y > pageH - 140) { doc.addPage(); y = margin; }
        const totalsX = pageW - margin - 200;
        function totalLine(label, value, big) {
          doc.setFont("helvetica", big ? "bold" : "normal");
          doc.setFontSize(big ? 13 : 10);
          doc.setTextColor(big ? 4 : 90, big ? 27 : 90, big ? 69 : 90);
          doc.text(label, totalsX, y);
          doc.text(value, pageW - margin, y, { align: "right" });
          y += big ? 22 : 18;
        }
        const curCode = currencySel.value || "USD";
        totalLine("Subtotal", formatMoneyPdf(totals.subtotal, curCode));
        totalLine("Tax (" + totals.taxRate + "%)", formatMoneyPdf(totals.tax, curCode));
        doc.setDrawColor(225, 229, 240);
        doc.line(totalsX, y - 4, pageW - margin, y - 4);
        y += 6;
        totalLine("Total (" + curCode + ")", formatMoneyPdf(totals.total, curCode), true);

        const notes = $("tz-notes").value;
        if (notes.trim()) {
          y += 24;
          if (y > pageH - 80) { doc.addPage(); y = margin; }
          doc.setFont("helvetica", "bold");
          doc.setFontSize(9);
          doc.setTextColor(140, 148, 165);
          doc.text("NOTES", margin, y);
          y += 16;
          doc.setFont("helvetica", "normal");
          doc.setFontSize(10);
          doc.setTextColor(70, 78, 95);
          doc.splitTextToSize(notes, pageW - margin * 2).forEach(function (line) {
            doc.text(line, margin, y);
            y += 14;
          });
        }

        doc.save((invNumber || "invoice").replace(/[^a-z0-9-_]+/gi, "-") + ".pdf");
        TZ.showToast("Invoice PDF downloaded");
      });
    },
  };
  // ---------------------------- Password Generator ----------------------------
  window.TZTools.passwordGenerator = {
    init: function () {
      const lengthInput = $("tz-length");
      const lengthValue = $("tz-length-value");
      const output = $("tz-output");
      const strengthBar = $("tz-strength-bar");
      const strengthLabel = $("tz-strength-label");
      const status = $("tz-status");
      const opts = {
        upper: $("tz-opt-upper"),
        lower: $("tz-opt-lower"),
        numbers: $("tz-opt-numbers"),
        symbols: $("tz-opt-symbols"),
      };
      const POOLS = {
        upper: "ABCDEFGHJKLMNPQRSTUVWXYZ",
        lower: "abcdefghijkmnpqrstuvwxyz",
        numbers: "23456789",
        symbols: "!@#$%^&*()-_=+[]{}",
      };

      function buildPool() {
        let pool = "";
        Object.keys(opts).forEach(function (k) {
          if (opts[k].checked) pool += POOLS[k];
        });
        return pool;
      }

      function secureRandomInt(max) {
        const arr = new Uint32Array(1);
        crypto.getRandomValues(arr);
        return arr[0] % max;
      }

      function generate() {
        const pool = buildPool();
        status.textContent = "";
        if (!pool) {
          output.value = "";
          status.textContent = "Choose at least one character type.";
          updateStrength(0);
          return;
        }
        const length = parseInt(lengthInput.value, 10) || 16;
        let result = "";
        for (let i = 0; i < length; i++) {
          result += pool[secureRandomInt(pool.length)];
        }
        output.value = result;
        updateStrength(scoreStrength(result, opts));
      }

      function scoreStrength(pw, opts) {
        let variety = 0;
        if (opts.upper.checked) variety++;
        if (opts.lower.checked) variety++;
        if (opts.numbers.checked) variety++;
        if (opts.symbols.checked) variety++;
        const lengthScore = Math.min(pw.length / 20, 1);
        return Math.min(1, (variety / 4) * 0.5 + lengthScore * 0.5);
      }

      function updateStrength(score) {
        const pct = Math.round(score * 100);
        strengthBar.style.width = pct + "%";
        let label = "Weak";
        let color = "#e05252";
        if (score > 0.75) { label = "Strong"; color = "#1fa971"; }
        else if (score > 0.45) { label = "Medium"; color = "#e0a020"; }
        else if (score === 0) { label = ""; }
        strengthBar.style.background = color;
        strengthLabel.textContent = label;
      }

      lengthInput.addEventListener("input", function () {
        lengthValue.textContent = lengthInput.value;
        generate();
      });
      Object.keys(opts).forEach(function (k) {
        opts[k].addEventListener("change", generate);
      });
      on($("tz-run"), "click", generate);
      on($("tz-copy"), "click", function () {
        if (!output.value) return;
        TZ.copyToClipboard(output.value);
        TZ.showToast("Password copied");
      });

      generate();
    },
  };

  // ---------------------------- QR Code Generator ----------------------------
  window.TZTools.qrCodeGenerator = {
    init: function () {
      const input = $("tz-input");
      const sizeSelect = $("tz-size");
      const container = $("tz-qr-preview");
      const downloadBtn = $("tz-download");
      const status = $("tz-status");
      let currentDataUrl = null;

      function render() {
        const text = input.value.trim();
        container.innerHTML = "";
        downloadBtn.style.display = "none";
        currentDataUrl = null;
        status.textContent = "";
        if (!text) return;
        if (typeof QRCode === "undefined") {
          status.textContent = libMissingMessage("the QR code engine");
          return;
        }
        const size = parseInt(sizeSelect.value, 10) || 256;
        try {
          new QRCode(container, {
            text: text,
            width: size,
            height: size,
            colorDark: "#0b1220",
            colorLight: "#ffffff",
            correctLevel: QRCode.CorrectLevel.M,
          });
          setTimeout(function () {
            const canvas = container.querySelector("canvas");
            if (canvas) {
              currentDataUrl = canvas.toDataURL("image/png");
              downloadBtn.style.display = "";
            }
          }, 30);
        } catch (e) {
          status.textContent = "Couldn't generate a QR code for that input.";
        }
      }

      on(input, "input", TZ.debounce(render, 200));
      on(sizeSelect, "change", render);
      on(downloadBtn, "click", function () {
        if (!currentDataUrl) return;
        const a = document.createElement("a");
        a.href = currentDataUrl;
        a.download = "qrcode.png";
        a.click();
      });
    },
  };

  // ---------------------------- Lorem Ipsum Generator ----------------------------
  window.TZTools.loremIpsumGenerator = {
    init: function () {
      const WORDS = ("lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor " +
        "incididunt ut labore et dolore magna aliqua enim ad minim veniam quis nostrud exercitation " +
        "ullamco laboris nisi aliquip ex ea commodo consequat duis aute irure in reprehenderit " +
        "voluptate velit esse cillum eu fugiat nulla pariatur excepteur sint occaecat cupidatat non " +
        "proident sunt culpa qui officia deserunt mollit anim id est laborum").split(" ");

      const unitSelect = $("tz-unit");
      const countInput = $("tz-count");
      const classicCheck = $("tz-classic");
      const output = $("tz-output");

      function randomWord() {
        return WORDS[Math.floor(Math.random() * WORDS.length)];
      }
      function makeSentence(minWords, maxWords) {
        const n = minWords + Math.floor(Math.random() * (maxWords - minWords));
        let words = [];
        for (let i = 0; i < n; i++) words.push(randomWord());
        let s = words.join(" ");
        return s.charAt(0).toUpperCase() + s.slice(1) + ".";
      }
      function makeParagraph(sentenceCount) {
        let sentences = [];
        for (let i = 0; i < sentenceCount; i++) sentences.push(makeSentence(6, 16));
        return sentences.join(" ");
      }

      function generate() {
        const unit = unitSelect.value;
        const count = Math.max(1, Math.min(50, parseInt(countInput.value, 10) || 1));
        let result = "";
        if (unit === "words") {
          let words = [];
          for (let i = 0; i < count; i++) words.push(randomWord());
          if (classicCheck.checked) {
            const classic = "lorem ipsum dolor sit amet".split(" ");
            words = classic.slice(0, count).concat(words.slice(0, Math.max(0, count - classic.length)));
          }
          result = words.join(" ");
          result = result.charAt(0).toUpperCase() + result.slice(1) + ".";
        } else if (unit === "sentences") {
          let sentences = [];
          for (let i = 0; i < count; i++) sentences.push(makeSentence(6, 16));
          if (classicCheck.checked) sentences[0] = "Lorem ipsum dolor sit amet, consectetur adipiscing elit.";
          result = sentences.join(" ");
        } else {
          let paragraphs = [];
          for (let i = 0; i < count; i++) paragraphs.push(makeParagraph(4 + Math.floor(Math.random() * 3)));
          if (classicCheck.checked) {
            paragraphs[0] = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. " + paragraphs[0];
          }
          result = paragraphs.join("\n\n");
        }
        output.value = result;
      }

      on($("tz-run"), "click", generate);
      on($("tz-copy"), "click", function () {
        if (!output.value) return;
        TZ.copyToClipboard(output.value);
        TZ.showToast("Text copied");
      });
      generate();
    },
  };

  // ---------------------------- Base64 Encoder/Decoder ----------------------------
  window.TZTools.base64EncoderDecoder = {
    init: function () {
      const input = $("tz-input");
      const output = $("tz-output");
      const status = $("tz-status");
      function mode() {
        const el = document.querySelector('input[name="tz-mode"]:checked');
        return el ? el.value : "encode";
      }

      function run() {
        const text = input.value;
        status.textContent = "";
        if (!text) { output.value = ""; return; }
        try {
          if (mode() === "encode") {
            const bytes = new TextEncoder().encode(text);
            let binary = "";
            bytes.forEach(function (b) { binary += String.fromCharCode(b); });
            output.value = btoa(binary);
          } else {
            const binary = atob(text.trim());
            const bytes = new Uint8Array(binary.length);
            for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
            output.value = new TextDecoder().decode(bytes);
          }
        } catch (e) {
          output.value = "";
          status.textContent = mode() === "decode" ? "That doesn't look like valid Base64." : "Couldn't encode that text.";
        }
      }

      on(input, "input", TZ.debounce(run, 100));
      document.querySelectorAll('input[name="tz-mode"]').forEach(function (r) { on(r, "change", run); });
      on($("tz-copy"), "click", function () {
        if (!output.value) return;
        TZ.copyToClipboard(output.value);
        TZ.showToast("Copied");
      });
      on($("tz-swap"), "click", function () {
        const encodeRadio = document.getElementById("tz-mode-encode");
        const decodeRadio = document.getElementById("tz-mode-decode");
        input.value = output.value;
        if (mode() === "encode") { decodeRadio.checked = true; } else { encodeRadio.checked = true; }
        run();
      });
    },
  };

  // ---------------------------- Hash Generator ----------------------------
  window.TZTools.hashGenerator = {
    init: function () {
      const input = $("tz-input");
      const algoSelect = $("tz-algo");
      const output = $("tz-output");
      const status = $("tz-status");

      async function run() {
        const text = input.value;
        status.textContent = "";
        if (!text) { output.value = ""; return; }
        if (!window.crypto || !window.crypto.subtle) {
          status.textContent = "Your browser doesn't support secure hashing.";
          return;
        }
        try {
          const algo = algoSelect.value;
          const bytes = new TextEncoder().encode(text);
          const digest = await crypto.subtle.digest(algo, bytes);
          const hex = Array.prototype.map
            .call(new Uint8Array(digest), function (b) { return b.toString(16).padStart(2, "0"); })
            .join("");
          output.value = hex;
        } catch (e) {
          status.textContent = "Couldn't hash that input.";
        }
      }

      on(input, "input", TZ.debounce(run, 150));
      on(algoSelect, "change", run);
      on($("tz-copy"), "click", function () {
        if (!output.value) return;
        TZ.copyToClipboard(output.value);
        TZ.showToast("Hash copied");
      });
    },
  };

  // ---------------------------- Regex Tester ----------------------------
  window.TZTools.regexTester = {
    init: function () {
      const patternInput = $("tz-pattern");
      const testInput = $("tz-test-text");
      const globalCheck = $("tz-flag-g");
      const iCheck = $("tz-flag-i");
      const mCheck = $("tz-flag-m");
      const highlighted = $("tz-highlighted");
      const status = $("tz-status");
      const matchList = $("tz-match-list");

      function run() {
        const pattern = patternInput.value;
        const text = testInput.value;
        matchList.innerHTML = "";
        if (!pattern) {
          highlighted.innerHTML = TZ.escapeHtml(text);
          status.textContent = "";
          return;
        }
        let flags = "";
        if (globalCheck.checked) flags += "g";
        if (iCheck.checked) flags += "i";
        if (mCheck.checked) flags += "m";
        let re;
        try {
          re = new RegExp(pattern, flags);
        } catch (e) {
          status.textContent = "Invalid pattern — " + e.message;
          highlighted.innerHTML = TZ.escapeHtml(text);
          return;
        }
        status.textContent = "";
        if (!text) { highlighted.innerHTML = ""; return; }

        let html = "";
        let lastIndex = 0;
        let match;
        let count = 0;
        const matches = [];
        const globalRe = new RegExp(pattern, flags.indexOf("g") === -1 ? flags + "g" : flags);
        while ((match = globalRe.exec(text)) !== null) {
          html += TZ.escapeHtml(text.slice(lastIndex, match.index));
          html += '<mark>' + TZ.escapeHtml(match[0]) + "</mark>";
          lastIndex = match.index + (match[0].length || 1);
          matches.push(match);
          count++;
          if (match[0].length === 0) globalRe.lastIndex++;
          if (count > 500) break;
        }
        html += TZ.escapeHtml(text.slice(lastIndex));
        highlighted.innerHTML = html || "&nbsp;";

        if (!matches.length) {
          matchList.innerHTML = '<p class="muted">No matches.</p>';
        } else {
          matchList.innerHTML = matches
            .slice(0, 100)
            .map(function (m, i) {
              const groups = m.slice(1).filter(function (g) { return g !== undefined; });
              const groupText = groups.length ? " — groups: " + groups.map(TZ.escapeHtml).join(", ") : "";
              return '<div class="match-row"><strong>#' + (i + 1) + "</strong> " + TZ.escapeHtml(m[0]) + groupText + "</div>";
            })
            .join("");
        }
      }

      [patternInput, testInput].forEach(function (el) {
        on(el, "input", TZ.debounce(run, 120));
      });
      [globalCheck, iCheck, mCheck].forEach(function (el) {
        on(el, "change", run);
      });
      run();
    },
  };

  // ---------------------------- Color Converter ----------------------------
  window.TZTools.colorConverter = {
    init: function () {
      const hexInput = $("tz-hex");
      const rgbInput = $("tz-rgb");
      const hslInput = $("tz-hsl");
      const picker = $("tz-picker");
      const swatch = $("tz-swatch");
      const status = $("tz-status");

      function clamp(v, min, max) { return Math.min(max, Math.max(min, v)); }

      function hexToRgb(hex) {
        hex = hex.replace("#", "").trim();
        if (hex.length === 3) hex = hex.split("").map(function (c) { return c + c; }).join("");
        if (!/^[0-9a-f]{6}$/i.test(hex)) return null;
        return {
          r: parseInt(hex.slice(0, 2), 16),
          g: parseInt(hex.slice(2, 4), 16),
          b: parseInt(hex.slice(4, 6), 16),
        };
      }
      function rgbToHex(r, g, b) {
        return "#" + [r, g, b].map(function (v) { return clamp(Math.round(v), 0, 255).toString(16).padStart(2, "0"); }).join("");
      }
      function rgbToHsl(r, g, b) {
        r /= 255; g /= 255; b /= 255;
        const max = Math.max(r, g, b), min = Math.min(r, g, b);
        let h, s, l = (max + min) / 2;
        if (max === min) { h = s = 0; }
        else {
          const d = max - min;
          s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
          switch (max) {
            case r: h = (g - b) / d + (g < b ? 6 : 0); break;
            case g: h = (b - r) / d + 2; break;
            default: h = (r - g) / d + 4;
          }
          h /= 6;
        }
        return { h: Math.round(h * 360), s: Math.round(s * 100), l: Math.round(l * 100) };
      }
      function hslToRgb(h, s, l) {
        h /= 360; s /= 100; l /= 100;
        if (s === 0) { const v = Math.round(l * 255); return { r: v, g: v, b: v }; }
        function hue2rgb(p, q, t) {
          if (t < 0) t += 1;
          if (t > 1) t -= 1;
          if (t < 1 / 6) return p + (q - p) * 6 * t;
          if (t < 1 / 2) return q;
          if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
          return p;
        }
        const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
        const p = 2 * l - q;
        return {
          r: Math.round(hue2rgb(p, q, h + 1 / 3) * 255),
          g: Math.round(hue2rgb(p, q, h) * 255),
          b: Math.round(hue2rgb(p, q, h - 1 / 3) * 255),
        };
      }
      function parseRgbString(str) {
        const m = str.match(/(-?\d+(\.\d+)?)/g);
        if (!m || m.length < 3) return null;
        return { r: clamp(+m[0], 0, 255), g: clamp(+m[1], 0, 255), b: clamp(+m[2], 0, 255) };
      }
      function parseHslString(str) {
        const m = str.match(/(-?\d+(\.\d+)?)/g);
        if (!m || m.length < 3) return null;
        return { h: ((+m[0] % 360) + 360) % 360, s: clamp(+m[1], 0, 100), l: clamp(+m[2], 0, 100) };
      }

      function updateFrom(rgb) {
        if (!rgb) { status.textContent = "Enter a valid color value."; return; }
        status.textContent = "";
        const hex = rgbToHex(rgb.r, rgb.g, rgb.b);
        const hsl = rgbToHsl(rgb.r, rgb.g, rgb.b);
        hexInput.value = hex;
        rgbInput.value = "rgb(" + rgb.r + ", " + rgb.g + ", " + rgb.b + ")";
        hslInput.value = "hsl(" + hsl.h + ", " + hsl.s + "%, " + hsl.l + "%)";
        picker.value = hex;
        swatch.style.background = hex;
      }

      on(hexInput, "input", function () { updateFrom(hexToRgb(hexInput.value)); });
      on(rgbInput, "input", function () { updateFrom(parseRgbString(rgbInput.value)); });
      on(hslInput, "input", function () {
        const hsl = parseHslString(hslInput.value);
        updateFrom(hsl ? hslToRgb(hsl.h, hsl.s, hsl.l) : null);
      });
      on(picker, "input", function () { updateFrom(hexToRgb(picker.value)); });

      updateFrom({ r: 11, g: 114, b: 214 });
    },
  };

  // ---------------------------- UUID Generator ----------------------------
  window.TZTools.uuidGenerator = {
    init: function () {
      const countInput = $("tz-count");
      const output = $("tz-output");

      function makeUuid() {
        if (window.crypto && crypto.randomUUID) return crypto.randomUUID();
        const bytes = new Uint8Array(16);
        crypto.getRandomValues(bytes);
        bytes[6] = (bytes[6] & 0x0f) | 0x40;
        bytes[8] = (bytes[8] & 0x3f) | 0x80;
        const hex = Array.prototype.map.call(bytes, function (b) { return b.toString(16).padStart(2, "0"); });
        return [hex.slice(0, 4).join(""), hex.slice(4, 6).join(""), hex.slice(6, 8).join(""), hex.slice(8, 10).join(""), hex.slice(10, 16).join("")].join("-");
      }

      function generate() {
        const count = Math.max(1, Math.min(100, parseInt(countInput.value, 10) || 1));
        const list = [];
        for (let i = 0; i < count; i++) list.push(makeUuid());
        output.value = list.join("\n");
      }

      on($("tz-run"), "click", generate);
      on($("tz-copy"), "click", function () {
        if (!output.value) return;
        TZ.copyToClipboard(output.value);
        TZ.showToast(output.value.indexOf("\n") === -1 ? "UUID copied" : "UUIDs copied");
      });
      generate();
    },
  };

  // ---------------------------- BMI Calculator ----------------------------
  window.TZTools.bmiCalculator = {
    init: function () {
      const unitRadios = document.getElementsByName("tz-units");
      const metricFields = $("tz-metric-fields");
      const imperialFields = $("tz-imperial-fields");
      const heightCm = $("tz-height-cm");
      const weightKg = $("tz-weight-kg");
      const heightFt = $("tz-height-ft");
      const heightIn = $("tz-height-in");
      const weightLb = $("tz-weight-lb");
      const resultValue = $("tz-stat-bmi");
      const resultCategory = $("tz-stat-category");

      function units() {
        for (let i = 0; i < unitRadios.length; i++) if (unitRadios[i].checked) return unitRadios[i].value;
        return "metric";
      }

      function categoryFor(bmi) {
        if (bmi < 18.5) return "Underweight";
        if (bmi < 25) return "Normal weight";
        if (bmi < 30) return "Overweight";
        return "Obese";
      }

      function compute() {
        const isMetric = units() === "metric";
        metricFields.style.display = isMetric ? "" : "none";
        imperialFields.style.display = isMetric ? "none" : "";
        let bmi = null;
        if (isMetric) {
          const h = parseFloat(heightCm.value) / 100;
          const w = parseFloat(weightKg.value);
          if (h > 0 && w > 0) bmi = w / (h * h);
        } else {
          const ft = parseFloat(heightFt.value) || 0;
          const inch = parseFloat(heightIn.value) || 0;
          const totalIn = ft * 12 + inch;
          const w = parseFloat(weightLb.value);
          if (totalIn > 0 && w > 0) bmi = (703 * w) / (totalIn * totalIn);
        }
        if (bmi && isFinite(bmi)) {
          resultValue.textContent = bmi.toFixed(1);
          resultCategory.textContent = categoryFor(bmi);
        } else {
          resultValue.textContent = "—";
          resultCategory.textContent = "Enter your height and weight";
        }
      }

      for (let i = 0; i < unitRadios.length; i++) on(unitRadios[i], "change", compute);
      [heightCm, weightKg, heightFt, heightIn, weightLb].forEach(function (el) {
        on(el, "input", compute);
      });
      compute();
    },
  };

  // ---------------------------- Loan Calculator ----------------------------
  window.TZTools.loanCalculator = {
    init: function () {
      const amountInput = $("tz-amount");
      const rateInput = $("tz-rate");
      const yearsInput = $("tz-years");
      const monthlyOut = $("tz-stat-monthly");
      const totalOut = $("tz-stat-total");
      const interestOut = $("tz-stat-interest");

      function compute() {
        const principal = parseFloat(amountInput.value);
        const annualRate = parseFloat(rateInput.value);
        const years = parseFloat(yearsInput.value);
        if (!(principal > 0) || !(years > 0) || isNaN(annualRate) || annualRate < 0) {
          monthlyOut.textContent = "—";
          totalOut.textContent = "—";
          interestOut.textContent = "—";
          return;
        }
        const n = years * 12;
        const monthlyRate = annualRate / 100 / 12;
        let monthly;
        if (monthlyRate === 0) {
          monthly = principal / n;
        } else {
          monthly = (principal * monthlyRate) / (1 - Math.pow(1 + monthlyRate, -n));
        }
        const total = monthly * n;
        const interest = total - principal;
        const fmt = function (v) { return "$" + v.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }); };
        monthlyOut.textContent = fmt(monthly);
        totalOut.textContent = fmt(total);
        interestOut.textContent = fmt(interest);
      }

      [amountInput, rateInput, yearsInput].forEach(function (el) {
        on(el, "input", compute);
      });
      compute();
    },
  };

  // ---------------------------- Unix Timestamp Converter ----------------------------
  window.TZTools.timestampConverter = {
    init: function () {
      const tsInput = $("tz-timestamp");
      const unitSelect = $("tz-unit");
      const dateInput = $("tz-date");
      const localOut = $("tz-stat-local");
      const utcOut = $("tz-stat-utc");
      const tsFromDateOut = $("tz-stat-timestamp");

      function tsToDate() {
        const raw = parseFloat(tsInput.value);
        if (isNaN(raw)) { localOut.textContent = "—"; utcOut.textContent = "—"; return; }
        const ms = unitSelect.value === "seconds" ? raw * 1000 : raw;
        const d = new Date(ms);
        if (isNaN(d.getTime())) { localOut.textContent = "Invalid"; utcOut.textContent = "Invalid"; return; }
        localOut.textContent = d.toLocaleString();
        utcOut.textContent = d.toUTCString();
      }

      function dateToTs() {
        if (!dateInput.value) { tsFromDateOut.textContent = "—"; return; }
        const d = new Date(dateInput.value);
        if (isNaN(d.getTime())) { tsFromDateOut.textContent = "Invalid date"; return; }
        const seconds = Math.floor(d.getTime() / 1000);
        tsFromDateOut.textContent = seconds + " (seconds) / " + d.getTime() + " (ms)";
      }

      on(tsInput, "input", tsToDate);
      on(unitSelect, "change", tsToDate);
      on(dateInput, "input", dateToTs);
      on($("tz-now"), "click", function () {
        const now = new Date();
        tsInput.value = Math.floor(now.getTime() / 1000);
        unitSelect.value = "seconds";
        tsToDate();
        const pad = function (n) { return String(n).padStart(2, "0"); };
        dateInput.value = now.getFullYear() + "-" + pad(now.getMonth() + 1) + "-" + pad(now.getDate()) + "T" + pad(now.getHours()) + ":" + pad(now.getMinutes());
        dateToTs();
      });
    },
  };

  // ---------------------------- Sort Lines ----------------------------
  window.TZTools.sortLines = {
    init: function () {
      const input = $("tz-input");
      const output = $("tz-output");
      const orderSelect = $("tz-order");
      const caseInsensitive = $("tz-case-insensitive");
      const removeBlank = $("tz-remove-blank");

      function run() {
        let lines = input.value.split("\n");
        if (removeBlank.checked) lines = lines.filter(function (l) { return l.trim() !== ""; });
        const order = orderSelect.value;
        const collator = new Intl.Collator(undefined, { sensitivity: caseInsensitive.checked ? "base" : "variant", numeric: order === "numeric" });
        if (order === "az" || order === "numeric") {
          lines.sort(collator.compare);
        } else if (order === "za") {
          lines.sort(collator.compare).reverse();
        } else if (order === "length") {
          lines.sort(function (a, b) { return a.length - b.length; });
        }
        output.value = lines.join("\n");
      }

      on($("tz-run"), "click", run);
      on($("tz-copy"), "click", function () {
        if (!output.value) return;
        TZ.copyToClipboard(output.value);
        TZ.showToast("Sorted list copied");
      });
    },
  };

  // ---------------------------- Text Diff Checker ----------------------------
  window.TZTools.textDiffChecker = {
    init: function () {
      const leftInput = $("tz-left");
      const rightInput = $("tz-right");
      const outputEl = $("tz-diff-output");
      const statOut = $("tz-stat-summary");

      function diffLines(a, b) {
        const m = a.length, n = b.length;
        const dp = Array.from({ length: m + 1 }, function () { return new Array(n + 1).fill(0); });
        for (let i = m - 1; i >= 0; i--) {
          for (let j = n - 1; j >= 0; j--) {
            dp[i][j] = a[i] === b[j] ? dp[i + 1][j + 1] + 1 : Math.max(dp[i + 1][j], dp[i][j + 1]);
          }
        }
        const result = [];
        let i = 0, j = 0;
        while (i < m && j < n) {
          if (a[i] === b[j]) { result.push({ type: "same", text: a[i] }); i++; j++; }
          else if (dp[i + 1][j] >= dp[i][j + 1]) { result.push({ type: "removed", text: a[i] }); i++; }
          else { result.push({ type: "added", text: b[j] }); j++; }
        }
        while (i < m) { result.push({ type: "removed", text: a[i] }); i++; }
        while (j < n) { result.push({ type: "added", text: b[j] }); j++; }
        return result;
      }

      function run() {
        const a = leftInput.value.split("\n");
        const b = rightInput.value.split("\n");
        if (!leftInput.value && !rightInput.value) {
          outputEl.innerHTML = "";
          statOut.textContent = "";
          return;
        }
        const diff = diffLines(a, b);
        let added = 0, removed = 0;
        const html = diff
          .map(function (d) {
            if (d.type === "added") added++;
            if (d.type === "removed") removed++;
            const cls = d.type === "added" ? "diff-added" : d.type === "removed" ? "diff-removed" : "diff-same";
            const prefix = d.type === "added" ? "+ " : d.type === "removed" ? "- " : "  ";
            return '<div class="' + cls + '">' + TZ.escapeHtml(prefix + d.text) + "</div>";
          })
          .join("");
        outputEl.innerHTML = html;
        statOut.textContent = added + " added, " + removed + " removed";
      }

      on($("tz-run"), "click", run);
      on($("tz-reset"), "click", function () {
        leftInput.value = "";
        rightInput.value = "";
        outputEl.innerHTML = "";
        statOut.textContent = "";
      });
    },
  };


  /* =====================================================================
     AUDIO & VOICE TOOLS (v10) — free, no API keys, runs in the browser.
     AI voices: Kokoro-82M (open-source neural TTS) via kokoro-js.
     AI transcription: Whisper (open-source) via Transformers.js.
     Both models download once from a public CDN / Hugging Face and are
     cached by the browser; nothing the user types or says is uploaded.
     ===================================================================== */

  const KOKORO_URL = "https://cdn.jsdelivr.net/npm/kokoro-js@1.2.0/dist/kokoro.web.js";
  const KOKORO_MODEL = "onnx-community/Kokoro-82M-v1.0-ONNX";
  const TRANSFORMERS_URL = "https://cdn.jsdelivr.net/npm/@huggingface/transformers@3.5.0";
  const TTS_WPM = 150;                 // average speaking pace
  const TTS_MAX_WORDS = 1500;          // 1,500 words ≈ 10 minutes of audio

  const KOKORO_VOICES = [
    ["af_heart", "Heart", "American English · Female"],
    ["af_bella", "Bella", "American English · Female"],
    ["af_nicole", "Nicole", "American English · Female"],
    ["af_sarah", "Sarah", "American English · Female"],
    ["af_sky", "Sky", "American English · Female"],
    ["af_nova", "Nova", "American English · Female"],
    ["af_river", "River", "American English · Female"],
    ["af_jessica", "Jessica", "American English · Female"],
    ["af_kore", "Kore", "American English · Female"],
    ["af_aoede", "Aoede", "American English · Female"],
    ["af_alloy", "Alloy", "American English · Female"],
    ["am_adam", "Adam", "American English · Male"],
    ["am_michael", "Michael", "American English · Male"],
    ["am_eric", "Eric", "American English · Male"],
    ["am_liam", "Liam", "American English · Male"],
    ["am_onyx", "Onyx", "American English · Male"],
    ["am_echo", "Echo", "American English · Male"],
    ["am_fenrir", "Fenrir", "American English · Male"],
    ["am_puck", "Puck", "American English · Male"],
    ["am_santa", "Santa", "American English · Male"],
    ["bf_emma", "Emma", "British English · Female"],
    ["bf_isabella", "Isabella", "British English · Female"],
    ["bf_alice", "Alice", "British English · Female"],
    ["bf_lily", "Lily", "British English · Female"],
    ["bm_george", "George", "British English · Male"],
    ["bm_lewis", "Lewis", "British English · Male"],
    ["bm_daniel", "Daniel", "British English · Male"],
    ["bm_fable", "Fable", "British English · Male"],
  ];

  function countWords(text) {
    const m = String(text || "").trim().match(/\S+/g);
    return m ? m.length : 0;
  }

  function trimToWords(text, max) {
    const re = /\S+/g;
    let m, n = 0;
    while ((m = re.exec(text)) !== null) {
      n++;
      if (n > max) return text.slice(0, m.index).replace(/\s+$/, "");
    }
    return text;
  }

  function fmtClock(totalSeconds) {
    const s = Math.max(0, Math.round(totalSeconds));
    return Math.floor(s / 60) + ":" + String(s % 60).padStart(2, "0");
  }

  // Splits text into sentence-sized chunks (long sentences are cut at commas/spaces).
  function splitIntoChunks(text, maxLen) {
    const parts = String(text).replace(/\r/g, "").match(/[^.!?\u3002\uff01\uff1f\n]+[.!?\u3002\uff01\uff1f]*["')\]]*\s*/g) || [String(text)];
    const chunks = [];
    let cur = "";
    parts.forEach(function (raw) {
      const p = raw.replace(/\s+/g, " ").trim();
      if (!p) return;
      if (p.length > maxLen) {
        if (cur) { chunks.push(cur); cur = ""; }
        let rest = p;
        while (rest.length > maxLen) {
          let cut = rest.lastIndexOf(", ", maxLen);
          if (cut < maxLen * 0.4) cut = rest.lastIndexOf(" ", maxLen);
          if (cut <= 0) cut = maxLen;
          chunks.push(rest.slice(0, cut + 1).trim());
          rest = rest.slice(cut + 1).trim();
        }
        cur = rest;
        return;
      }
      if (cur && (cur + " " + p).length > maxLen) { chunks.push(cur); cur = p; }
      else cur = cur ? cur + " " + p : p;
    });
    if (cur) chunks.push(cur);
    return chunks;
  }

  function encodeWav(samples, rate) {
    const buf = new ArrayBuffer(44 + samples.length * 2);
    const v = new DataView(buf);
    function w(o, s) { for (let i = 0; i < s.length; i++) v.setUint8(o + i, s.charCodeAt(i)); }
    w(0, "RIFF"); v.setUint32(4, 36 + samples.length * 2, true); w(8, "WAVE"); w(12, "fmt ");
    v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true);
    v.setUint32(24, rate, true); v.setUint32(28, rate * 2, true); v.setUint16(32, 2, true); v.setUint16(34, 16, true);
    w(36, "data"); v.setUint32(40, samples.length * 2, true);
    let o = 44;
    for (let i = 0; i < samples.length; i++, o += 2) {
      const s = Math.max(-1, Math.min(1, samples[i]));
      v.setInt16(o, s < 0 ? s * 0x8000 : s * 0x7fff, true);
    }
    return new Blob([buf], { type: "audio/wav" });
  }

  let kokoroPromise = null;
  function loadKokoro(onProgress) {
    if (!kokoroPromise) {
      kokoroPromise = import(KOKORO_URL).then(function (mod) {
        return mod.KokoroTTS.from_pretrained(KOKORO_MODEL, { dtype: "q8", device: "wasm", progress_callback: onProgress });
      });
      kokoroPromise.catch(function () { kokoroPromise = null; });
    }
    return kokoroPromise;
  }

  /* ============================================================= TEXT TO SPEECH */

  window.TZTools.textToSpeech = {
    init: function () {
      const input = $("tz-input");
      const engineSel = $("tz-engine");
      const voiceSel = $("tz-voice");
      const rate = $("tz-rate");
      const pitch = $("tz-pitch");
      const audioEl = $("tz-audio");
      const resultEl = $("tz-result");
      const runBtn = $("tz-run");
      const dlBtn = $("tz-download");
      let lastBlob = null;
      let cancelled = false;
      let busy = false;

      function updateStats() {
        const words = countWords(input.value);
        const speed = parseFloat(rate.value) || 1;
        $("tz-stat-words").textContent = words.toLocaleString() + " / " + TTS_MAX_WORDS.toLocaleString();
        $("tz-stat-chars").textContent = input.value.length.toLocaleString();
        $("tz-stat-time").textContent = words ? "~" + fmtClock((words / (TTS_WPM * speed)) * 60) : "0:00";
        $("tz-rate-out").textContent = speed.toFixed(2).replace(/0$/, "") + "\u00d7";
        $("tz-pitch-out").textContent = (parseFloat(pitch.value) || 1).toFixed(1);
      }

      function fillVoices() {
        const engine = engineSel.value;
        voiceSel.innerHTML = "";
        $("tz-pitch-wrap").style.display = engine === "system" ? "" : "none";
        if ($("tz-gallery-wrap")) $("tz-gallery-wrap").style.display = engine === "ai" ? "" : "none";
        dlBtn.style.display = "none";
        if (engine === "ai") {
          const groups = {};
          KOKORO_VOICES.forEach(function (v) {
            if (!groups[v[2]]) {
              groups[v[2]] = document.createElement("optgroup");
              groups[v[2]].label = v[2];
              voiceSel.appendChild(groups[v[2]]);
            }
            const o = document.createElement("option");
            o.value = v[0];
            o.textContent = v[1];
            groups[v[2]].appendChild(o);
          });
          return;
        }
        const list = ("speechSynthesis" in window) ? window.speechSynthesis.getVoices() : [];
        if (!list.length) {
          const o = document.createElement("option");
          o.textContent = "No device voices found";
          o.value = "";
          voiceSel.appendChild(o);
          return;
        }
        list.slice().sort(function (a, b) {
          return (a.lang + a.name).localeCompare(b.lang + b.name);
        }).forEach(function (v) {
          const o = document.createElement("option");
          o.value = v.voiceURI;
          o.textContent = v.name + " \u2014 " + v.lang;
          voiceSel.appendChild(o);
        });
        const en = Array.prototype.find.call(voiceSel.options, function (o) { return /\u2014 en[-_]/i.test(o.textContent); });
        if (en) voiceSel.value = en.value;
      }

      function setBusy(state) {
        busy = state;
        runBtn.disabled = state;
        $("tz-stop").disabled = !state;
      }

      function finish() { setBusy(false); setProgress(null); }

      /* ---- voice preview: hear a short sample before choosing ---- */
      const SAMPLE_BY_LANG = {
        en: "Hello! This is how my voice sounds. I hope you like it.",
        ja: "\u3053\u3093\u306b\u3061\u306f\u3002\u3053\u308c\u306f\u79c1\u306e\u58f0\u306e\u30b5\u30f3\u30d7\u30eb\u3067\u3059\u3002",
        fr: "Bonjour ! Voici \u00e0 quoi ressemble ma voix.",
        es: "\u00a1Hola! As\u00ed es como suena mi voz.",
        de: "Hallo! So klingt meine Stimme.",
        it: "Ciao! Ecco come suona la mia voce.",
        pt: "Ol\u00e1! Assim \u00e9 a minha voz.",
        hi: "\u0928\u092e\u0938\u094d\u0924\u0947! \u092f\u0939 \u092e\u0947\u0930\u0940 \u0906\u0935\u093e\u091c\u093c \u0915\u093e \u0928\u092e\u0942\u0928\u093e \u0939\u0948\u0964",
        ur: "\u0627\u0644\u0633\u0644\u0627\u0645 \u0639\u0644\u06cc\u06a9\u0645! \u06cc\u06c1 \u0645\u06cc\u0631\u06cc \u0622\u0648\u0627\u0632 \u06a9\u0627 \u0646\u0645\u0648\u0646\u06c1 \u06c1\u06d2\u06d4",
        ar: "\u0645\u0631\u062d\u0628\u0627\u064b! \u0647\u0630\u0627 \u0647\u0648 \u0635\u0648\u062a\u064a.",
        zh: "\u4f60\u597d\uff01\u8fd9\u5c31\u662f\u6211\u7684\u58f0\u97f3\u3002",
        ko: "\uc548\ub155\ud558\uc138\uc694! \uc774\uac83\uc774 \uc81c \ubaa9\uc18c\ub9ac\uc785\ub2c8\ub2e4.",
        ru: "\u041f\u0440\u0438\u0432\u0435\u0442! \u0412\u043e\u0442 \u0442\u0430\u043a \u0437\u0432\u0443\u0447\u0438\u0442 \u043c\u043e\u0439 \u0433\u043e\u043b\u043e\u0441.",
      };
      const previewCache = {};            // AI voice id -> object URL of the sample audio
      let previewAudio = null;
      let previewBusy = false;

      function stopPreview() {
        if (previewAudio) { previewAudio.pause(); previewAudio = null; }
        if ("speechSynthesis" in window) window.speechSynthesis.cancel();
        document.querySelectorAll("[data-preview]").forEach(function (b) { b.classList.remove("is-playing"); });
      }

      async function previewVoice(voiceId, label) {
        if (previewBusy) return;
        stopPreview();
        if (engineSel.value === "system") {
          if (!("speechSynthesis" in window)) { TZ.showToast("This browser doesn\u2019t support device voices"); return; }
          const v = window.speechSynthesis.getVoices().find(function (x) { return x.voiceURI === voiceId; });
          const lang = v ? v.lang.slice(0, 2).toLowerCase() : "en";
          const u = new SpeechSynthesisUtterance(SAMPLE_BY_LANG[lang] || SAMPLE_BY_LANG.en);
          if (v) { u.voice = v; u.lang = v.lang; }
          u.rate = parseFloat(rate.value) || 1;
          u.pitch = parseFloat(pitch.value) || 1;
          window.speechSynthesis.speak(u);
          return;
        }
        previewBusy = true;
        const msg = $("tz-preview-msg");
        try {
          if (!previewCache[voiceId]) {
            msg.textContent = "Loading the AI voice engine (first time only)\u2026";
            const tts = await loadKokoro(function (p) {
              if (p && p.status === "progress" && typeof p.progress === "number") msg.textContent = "Downloading the voice model\u2026 " + Math.round(p.progress) + "%";
            });
            msg.textContent = "Creating a sample of " + label + "\u2026";
            const out = await tts.generate("Hi, I\u2019m " + label + ". This is how I sound when I read your text aloud.", { voice: voiceId, speed: 1 });
            previewCache[voiceId] = URL.createObjectURL(encodeWav(out.audio, out.sampling_rate || 24000));
          }
          msg.textContent = "Playing " + label;
          previewAudio = new Audio(previewCache[voiceId]);
          previewAudio.onended = function () { msg.textContent = ""; stopPreview(); };
          await previewAudio.play();
        } catch (err) {
          msg.textContent = "Couldn\u2019t load the AI voice. Check your internet connection and try again.";
        }
        previewBusy = false;
      }

      function buildGallery() {
        const box = $("tz-gallery");
        if (!box) return;
        box.innerHTML = KOKORO_VOICES.map(function (v) {
          return '<div class="tz-voice-card"><div><strong>' + v[1] + "</strong><span>" + v[2] + "</span></div>" +
            '<div class="tz-voice-actions"><button type="button" class="btn btn-outline btn-sm" data-preview="' + v[0] + '" data-name="' + v[1] + '" aria-label="Play a sample of ' + v[1] + '">' + tzIcon("play") + "<span>Play</span></button>" +
            '<button type="button" class="btn btn-primary btn-sm" data-use="' + v[0] + '">Use</button></div></div>';
        }).join("");
      }
      on($("tz-gallery"), "click", function (e) {
        const p = e.target.closest("[data-preview]");
        const u = e.target.closest("[data-use]");
        if (p) { engineSel.value = "ai"; previewVoice(p.getAttribute("data-preview"), p.getAttribute("data-name")); }
        if (u) { voiceSel.value = u.getAttribute("data-use"); document.querySelectorAll("[data-use]").forEach(function (b) { b.textContent = "Use"; }); u.textContent = "Selected"; TZ.showToast("Voice selected"); }
      });
      on($("tz-preview"), "click", function () {
        if (!voiceSel.value) { TZ.showToast("No voice to preview"); return; }
        const label = voiceSel.options[voiceSel.selectedIndex].textContent.split(" \u2014 ")[0];
        previewVoice(voiceSel.value, label);
      });
      on(voiceSel, "change", stopPreview);

      async function runAi(text) {
        const chunks = splitIntoChunks(text, 300);
        showResult(resultEl, "Loading the AI voice engine\u2026 the first time this downloads a voice model (about 90 MB) and keeps it for next time.");
        let tts;
        try {
          tts = await loadKokoro(function (p) {
            if (p && p.status === "progress" && typeof p.progress === "number") {
              setProgress(p.progress);
              showResult(resultEl, "Downloading the voice model\u2026 " + Math.round(p.progress) + "%");
            }
          });
        } catch (err) {
          showResult(resultEl, "The AI voice engine couldn\u2019t load. " + libMissingMessage("the AI voice model") + " You can also switch to \u201cYour device voices\u201d, which work instantly.", "error");
          finish();
          return;
        }
        const parts = [];
        let sampleRate = 24000;
        const speed = parseFloat(rate.value) || 1;
        for (let i = 0; i < chunks.length; i++) {
          if (cancelled) break;
          showResult(resultEl, "Creating speech\u2026 part " + (i + 1) + " of " + chunks.length);
          setProgress(((i + 0.2) / chunks.length) * 100);
          try {
            const out = await tts.generate(chunks[i], { voice: voiceSel.value, speed: speed });
            parts.push(out.audio);
            sampleRate = out.sampling_rate || sampleRate;
          } catch (err) {
            showResult(resultEl, "Something went wrong while creating the audio. Try a shorter text or another voice.", "error");
            finish();
            return;
          }
          setProgress(((i + 1) / chunks.length) * 100);
        }
        if (cancelled || !parts.length) { resultEl.style.display = "none"; finish(); return; }
        let total = 0;
        parts.forEach(function (p) { total += p.length; });
        const merged = new Float32Array(total);
        let offset = 0;
        parts.forEach(function (p) { merged.set(p, offset); offset += p.length; });
        lastBlob = encodeWav(merged, sampleRate);
        if (audioEl.dataset.url) URL.revokeObjectURL(audioEl.dataset.url);
        audioEl.dataset.url = URL.createObjectURL(lastBlob);
        audioEl.src = audioEl.dataset.url;
        audioEl.style.display = "block";
        dlBtn.style.display = "";
        showResult(resultEl, "Done \u2014 " + fmtClock(total / sampleRate) + " of audio. Press play, or download it as a WAV file.", "success");
        finish();
        audioEl.play().catch(function () {});
      }

      function runSystem(text) {
        if (!("speechSynthesis" in window)) {
          showResult(resultEl, "This browser doesn\u2019t support device voices. Switch to AI neural voices instead.", "error");
          finish();
          return;
        }
        const synth = window.speechSynthesis;
        synth.cancel();
        const voice = synth.getVoices().find(function (v) { return v.voiceURI === voiceSel.value; });
        const chunks = splitIntoChunks(text, 200);
        let i = 0;
        showResult(resultEl, "Speaking with your device voice\u2026 (device voices can\u2019t be saved as a file \u2014 use AI neural voices to download audio).");
        function next() {
          if (cancelled || i >= chunks.length) {
            if (!cancelled) showResult(resultEl, "Finished speaking.", "success");
            finish();
            return;
          }
          const u = new SpeechSynthesisUtterance(chunks[i]);
          if (voice) { u.voice = voice; u.lang = voice.lang; }
          u.rate = parseFloat(rate.value) || 1;
          u.pitch = parseFloat(pitch.value) || 1;
          u.onend = function () { i++; setProgress((i / chunks.length) * 100); next(); };
          u.onerror = function () { i++; next(); };
          synth.speak(u);
        }
        next();
      }

      on(input, "input", function () {
        if (countWords(input.value) > TTS_MAX_WORDS) {
          input.value = trimToWords(input.value, TTS_MAX_WORDS);
          TZ.showToast("Limit reached: 1,500 words (about 10 minutes of audio)");
        }
        updateStats();
      });
      on(rate, "input", updateStats);
      on(pitch, "input", updateStats);
      on(engineSel, "change", fillVoices);
      if ("speechSynthesis" in window) window.speechSynthesis.onvoiceschanged = function () { if (engineSel.value === "system") fillVoices(); };

      on(runBtn, "click", function () {
        const text = input.value.trim();
        if (!text) { TZ.showToast("Type or paste some text first"); return; }
        cancelled = false;
        stopPreview();
        setBusy(true);
        setProgress(0);
        audioEl.pause();
        if (engineSel.value === "ai") runAi(text); else runSystem(text);
      });
      on($("tz-stop"), "click", function () {
        cancelled = true;
        if ("speechSynthesis" in window) window.speechSynthesis.cancel();
        audioEl.pause();
        resultEl.style.display = "none";
        finish();
      });
      on(dlBtn, "click", function () {
        if (lastBlob) TZ.downloadBlob(lastBlob, "toolzihub-speech.wav");
      });
      on($("tz-reset"), "click", function () {
        cancelled = true;
        if ("speechSynthesis" in window) window.speechSynthesis.cancel();
        audioEl.pause();
        audioEl.style.display = "none";
        resultEl.style.display = "none";
        input.value = "";
        lastBlob = null;
        dlBtn.style.display = "none";
        finish();
        updateStats();
      });

      buildGallery();
      fillVoices();
      updateStats();
      setBusy(false);
    },
  };

  /* ============================================================= SPEECH TO TEXT */

  window.TZTools.speechToText = {
    init: function () {
      const WHISPER_LANGS = {
        "en-US": "english", "en-GB": "english", "en-CA": "english", "fr-CA": "french", "ja-JP": "japanese",
        "es-ES": "spanish", "de-DE": "german", "hi-IN": "hindi", "ur-PK": "urdu", "ar-SA": "arabic",
      };
      const out = $("tz-output");
      const langSel = $("tz-lang");
      const resultEl = $("tz-result");
      const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
      let recog = null;
      let listening = false;
      let finalText = "";
      let asrPromise = null;
      let asrModelId = "";
      let file = null;

      function updateCount() {
        $("tz-stat-words").textContent = countWords(out.value).toLocaleString();
        $("tz-stat-chars").textContent = out.value.length.toLocaleString();
      }

      function switchMode() {
        const mode = $("tz-mode").value;
        $("tz-panel-mic").style.display = mode === "mic" ? "" : "none";
        $("tz-panel-file").style.display = mode === "file" ? "" : "none";
        resultEl.style.display = "none";
      }

      /* ---- live microphone ---- */
      function stopListening() {
        listening = false;
        if (recog) { try { recog.stop(); } catch (e) {} }
        $("tz-start").disabled = false;
        $("tz-stop").disabled = true;
        $("tz-mic-status").textContent = "Stopped";
      }

      function startListening() {
        if (!SR) {
          showResult(resultEl, "This browser doesn\u2019t support live speech recognition. Try Chrome, Edge or Safari \u2014 or use the \u201cAudio file (AI)\u201d option, which works in any modern browser.", "error");
          return;
        }
        finalText = out.value ? out.value.replace(/\s+$/, "") + " " : "";
        recog = new SR();
        recog.continuous = true;
        recog.interimResults = true;
        recog.lang = langSel.value;
        recog.onresult = function (e) {
          let interim = "";
          for (let i = e.resultIndex; i < e.results.length; i++) {
            const t = e.results[i][0].transcript;
            if (e.results[i].isFinal) finalText += t + " "; else interim += t;
          }
          out.value = finalText + interim;
          updateCount();
        };
        recog.onerror = function (e) {
          if (e.error === "no-speech" || e.error === "aborted") return;
          const msg = e.error === "not-allowed" || e.error === "service-not-allowed"
            ? "Microphone access was blocked. Allow the microphone for this site and try again."
            : "Speech recognition stopped (" + e.error + "). Check your connection and try again.";
          showResult(resultEl, msg, "error");
          stopListening();
        };
        recog.onend = function () {
          if (listening) { try { recog.lang = langSel.value; recog.start(); } catch (e) {} }
        };
        try {
          recog.start();
          listening = true;
          resultEl.style.display = "none";
          $("tz-start").disabled = true;
          $("tz-stop").disabled = false;
          $("tz-mic-status").textContent = "Listening\u2026 speak now";
        } catch (e) {
          showResult(resultEl, "Couldn\u2019t start the microphone. Please try again.", "error");
        }
      }

      /* ---- audio file with Whisper AI ---- */
      function loadWhisper(modelId) {
        if (asrPromise && asrModelId === modelId) return asrPromise;
        asrModelId = modelId;
        asrPromise = import(TRANSFORMERS_URL).then(function (mod) {
          return mod.pipeline("automatic-speech-recognition", modelId, {
            dtype: "q8",
            device: "wasm",
            progress_callback: function (p) {
              if (p && p.status === "progress" && typeof p.progress === "number") {
                setProgress(p.progress);
                showResult(resultEl, "Downloading the AI model\u2026 " + Math.round(p.progress) + "%");
              }
            },
          });
        });
        asrPromise.catch(function () { asrPromise = null; });
        return asrPromise;
      }

      async function decodeTo16kMono(f) {
        const Ctx = window.AudioContext || window.webkitAudioContext;
        const ctx = new Ctx({ sampleRate: 16000 });
        const buf = await ctx.decodeAudioData(await fileToArrayBuffer(f));
        const ch = buf.numberOfChannels;
        const data = new Float32Array(buf.length);
        for (let c = 0; c < ch; c++) {
          const d = buf.getChannelData(c);
          for (let i = 0; i < d.length; i++) data[i] += d[i] / ch;
        }
        try { ctx.close(); } catch (e) {}
        return data;
      }

      const upload = setupSingleUpload({
        iconKey: "mic",
        onFile: function (f) { file = f; $("tz-transcribe").disabled = !f; },
      });

      on($("tz-transcribe"), "click", async function () {
        if (!file) { TZ.showToast("Choose an audio file first"); return; }
        const btn = $("tz-transcribe");
        setBtnLoading(btn, true, "Working\u2026");
        setProgress(0);
        try {
          showResult(resultEl, "Reading your audio file\u2026");
          const audio = await decodeTo16kMono(file);
          const asr = await loadWhisper($("tz-model").value);
          showResult(resultEl, "Listening to the audio and writing it down\u2026 longer files take longer.");
          setProgress(null);
          const lang = WHISPER_LANGS[langSel.value] || "english";
          const res = await asr(audio, { language: lang, task: "transcribe", chunk_length_s: 30, stride_length_s: 5 });
          const text = (res && res.text ? res.text : "").trim();
          out.value = (out.value ? out.value.replace(/\s+$/, "") + "\n\n" : "") + text;
          updateCount();
          showResult(resultEl, text ? "Done \u2014 the transcript is in the box below." : "No speech was found in that file.", text ? "success" : "error");
        } catch (err) {
          showResult(resultEl, "Couldn\u2019t transcribe that file. " + libMissingMessage("the AI speech model") + " Make sure the file is a valid audio or video file.", "error");
        }
        setProgress(null);
        setBtnLoading(btn, false);
      });

      on($("tz-mode"), "change", function () { if (listening) stopListening(); switchMode(); });
      on(langSel, "change", function () { if (listening) { try { recog.stop(); } catch (e) {} } });
      on($("tz-start"), "click", startListening);
      on($("tz-stop"), "click", stopListening);
      on(out, "input", updateCount);
      on($("tz-copy"), "click", function () {
        if (!out.value) return;
        TZ.copyToClipboard(out.value, "Transcript copied");
      });
      on($("tz-download-txt"), "click", function () {
        if (!out.value) return;
        TZ.downloadText(out.value, "toolzihub-transcript.txt", "text/plain");
      });
      on($("tz-reset"), "click", function () {
        if (listening) stopListening();
        out.value = "";
        finalText = "";
        upload.clear();
        file = null;
        $("tz-transcribe").disabled = true;
        resultEl.style.display = "none";
        updateCount();
      });

      $("tz-stop").disabled = true;
      $("tz-transcribe").disabled = true;
      switchMode();
      updateCount();
    },
  };


  /* =====================================================================
     v11 — shared helpers for the new tools
     ===================================================================== */

  function setupMultiUpload(opts) {
    const zone = $(opts.zoneId || "tz-upload-zone");
    const input = $(opts.inputId || "tz-file-input");
    if (!zone || !input) return;
    function handle(list) {
      const arr = Array.prototype.slice.call(list || []);
      if (arr.length && opts.onFiles) opts.onFiles(arr);
    }
    on(zone, "click", function () { input.click(); });
    on(zone, "keydown", function (e) {
      if (e.key === "Enter" || e.key === " ") { e.preventDefault(); input.click(); }
    });
    on(input, "change", function () { handle(input.files); input.value = ""; });
    ["dragenter", "dragover"].forEach(function (ev) {
      on(zone, ev, function (e) { e.preventDefault(); zone.classList.add("dragover"); });
    });
    ["dragleave", "drop"].forEach(function (ev) {
      on(zone, ev, function (e) { e.preventDefault(); zone.classList.remove("dragover"); });
    });
    on(zone, "drop", function (e) { handle(e.dataTransfer && e.dataTransfer.files); });
  }

  function baseName(name) { return String(name || "file").replace(/\.[^.]+$/, ""); }

  function canvasToBlob(canvas, type, quality) {
    return new Promise(function (resolve) { canvas.toBlob(resolve, type, quality); });
  }

  // "1-3, 5, 8-" -> [1,2,3,5,8,...total]; throws a friendly Error on bad input.
  function parsePageSpec(spec, total) {
    const out = [];
    String(spec || "").split(",").forEach(function (raw) {
      const part = raw.trim();
      if (!part) return;
      const m = part.match(/^(\d*)\s*-\s*(\d*)$/);
      if (m && (m[1] || m[2])) {
        let a = m[1] ? parseInt(m[1], 10) : 1;
        let b = m[2] ? parseInt(m[2], 10) : total;
        if (a > b) { const t = a; a = b; b = t; }
        if (a < 1 || b > total) throw new Error("Pages must be between 1 and " + total + ".");
        for (let p = a; p <= b; p++) out.push(p);
      } else if (/^\d+$/.test(part)) {
        const p = parseInt(part, 10);
        if (p < 1 || p > total) throw new Error("Page " + p + " is outside this PDF (1\u2013" + total + ").");
        out.push(p);
      } else {
        throw new Error("Couldn\u2019t understand \u201c" + part + "\u201d. Use page numbers and ranges like 1-3, 5, 8-");
      }
    });
    return out;
  }

  async function loadPdfLibDoc(file) {
    const bytes = await fileToArrayBuffer(file);
    return PDFLib.PDFDocument.load(bytes, { ignoreEncryption: true });
  }

  function downloadPdfBytes(bytes, name) {
    TZ.downloadBlob(new Blob([bytes], { type: "application/pdf" }), name);
  }

  function fillCurrencySelect(sel, def) {
    if (!sel) return;
    sel.innerHTML = "";
    const popular = document.createElement("optgroup");
    popular.label = "Popular";
    const all = document.createElement("optgroup");
    all.label = "All currencies (A\u2013Z)";
    const opt = function (c) {
      const o = document.createElement("option");
      o.value = c;
      o.textContent = c + " \u2014 " + currencyName(c);
      return o;
    };
    TZ_POPULAR_CURRENCIES.forEach(function (c) { popular.appendChild(opt(c)); });
    TZ_CURRENCY_CODES.slice().sort().forEach(function (c) { all.appendChild(opt(c)); });
    sel.appendChild(popular);
    sel.appendChild(all);
    sel.value = def || "USD";
  }

  function numVal(id, fallback) {
    const el = $(id);
    const v = el ? parseFloat(el.value) : NaN;
    return isNaN(v) ? (fallback == null ? 0 : fallback) : v;
  }

  /* ============================================================= SPLIT PDF */

  window.TZTools.splitPdf = {
    init: function () {
      const resultEl = $("tz-result");
      const modeSel = $("tz-mode");
      let file = null;
      let total = 0;

      const upload = setupSingleUpload({
        iconKey: "file-text",
        onFile: async function (f) {
          file = f;
          total = 0;
          $("tz-page-info").textContent = "";
          if (!f) return;
          if (typeof PDFLib === "undefined") { TZ.showToast(libMissingMessage("the PDF engine")); return; }
          try {
            const doc = await loadPdfLibDoc(f);
            total = doc.getPageCount();
            $("tz-page-info").textContent = "This PDF has " + total + " page" + (total === 1 ? "" : "s") + ".";
          } catch (e) { showResult(resultEl, "Couldn\u2019t read that PDF. It may be damaged or password-protected.", "error"); }
        },
      });

      function syncMode() { $("tz-ranges-wrap").style.display = modeSel.value === "ranges" ? "" : "none"; }
      on(modeSel, "change", syncMode);
      syncMode();

      on($("tz-run"), "click", async function () {
        if (!file) { TZ.showToast("Upload a PDF first"); return; }
        if (typeof PDFLib === "undefined" || typeof JSZip === "undefined") { TZ.showToast(libMissingMessage("the PDF engine")); return; }
        const btn = $("tz-run");
        setBtnLoading(btn, true, "Splitting\u2026");
        setProgress(5);
        try {
          const src = await loadPdfLibDoc(file);
          total = src.getPageCount();
          let groups = [];
          if (modeSel.value === "every") {
            for (let i = 1; i <= total; i++) groups.push([i]);
          } else {
            const spec = $("tz-ranges").value;
            if (!spec.trim()) throw new Error("Enter the page ranges you want, for example 1-3, 4-6, 7-");
            spec.split(",").forEach(function (part) {
              const pages = parsePageSpec(part, total);
              if (pages.length) groups.push(pages);
            });
          }
          if (!groups.length) throw new Error("No pages selected.");
          const name = baseName(file.name);
          const outputs = [];
          for (let g = 0; g < groups.length; g++) {
            const out = await PDFLib.PDFDocument.create();
            const copied = await out.copyPages(src, groups[g].map(function (p) { return p - 1; }));
            copied.forEach(function (p) { out.addPage(p); });
            const label = modeSel.value === "every" ? "page-" + groups[g][0] : "part-" + (g + 1);
            outputs.push({ name: name + "-" + label + ".pdf", bytes: await out.save() });
            setProgress(5 + ((g + 1) / groups.length) * 90);
          }
          if (outputs.length === 1) {
            downloadPdfBytes(outputs[0].bytes, outputs[0].name);
          } else {
            const zip = new JSZip();
            outputs.forEach(function (o) { zip.file(o.name, o.bytes); });
            TZ.downloadBlob(await zip.generateAsync({ type: "blob" }), name + "-split.zip");
          }
          showResult(resultEl, "Done \u2014 " + outputs.length + " PDF file" + (outputs.length === 1 ? "" : "s") + " created" + (outputs.length > 1 ? " and bundled in a ZIP." : "."), "success");
        } catch (err) {
          showResult(resultEl, TZ.escapeHtml(err && err.message ? err.message : "Couldn\u2019t split that PDF."), "error");
        }
        setProgress(null);
        setBtnLoading(btn, false);
      });
      on($("tz-reset"), "click", function () {
        upload.clear(); file = null; total = 0;
        $("tz-page-info").textContent = "";
        $("tz-ranges").value = "";
        resultEl.style.display = "none";
      });
    },
  };

  /* ============================================================= IMAGES TO PDF */

  window.TZTools.imagesToPdf = {
    init: function () {
      const listEl = $("tz-file-list");
      const resultEl = $("tz-result");
      let files = [];

      function render() {
        listEl.innerHTML = files.map(function (f, i) {
          return '<div class="file-chip">' + tzIcon("image") +
            '<span class="name">' + (i + 1) + ". " + TZ.escapeHtml(f.name) + " \u00b7 " + TZ.formatBytes(f.size) + "</span>" +
            '<button type="button" data-act="up" data-i="' + i + '" aria-label="Move up"' + (i === 0 ? " disabled" : "") + ">" + tzIcon("chevron-up") + "</button>" +
            '<button type="button" data-act="down" data-i="' + i + '" aria-label="Move down"' + (i === files.length - 1 ? " disabled" : "") + ">" + tzIcon("chevron-down") + "</button>" +
            '<button type="button" data-act="remove" data-i="' + i + '" aria-label="Remove">' + tzIcon("close") + "</button></div>";
        }).join("");
      }
      on(listEl, "click", function (e) {
        const btn = e.target.closest("button[data-act]");
        if (!btn) return;
        const i = parseInt(btn.getAttribute("data-i"), 10);
        const act = btn.getAttribute("data-act");
        if (act === "remove") files.splice(i, 1);
        if (act === "up" && i > 0) { const t = files[i - 1]; files[i - 1] = files[i]; files[i] = t; }
        if (act === "down" && i < files.length - 1) { const t = files[i + 1]; files[i + 1] = files[i]; files[i] = t; }
        render();
      });
      setupMultiUpload({
        onFiles: function (list) {
          list.forEach(function (f) { if (/^image\//.test(f.type) || /\.(jpe?g|png|webp|gif|bmp)$/i.test(f.name)) files.push(f); });
          render();
        },
      });

      async function toEmbeddable(pdf, f) {
        const isJpg = /jpe?g/i.test(f.type) || /\.jpe?g$/i.test(f.name);
        const isPng = /png/i.test(f.type) || /\.png$/i.test(f.name);
        if (isJpg) return pdf.embedJpg(await fileToArrayBuffer(f));
        if (isPng) return pdf.embedPng(await fileToArrayBuffer(f));
        const img = await loadImage(await fileToDataUrl(f));
        const c = document.createElement("canvas");
        c.width = img.naturalWidth; c.height = img.naturalHeight;
        c.getContext("2d").drawImage(img, 0, 0);
        const blob = await canvasToBlob(c, "image/png");
        return pdf.embedPng(await blob.arrayBuffer());
      }

      on($("tz-run"), "click", async function () {
        if (!files.length) { TZ.showToast("Add at least one image"); return; }
        if (typeof PDFLib === "undefined") { TZ.showToast(libMissingMessage("the PDF engine")); return; }
        const btn = $("tz-run");
        setBtnLoading(btn, true, "Creating PDF\u2026");
        setProgress(5);
        try {
          const pdf = await PDFLib.PDFDocument.create();
          const size = $("tz-size").value;
          const marginPt = { none: 0, small: 20, medium: 40 }[$("tz-margin").value] || 0;
          for (let i = 0; i < files.length; i++) {
            const img = await toEmbeddable(pdf, files[i]);
            const iw = img.width, ih = img.height;
            if (size === "fit") {
              const page = pdf.addPage([iw * 0.75 + marginPt * 2, ih * 0.75 + marginPt * 2]);
              page.drawImage(img, { x: marginPt, y: marginPt, width: iw * 0.75, height: ih * 0.75 });
            } else {
              let pw = size === "letter" ? 612 : 595.28, ph = size === "letter" ? 792 : 841.89;
              if (iw > ih) { const t = pw; pw = ph; ph = t; }
              const page = pdf.addPage([pw, ph]);
              const scale = Math.min((pw - marginPt * 2) / iw, (ph - marginPt * 2) / ih);
              const w = iw * scale, h = ih * scale;
              page.drawImage(img, { x: (pw - w) / 2, y: (ph - h) / 2, width: w, height: h });
            }
            setProgress(5 + ((i + 1) / files.length) * 90);
          }
          downloadPdfBytes(await pdf.save(), "images.pdf");
          showResult(resultEl, "Done \u2014 your PDF with " + files.length + " page" + (files.length === 1 ? "" : "s") + " was downloaded.", "success");
        } catch (err) {
          showResult(resultEl, "Couldn\u2019t build the PDF. Check that every file is a valid image.", "error");
        }
        setProgress(null);
        setBtnLoading(btn, false);
      });
      on($("tz-reset"), "click", function () { files = []; render(); resultEl.style.display = "none"; });
    },
  };

  /* ============================================================= PDF TO IMAGES */

  window.TZTools.pdfToImages = {
    init: function () {
      const resultEl = $("tz-result");
      const gallery = $("tz-gallery");
      let file = null;
      let made = [];

      const upload = setupSingleUpload({ iconKey: "file-text", onFile: function (f) { file = f; } });

      on($("tz-run"), "click", async function () {
        if (!file) { TZ.showToast("Upload a PDF first"); return; }
        if (!ensurePdfJs()) { TZ.showToast(libMissingMessage("the PDF reader")); return; }
        const btn = $("tz-run");
        setBtnLoading(btn, true, "Converting\u2026");
        setProgress(3);
        gallery.innerHTML = "";
        made = [];
        try {
          const data = new Uint8Array(await fileToArrayBuffer(file));
          const doc = await window.pdfjsLib.getDocument({ data: data }).promise;
          const scale = parseFloat($("tz-scale").value) || 2;
          const type = $("tz-format").value;
          const ext = type === "image/png" ? "png" : "jpg";
          const name = baseName(file.name);
          const limit = Math.min(doc.numPages, 100);
          for (let p = 1; p <= limit; p++) {
            const page = await doc.getPage(p);
            const vp = page.getViewport({ scale: scale });
            const c = document.createElement("canvas");
            c.width = Math.floor(vp.width); c.height = Math.floor(vp.height);
            const ctx = c.getContext("2d");
            ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, c.width, c.height);
            await page.render({ canvasContext: ctx, viewport: vp }).promise;
            const blob = await canvasToBlob(c, type, 0.92);
            const fname = name + "-page-" + p + "." + ext;
            made.push({ name: fname, blob: blob });
            const url = URL.createObjectURL(blob);
            const cell = document.createElement("div");
            cell.style.cssText = "text-align:center;";
            cell.innerHTML = '<img src="' + url + '" alt="Page ' + p + '" style="width:100%;border:1px solid var(--border-soft);border-radius:8px;"><a class="btn btn-outline btn-sm" style="margin-top:8px;" href="' + url + '" download="' + fname + '">Page ' + p + "</a>";
            gallery.appendChild(cell);
            setProgress(3 + (p / limit) * 94);
          }
          $("tz-zip").style.display = made.length > 1 ? "" : "none";
          showResult(resultEl, "Done \u2014 " + made.length + " image" + (made.length === 1 ? "" : "s") + " created" + (doc.numPages > limit ? " (first 100 pages)" : "") + ".", "success");
        } catch (err) {
          showResult(resultEl, "Couldn\u2019t convert that PDF. It may be damaged or password-protected.", "error");
        }
        setProgress(null);
        setBtnLoading(btn, false);
      });
      on($("tz-zip"), "click", async function () {
        if (typeof JSZip === "undefined" || !made.length) return;
        const zip = new JSZip();
        made.forEach(function (m) { zip.file(m.name, m.blob); });
        TZ.downloadBlob(await zip.generateAsync({ type: "blob" }), baseName(file.name) + "-images.zip");
      });
      on($("tz-reset"), "click", function () { upload.clear(); file = null; made = []; gallery.innerHTML = ""; $("tz-zip").style.display = "none"; resultEl.style.display = "none"; });
      $("tz-zip").style.display = "none";
    },
  };

  /* ============================================================= ROTATE PDF */

  window.TZTools.rotatePdf = {
    init: function () {
      const resultEl = $("tz-result");
      let file = null;
      const upload = setupSingleUpload({
        iconKey: "file-text",
        onFile: async function (f) {
          file = f;
          $("tz-page-info").textContent = "";
          if (f && typeof PDFLib !== "undefined") {
            try { const d = await loadPdfLibDoc(f); $("tz-page-info").textContent = "This PDF has " + d.getPageCount() + " pages."; } catch (e) {}
          }
        },
      });
      on($("tz-run"), "click", async function () {
        if (!file) { TZ.showToast("Upload a PDF first"); return; }
        if (typeof PDFLib === "undefined") { TZ.showToast(libMissingMessage("the PDF engine")); return; }
        const btn = $("tz-run");
        setBtnLoading(btn, true, "Rotating\u2026");
        try {
          const doc = await loadPdfLibDoc(file);
          const total = doc.getPageCount();
          const spec = $("tz-pages").value.trim();
          const pages = spec ? parsePageSpec(spec, total) : Array.from({ length: total }, function (_, i) { return i + 1; });
          const angle = parseInt($("tz-angle").value, 10) || 90;
          pages.forEach(function (n) {
            const page = doc.getPage(n - 1);
            page.setRotation(PDFLib.degrees((page.getRotation().angle + angle + 360) % 360));
          });
          downloadPdfBytes(await doc.save(), baseName(file.name) + "-rotated.pdf");
          showResult(resultEl, "Done \u2014 " + pages.length + " page" + (pages.length === 1 ? "" : "s") + " rotated.", "success");
        } catch (err) {
          showResult(resultEl, TZ.escapeHtml(err && err.message ? err.message : "Couldn\u2019t rotate that PDF."), "error");
        }
        setBtnLoading(btn, false);
      });
      on($("tz-reset"), "click", function () { upload.clear(); file = null; $("tz-pages").value = ""; $("tz-page-info").textContent = ""; resultEl.style.display = "none"; });
    },
  };

  /* ============================================================= ORGANIZE PDF PAGES */

  window.TZTools.organizePdf = {
    init: function () {
      const resultEl = $("tz-result");
      let file = null;
      const upload = setupSingleUpload({
        iconKey: "file-text",
        onFile: async function (f) {
          file = f;
          $("tz-page-info").textContent = "";
          if (f && typeof PDFLib !== "undefined") {
            try { const d = await loadPdfLibDoc(f); $("tz-page-info").textContent = "This PDF has " + d.getPageCount() + " pages."; } catch (e) {}
          }
        },
      });
      on($("tz-run"), "click", async function () {
        if (!file) { TZ.showToast("Upload a PDF first"); return; }
        if (typeof PDFLib === "undefined") { TZ.showToast(libMissingMessage("the PDF engine")); return; }
        const btn = $("tz-run");
        setBtnLoading(btn, true, "Working\u2026");
        try {
          const src = await loadPdfLibDoc(file);
          const total = src.getPageCount();
          const spec = $("tz-pages").value.trim();
          if (!spec) throw new Error("Enter the page numbers first, for example 3, 1, 2, 5-7");
          const picked = parsePageSpec(spec, total);
          let order;
          if ($("tz-mode").value === "delete") {
            const drop = {};
            picked.forEach(function (p) { drop[p] = true; });
            order = [];
            for (let p = 1; p <= total; p++) if (!drop[p]) order.push(p);
          } else {
            order = picked;
          }
          if (!order.length) throw new Error("That would leave the PDF with no pages.");
          const out = await PDFLib.PDFDocument.create();
          const copied = await out.copyPages(src, order.map(function (p) { return p - 1; }));
          copied.forEach(function (p) { out.addPage(p); });
          downloadPdfBytes(await out.save(), baseName(file.name) + "-edited.pdf");
          showResult(resultEl, "Done \u2014 the new PDF has " + order.length + " page" + (order.length === 1 ? "" : "s") + ".", "success");
        } catch (err) {
          showResult(resultEl, TZ.escapeHtml(err && err.message ? err.message : "Couldn\u2019t edit that PDF."), "error");
        }
        setBtnLoading(btn, false);
      });
      on($("tz-reset"), "click", function () { upload.clear(); file = null; $("tz-pages").value = ""; $("tz-page-info").textContent = ""; resultEl.style.display = "none"; });
    },
  };

  /* ============================================================= PDF WATERMARK */

  window.TZTools.pdfWatermark = {
    init: function () {
      const resultEl = $("tz-result");
      let file = null;
      const upload = setupSingleUpload({ iconKey: "file-text", onFile: function (f) { file = f; } });
      const colors = { gray: [0.5, 0.5, 0.5], red: [0.85, 0.1, 0.1], blue: [0.1, 0.35, 0.85], black: [0, 0, 0] };

      function syncOut() {
        $("tz-size-out").textContent = $("tz-size").value + " pt";
        $("tz-opacity-out").textContent = Math.round(parseFloat($("tz-opacity").value) * 100) + "%";
      }
      on($("tz-size"), "input", syncOut);
      on($("tz-opacity"), "input", syncOut);
      syncOut();

      on($("tz-run"), "click", async function () {
        if (!file) { TZ.showToast("Upload a PDF first"); return; }
        const text = $("tz-text").value.trim();
        if (!text) { TZ.showToast("Type the watermark text"); return; }
        if (typeof PDFLib === "undefined") { TZ.showToast(libMissingMessage("the PDF engine")); return; }
        const btn = $("tz-run");
        setBtnLoading(btn, true, "Adding watermark\u2026");
        try {
          const doc = await loadPdfLibDoc(file);
          const font = await doc.embedFont(PDFLib.StandardFonts.HelveticaBold);
          const size = parseInt($("tz-size").value, 10) || 60;
          const opacity = parseFloat($("tz-opacity").value) || 0.25;
          const angle = parseInt($("tz-rotation").value, 10) || 0;
          const c = colors[$("tz-color").value] || colors.gray;
          const tile = $("tz-layout").value === "tile";
          const rad = angle * Math.PI / 180;
          const tw = font.widthOfTextAtSize(text, size);
          const th = size * 0.7;
          doc.getPages().forEach(function (page) {
            const pw = page.getWidth(), ph = page.getHeight();
            function stamp(cx, cy) {
              page.drawText(text, {
                x: cx - (tw / 2) * Math.cos(rad) + (th / 2) * Math.sin(rad),
                y: cy - (tw / 2) * Math.sin(rad) - (th / 2) * Math.cos(rad),
                size: size, font: font, color: PDFLib.rgb(c[0], c[1], c[2]), opacity: opacity, rotate: PDFLib.degrees(angle),
              });
            }
            if (!tile) stamp(pw / 2, ph / 2);
            else {
              const stepX = tw + size, stepY = size * 3;
              for (let y = stepY / 2; y < ph + stepY; y += stepY) {
                for (let x = ((Math.round(y / stepY) % 2) ? stepX / 2 : 0); x < pw + stepX; x += stepX) stamp(x, y);
              }
            }
          });
          downloadPdfBytes(await doc.save(), baseName(file.name) + "-watermarked.pdf");
          showResult(resultEl, "Done \u2014 the watermark was added to every page.", "success");
        } catch (err) {
          showResult(resultEl, "Couldn\u2019t add the watermark. Watermark text supports standard Latin letters, numbers and symbols.", "error");
        }
        setBtnLoading(btn, false);
      });
      on($("tz-reset"), "click", function () { upload.clear(); file = null; $("tz-text").value = "CONFIDENTIAL"; resultEl.style.display = "none"; });
    },
  };

  /* ============================================================= BACKGROUND REMOVER (AI, in-browser) */

  window.TZTools.backgroundRemover = {
    init: function () {
      const resultEl = $("tz-result");
      const stage = $("tz-stage");
      let file = null;
      let cutout = null;       // canvas with transparent background
      let modelPromise = null;

      const upload = setupSingleUpload({ iconKey: "image", onFile: function (f) { file = f; cutout = null; stage.style.display = "none"; $("tz-download").style.display = "none"; } });

      function loadModel() {
        if (!modelPromise) {
          modelPromise = import(TRANSFORMERS_URL).then(async function (T) {
            const cb = function (p) {
              if (p && p.status === "progress" && typeof p.progress === "number") {
                setProgress(p.progress);
                showResult(resultEl, "Downloading the AI model (one time)\u2026 " + Math.round(p.progress) + "%");
              }
            };
            const model = await T.AutoModel.from_pretrained("Xenova/modnet", { progress_callback: cb });
            const processor = await T.AutoProcessor.from_pretrained("Xenova/modnet");
            return { T: T, model: model, processor: processor };
          });
          modelPromise.catch(function () { modelPromise = null; });
        }
        return modelPromise;
      }

      function paint() {
        if (!cutout) return;
        const bg = $("tz-bg").value;
        const out = $("tz-canvas");
        out.width = cutout.width; out.height = cutout.height;
        const ctx = out.getContext("2d");
        ctx.clearRect(0, 0, out.width, out.height);
        if (bg !== "transparent") {
          ctx.fillStyle = bg === "custom" ? $("tz-bg-color").value : bg;
          ctx.fillRect(0, 0, out.width, out.height);
        }
        ctx.drawImage(cutout, 0, 0);
        out.style.background = bg === "transparent"
          ? "repeating-conic-gradient(#d9dde8 0% 25%, #fff 0% 50%) 50% / 20px 20px" : "none";
        $("tz-bg-color-wrap").style.display = bg === "custom" ? "" : "none";
      }
      on($("tz-bg"), "change", paint);
      on($("tz-bg-color"), "input", paint);

      on($("tz-run"), "click", async function () {
        if (!file) { TZ.showToast("Upload a photo first"); return; }
        const btn = $("tz-run");
        setBtnLoading(btn, true, "Working\u2026");
        setProgress(0);
        try {
          showResult(resultEl, "Loading the AI model\u2026 the first time this downloads about 25 MB and keeps it for next time.");
          const m = await loadModel();
          setProgress(null);
          showResult(resultEl, "Cutting out the background\u2026");
          let image = await m.T.RawImage.fromBlob(file);
          const maxSide = 2048;
          if (Math.max(image.width, image.height) > maxSide) {
            const k = maxSide / Math.max(image.width, image.height);
            image = await image.resize(Math.round(image.width * k), Math.round(image.height * k));
          }
          const inputs = await m.processor(image);
          const out = await m.model({ input: inputs.pixel_values });
          const mask = await m.T.RawImage.fromTensor(out.output[0].mul(255).to("uint8")).resize(image.width, image.height);
          const c = document.createElement("canvas");
          c.width = image.width; c.height = image.height;
          const ctx = c.getContext("2d");
          const img = await loadImage(URL.createObjectURL(file));
          ctx.drawImage(img, 0, 0, c.width, c.height);
          const px = ctx.getImageData(0, 0, c.width, c.height);
          const step = mask.channels || 1;
          for (let i = 0; i < c.width * c.height; i++) px.data[i * 4 + 3] = mask.data[i * step];
          ctx.putImageData(px, 0, 0);
          cutout = c;
          stage.style.display = "block";
          $("tz-download").style.display = "";
          paint();
          showResult(resultEl, "Done \u2014 choose a background below and download your image.", "success");
        } catch (err) {
          showResult(resultEl, "Couldn\u2019t remove the background. " + libMissingMessage("the AI model") + " Photos of people work best.", "error");
        }
        setProgress(null);
        setBtnLoading(btn, false);
      });
      on($("tz-download"), "click", async function () {
        if (!cutout) return;
        const blob = await canvasToBlob($("tz-canvas"), "image/png");
        TZ.downloadBlob(blob, baseName(file.name) + "-no-background.png");
      });
      on($("tz-reset"), "click", function () { upload.clear(); file = null; cutout = null; stage.style.display = "none"; $("tz-download").style.display = "none"; resultEl.style.display = "none"; });
      stage.style.display = "none";
      $("tz-download").style.display = "none";
    },
  };

  /* ============================================================= CROP IMAGE */

  window.TZTools.imageCropper = {
    init: function () {
      const resultEl = $("tz-result");
      const view = $("tz-view");
      const vctx = view.getContext("2d");
      let file = null, img = null, scale = 1;
      let sel = null;            // {x,y,w,h} in natural image pixels
      let dragStart = null;

      const upload = setupSingleUpload({
        iconKey: "image",
        onFile: async function (f) {
          file = f; img = null; sel = null;
          $("tz-stage").style.display = "none";
          if (!f) return;
          try {
            img = await loadImage(await fileToDataUrl(f));
            const maxW = Math.min(640, $("tz-stage").parentElement.clientWidth || 640);
            scale = Math.min(1, maxW / img.naturalWidth);
            view.width = Math.round(img.naturalWidth * scale);
            view.height = Math.round(img.naturalHeight * scale);
            $("tz-stage").style.display = "block";
            const w = img.naturalWidth * 0.8, h = img.naturalHeight * 0.8;
            sel = { x: (img.naturalWidth - w) / 2, y: (img.naturalHeight - h) / 2, w: w, h: h };
            applyAspect(false);
            draw();
          } catch (e) { showResult(resultEl, "Couldn\u2019t open that image.", "error"); }
        },
      });

      function ratio() {
        const v = $("tz-aspect").value;
        if (v === "free") return 0;
        const p = v.split(":");
        return parseFloat(p[0]) / parseFloat(p[1]);
      }
      function applyAspect(keepCenter) {
        const r = ratio();
        if (!r || !sel) return;
        const cx = sel.x + sel.w / 2, cy = sel.y + sel.h / 2;
        let w = sel.w, h = w / r;
        if (h > img.naturalHeight) { h = img.naturalHeight; w = h * r; }
        if (w > img.naturalWidth) { w = img.naturalWidth; h = w / r; }
        sel.w = w; sel.h = h;
        sel.x = Math.max(0, Math.min(img.naturalWidth - w, keepCenter === false ? sel.x : cx - w / 2));
        sel.y = Math.max(0, Math.min(img.naturalHeight - h, keepCenter === false ? sel.y : cy - h / 2));
      }
      function draw() {
        if (!img || !sel) return;
        vctx.clearRect(0, 0, view.width, view.height);
        vctx.drawImage(img, 0, 0, view.width, view.height);
        vctx.fillStyle = "rgba(4,27,69,0.55)";
        const x = sel.x * scale, y = sel.y * scale, w = sel.w * scale, h = sel.h * scale;
        vctx.fillRect(0, 0, view.width, y);
        vctx.fillRect(0, y + h, view.width, view.height - y - h);
        vctx.fillRect(0, y, x, h);
        vctx.fillRect(x + w, y, view.width - x - w, h);
        vctx.strokeStyle = "#fff"; vctx.lineWidth = 2; vctx.strokeRect(x, y, w, h);
        $("tz-sel-info").textContent = "Selection: " + Math.round(sel.w) + " \u00d7 " + Math.round(sel.h) + " px";
      }
      function pos(e) {
        const r = view.getBoundingClientRect();
        return { x: (e.clientX - r.left) * (view.width / r.width) / scale, y: (e.clientY - r.top) * (view.height / r.height) / scale };
      }
      on(view, "pointerdown", function (e) {
        if (!img) return;
        e.preventDefault();
        view.setPointerCapture(e.pointerId);
        dragStart = pos(e);
      });
      on(view, "pointermove", function (e) {
        if (!dragStart) return;
        const p = pos(e);
        const clampX = function (v) { return Math.max(0, Math.min(img.naturalWidth, v)); };
        const clampY = function (v) { return Math.max(0, Math.min(img.naturalHeight, v)); };
        let x2 = clampX(p.x), y2 = clampY(p.y);
        const r = ratio();
        let w = x2 - dragStart.x, h = y2 - dragStart.y;
        if (r) { h = Math.sign(h || 1) * Math.abs(w) / r; y2 = dragStart.y + h; if (y2 < 0 || y2 > img.naturalHeight) { y2 = clampY(y2); h = y2 - dragStart.y; w = Math.sign(w || 1) * Math.abs(h) * r; x2 = dragStart.x + w; } }
        sel = { x: Math.min(dragStart.x, x2), y: Math.min(dragStart.y, y2), w: Math.abs(x2 - dragStart.x), h: Math.abs(y2 - dragStart.y) };
        draw();
      });
      ["pointerup", "pointercancel"].forEach(function (ev) { on(view, ev, function () { dragStart = null; }); });
      on($("tz-aspect"), "change", function () { applyAspect(true); draw(); });
      on($("tz-reset-sel"), "click", function () {
        if (!img) return;
        sel = { x: 0, y: 0, w: img.naturalWidth, h: img.naturalHeight };
        applyAspect(true); draw();
      });

      on($("tz-run"), "click", async function () {
        if (!img || !sel || sel.w < 2 || sel.h < 2) { TZ.showToast("Drag on the image to choose the area to keep"); return; }
        const c = document.createElement("canvas");
        c.width = Math.round(sel.w); c.height = Math.round(sel.h);
        c.getContext("2d").drawImage(img, sel.x, sel.y, sel.w, sel.h, 0, 0, c.width, c.height);
        const type = $("tz-format").value;
        const blob = await canvasToBlob(c, type, 0.92);
        TZ.downloadBlob(blob, baseName(file.name) + "-cropped." + (type === "image/png" ? "png" : "jpg"));
        showResult(resultEl, "Done \u2014 cropped image downloaded (" + c.width + " \u00d7 " + c.height + " px).", "success");
      });
      on($("tz-reset"), "click", function () { upload.clear(); file = null; img = null; sel = null; $("tz-stage").style.display = "none"; resultEl.style.display = "none"; });
      $("tz-stage").style.display = "none";
    },
  };

  /* ============================================================= ROTATE & FLIP IMAGE */

  window.TZTools.imageRotateFlip = {
    init: function () {
      const resultEl = $("tz-result");
      const view = $("tz-view");
      let file = null, img = null;
      let st = { rot: 0, fh: false, fv: false };

      const upload = setupSingleUpload({
        iconKey: "image",
        onFile: async function (f) {
          file = f; img = null; st = { rot: 0, fh: false, fv: false };
          $("tz-stage").style.display = "none";
          if (!f) return;
          try { img = await loadImage(await fileToDataUrl(f)); $("tz-stage").style.display = "block"; render(view, 640); }
          catch (e) { showResult(resultEl, "Couldn\u2019t open that image.", "error"); }
        },
      });

      function render(canvas, maxSide) {
        const swap = st.rot % 180 !== 0;
        const nw = img.naturalWidth, nh = img.naturalHeight;
        const ow = swap ? nh : nw, oh = swap ? nw : nh;
        const k = maxSide ? Math.min(1, maxSide / Math.max(ow, oh)) : 1;
        canvas.width = Math.round(ow * k); canvas.height = Math.round(oh * k);
        const ctx = canvas.getContext("2d");
        ctx.save();
        ctx.translate(canvas.width / 2, canvas.height / 2);
        ctx.rotate(st.rot * Math.PI / 180);
        ctx.scale(st.fh ? -1 : 1, st.fv ? -1 : 1);
        ctx.drawImage(img, -nw * k / 2, -nh * k / 2, nw * k, nh * k);
        ctx.restore();
      }
      function act(fn) { if (!img) { TZ.showToast("Upload an image first"); return; } fn(); render(view, 640); }
      on($("tz-left"), "click", function () { act(function () { st.rot = (st.rot + 270) % 360; }); });
      on($("tz-right"), "click", function () { act(function () { st.rot = (st.rot + 90) % 360; }); });
      on($("tz-flip-h"), "click", function () { act(function () { st.fh = !st.fh; }); });
      on($("tz-flip-v"), "click", function () { act(function () { st.fv = !st.fv; }); });
      on($("tz-undo"), "click", function () { act(function () { st = { rot: 0, fh: false, fv: false }; }); });
      on($("tz-run"), "click", async function () {
        if (!img) { TZ.showToast("Upload an image first"); return; }
        const c = document.createElement("canvas");
        render(c, 0);
        const type = $("tz-format").value;
        TZ.downloadBlob(await canvasToBlob(c, type, 0.92), baseName(file.name) + "-edited." + (type === "image/png" ? "png" : "jpg"));
        showResult(resultEl, "Done \u2014 your image was downloaded.", "success");
      });
      on($("tz-reset"), "click", function () { upload.clear(); file = null; img = null; $("tz-stage").style.display = "none"; resultEl.style.display = "none"; });
      $("tz-stage").style.display = "none";
    },
  };

  /* ============================================================= HEIC TO JPG */

  window.TZTools.heicToJpg = {
    init: function () {
      const resultEl = $("tz-result");
      const listEl = $("tz-results");
      let files = [];
      let made = [];

      function renderFiles() {
        $("tz-file-list").innerHTML = files.map(function (f, i) {
          return '<div class="file-chip">' + tzIcon("image") + '<span class="name">' + TZ.escapeHtml(f.name) + " \u00b7 " + TZ.formatBytes(f.size) + "</span>" +
            '<button type="button" data-i="' + i + '" aria-label="Remove">' + tzIcon("close") + "</button></div>";
        }).join("");
      }
      on($("tz-file-list"), "click", function (e) {
        const b = e.target.closest("button[data-i]");
        if (!b) return;
        files.splice(parseInt(b.getAttribute("data-i"), 10), 1);
        renderFiles();
      });
      setupMultiUpload({ onFiles: function (list) { list.forEach(function (f) { files.push(f); }); renderFiles(); } });

      on($("tz-run"), "click", async function () {
        if (!files.length) { TZ.showToast("Add at least one HEIC photo"); return; }
        if (typeof heic2any === "undefined") { TZ.showToast(libMissingMessage("the HEIC converter")); return; }
        const btn = $("tz-run");
        setBtnLoading(btn, true, "Converting\u2026");
        listEl.innerHTML = "";
        made = [];
        const quality = parseFloat($("tz-quality").value) || 0.9;
        let failed = 0;
        for (let i = 0; i < files.length; i++) {
          try {
            let out = await heic2any({ blob: files[i], toType: "image/jpeg", quality: quality });
            if (Array.isArray(out)) out = out[0];
            const name = baseName(files[i].name) + ".jpg";
            made.push({ name: name, blob: out });
            const url = URL.createObjectURL(out);
            const row = document.createElement("div");
            row.className = "file-chip";
            row.innerHTML = tzIcon("check-circle") + '<span class="name">' + TZ.escapeHtml(name) + " \u00b7 " + TZ.formatBytes(out.size) + '</span><a class="btn btn-outline btn-sm" href="' + url + '" download="' + TZ.escapeHtml(name) + '">Download</a>';
            listEl.appendChild(row);
          } catch (e) { failed++; }
          setProgress(((i + 1) / files.length) * 100);
        }
        $("tz-zip").style.display = made.length > 1 ? "" : "none";
        showResult(resultEl, made.length + " photo" + (made.length === 1 ? "" : "s") + " converted" + (failed ? "; " + failed + " couldn\u2019t be read (are they really HEIC files?)." : "."), failed && !made.length ? "error" : "success");
        setProgress(null);
        setBtnLoading(btn, false);
      });
      on($("tz-zip"), "click", async function () {
        if (typeof JSZip === "undefined" || !made.length) return;
        const zip = new JSZip();
        made.forEach(function (m) { zip.file(m.name, m.blob); });
        TZ.downloadBlob(await zip.generateAsync({ type: "blob" }), "heic-to-jpg.zip");
      });
      on($("tz-reset"), "click", function () { files = []; made = []; renderFiles(); listEl.innerHTML = ""; $("tz-zip").style.display = "none"; resultEl.style.display = "none"; });
      $("tz-zip").style.display = "none";
    },
  };

  /* ============================================================= PASSPORT PHOTO MAKER */

  window.TZTools.passportPhoto = {
    init: function () {
      const FORMATS = {
        "us": ["US passport / visa (2 \u00d7 2 in)", 50.8, 50.8],
        "uk": ["UK passport (35 \u00d7 45 mm)", 35, 45],
        "ca": ["Canada passport (50 \u00d7 70 mm)", 50, 70],
        "eu": ["Schengen / EU visa (35 \u00d7 45 mm)", 35, 45],
        "in": ["India passport (2 \u00d7 2 in)", 50.8, 50.8],
        "pk": ["Pakistan passport (35 \u00d7 45 mm)", 35, 45],
        "au": ["Australia passport (35 \u00d7 45 mm)", 35, 45],
        "cn": ["China visa (33 \u00d7 48 mm)", 33, 48],
      };
      const DPI = 300;
      const sel = $("tz-format");
      Object.keys(FORMATS).forEach(function (k) {
        const o = document.createElement("option");
        o.value = k; o.textContent = FORMATS[k][0];
        sel.appendChild(o);
      });
      const view = $("tz-view");
      let file = null, img = null;

      const upload = setupSingleUpload({
        iconKey: "image",
        onFile: async function (f) {
          file = f; img = null;
          $("tz-stage").style.display = "none";
          if (!f) return;
          try { img = await loadImage(await fileToDataUrl(f)); $("tz-stage").style.display = "block"; draw(view, 0.35, true); }
          catch (e) { showResult($("tz-result"), "Couldn\u2019t open that image.", "error"); }
        },
      });

      function dims() {
        const f = FORMATS[sel.value];
        return { w: Math.round(f[1] / 25.4 * DPI), h: Math.round(f[2] / 25.4 * DPI) };
      }
      function draw(canvas, k, guide) {
        const d = dims();
        canvas.width = Math.round(d.w * k); canvas.height = Math.round(d.h * k);
        const ctx = canvas.getContext("2d");
        ctx.fillStyle = $("tz-bg").value;
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        const zoom = parseFloat($("tz-zoom").value) || 1;
        const cover = Math.max(canvas.width / img.naturalWidth, canvas.height / img.naturalHeight) * zoom;
        const w = img.naturalWidth * cover, h = img.naturalHeight * cover;
        const ox = (parseFloat($("tz-x").value) || 0) / 100 * canvas.width;
        const oy = (parseFloat($("tz-y").value) || 0) / 100 * canvas.height;
        ctx.drawImage(img, (canvas.width - w) / 2 + ox, (canvas.height - h) / 2 + oy, w, h);
        if (guide) {
          ctx.strokeStyle = "rgba(14,165,236,0.9)"; ctx.lineWidth = 2; ctx.setLineDash([6, 5]);
          ctx.beginPath();
          ctx.ellipse(canvas.width / 2, canvas.height * 0.45, canvas.width * 0.3, canvas.height * 0.3, 0, 0, Math.PI * 2);
          ctx.stroke();
          ctx.setLineDash([]);
        }
        $("tz-size-info").textContent = d.w + " \u00d7 " + d.h + " px at " + DPI + " DPI";
      }
      function refresh() { if (img) draw(view, 0.35, true); }
      ["tz-format", "tz-bg", "tz-zoom", "tz-x", "tz-y"].forEach(function (id) { on($(id), "input", refresh); on($(id), "change", refresh); });

      on($("tz-photo"), "click", async function () {
        if (!img) { TZ.showToast("Upload a photo first"); return; }
        const c = document.createElement("canvas");
        draw(c, 1, false);
        TZ.downloadBlob(await canvasToBlob(c, "image/jpeg", 0.95), "passport-photo.jpg");
      });
      on($("tz-sheet"), "click", async function () {
        if (!img) { TZ.showToast("Upload a photo first"); return; }
        const one = document.createElement("canvas");
        draw(one, 1, false);
        const d = dims(), gap = 24, margin = 36;
        function fit(W, H) {
          const cols = Math.max(0, Math.floor((W - margin * 2 + gap) / (d.w + gap)));
          const rows = Math.max(0, Math.floor((H - margin * 2 + gap) / (d.h + gap)));
          return { W: W, H: H, cols: cols, rows: rows, n: cols * rows };
        }
        const a = fit(1800, 1200), b = fit(1200, 1800);
        const best = b.n > a.n ? b : a;
        if (!best.n) { TZ.showToast("This photo size doesn\u2019t fit on a 4 \u00d7 6 in sheet"); return; }
        const sheet = document.createElement("canvas");
        sheet.width = best.W; sheet.height = best.H;
        const ctx = sheet.getContext("2d");
        ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, sheet.width, sheet.height);
        const gridW = best.cols * d.w + (best.cols - 1) * gap, gridH = best.rows * d.h + (best.rows - 1) * gap;
        const sx = (best.W - gridW) / 2, sy = (best.H - gridH) / 2;
        for (let r = 0; r < best.rows; r++) for (let q = 0; q < best.cols; q++) ctx.drawImage(one, sx + q * (d.w + gap), sy + r * (d.h + gap));
        TZ.downloadBlob(await canvasToBlob(sheet, "image/jpeg", 0.95), "passport-photo-4x6-sheet.jpg");
        showResult($("tz-result"), "Done \u2014 a 4 \u00d7 6 in print sheet with " + best.n + " photo" + (best.n === 1 ? "" : "s") + " was downloaded.", "success");
      });
      on($("tz-reset"), "click", function () {
        upload.clear(); file = null; img = null;
        $("tz-stage").style.display = "none"; $("tz-result").style.display = "none";
        $("tz-zoom").value = 1; $("tz-x").value = 0; $("tz-y").value = 0;
      });
      $("tz-stage").style.display = "none";
    },
  };

  /* ============================================================= PAYCHECK CALCULATOR (US / UK / Canada, 2026 rates) */

  window.TZTools.paycheckCalculator = {
    init: function () {
      const CUR = { us: "USD", uk: "GBP", ca: "CAD" };
      const countrySel = $("tz-country");

      function bracketTax(income, brackets) {
        // brackets: [[upTo, rate], ...] with the last upTo = Infinity
        let tax = 0, prev = 0;
        for (let i = 0; i < brackets.length; i++) {
          const top = brackets[i][0];
          if (income > prev) tax += (Math.min(income, top) - prev) * brackets[i][1];
          prev = top;
          if (income <= top) break;
        }
        return tax;
      }

      function calcUS(gross, pretax, married, stateRate) {
        const std = married ? 32200 : 16100;
        const B = married
          ? [[24800, 0.10], [100800, 0.12], [211400, 0.22], [403550, 0.24], [512450, 0.32], [768700, 0.35], [Infinity, 0.37]]
          : [[12400, 0.10], [50400, 0.12], [105700, 0.22], [201775, 0.24], [256225, 0.32], [640600, 0.35], [Infinity, 0.37]];
        const taxable = Math.max(0, gross - pretax - std);
        const fed = bracketTax(taxable, B);
        const ss = Math.min(gross, 184500) * 0.062;
        const medicare = gross * 0.0145 + Math.max(0, gross - (married ? 250000 : 200000)) * 0.009;
        const state = Math.max(0, gross - pretax) * stateRate / 100;
        return { lines: [["Federal income tax", fed], ["Social Security (6.2%)", ss], ["Medicare", medicare], ["State income tax (your estimate)", state]], tax: fed + ss + medicare + state };
      }

      function calcUK(gross, pension) {
        const income = Math.max(0, gross - pension);
        let pa = 12570;
        if (income > 100000) pa = Math.max(0, 12570 - (income - 100000) / 2);
        const t = Math.max(0, income - pa);
        const basic = Math.min(t, 37700) * 0.20;
        const higher = Math.min(Math.max(t - 37700, 0), 125140 - 37700) * 0.40;
        const additional = Math.max(t - 125140, 0) * 0.45;
        const ni = Math.max(0, Math.min(gross, 50270) - 12570) * 0.08 + Math.max(0, gross - 50270) * 0.02;
        return { lines: [["Income tax", basic + higher + additional], ["National Insurance (employee)", ni]], tax: basic + higher + additional + ni };
      }

      function calcCA(gross, pretax, provRate) {
        const taxable = Math.max(0, gross - pretax);
        const B = [[58523, 0.14], [117045, 0.205], [181440, 0.26], [258482, 0.29], [Infinity, 0.33]];
        const cpp1 = Math.max(0, Math.min(gross, 74600) - 3500) * 0.0595;
        const cpp2 = Math.max(0, Math.min(gross, 85000) - 74600) * 0.04;
        const ei = Math.min(gross, 68900) * 0.0163;
        let bpa = 16452;
        if (taxable >= 258482) bpa = 14829;
        else if (taxable > 181440) bpa = 16452 - (taxable - 181440) / (258482 - 181440) * (16452 - 14829);
        const credits = 0.14 * (bpa + ei + cpp1 * (4.95 / 5.95));
        const fed = Math.max(0, bracketTax(taxable, B) - credits);
        const prov = taxable * provRate / 100;
        return { lines: [["Federal income tax", fed], ["CPP contributions", cpp1 + cpp2], ["EI premiums", ei], ["Provincial tax (your estimate)", prov]], tax: fed + cpp1 + cpp2 + ei + prov };
      }

      function run() {
        const c = countrySel.value;
        const cur = CUR[c];
        const gross = Math.max(0, numVal("tz-gross"));
        const periods = parseInt($("tz-freq").value, 10) || 12;
        const pre = gross * Math.max(0, numVal("tz-pretax")) / 100;
        $("tz-us-opts").style.display = c === "us" ? "" : "none";
        $("tz-state-wrap").style.display = c === "us" || c === "ca" ? "" : "none";
        $("tz-state-label").textContent = c === "us" ? "State income tax rate (%)" : "Provincial income tax rate (%)";
        const extra = Math.max(0, numVal("tz-state"));
        let r;
        if (c === "us") r = calcUS(gross, pre, $("tz-status").value === "married", extra);
        else if (c === "uk") r = calcUK(gross, pre);
        else r = calcCA(gross, pre, extra);
        const net = gross - r.tax - pre;
        const f = function (n) { return formatMoney(n, cur); };
        $("tz-stat-net").textContent = f(net / periods);
        $("tz-stat-net-year").textContent = f(net);
        $("tz-stat-tax").textContent = gross ? (r.tax / gross * 100).toFixed(1) + "%" : "0%";
        const rows = [["Gross pay", gross]].concat(pre ? [["Pre-tax retirement contribution", -pre]] : []).concat(r.lines.map(function (l) { return [l[0], -l[1]]; })).concat([["Take-home pay", net]]);
        $("tz-breakdown").innerHTML = '<table class="invoice-table"><thead><tr><th>Item</th><th style="text-align:right;">Per paycheck</th><th style="text-align:right;">Annual</th></tr></thead><tbody>' +
          rows.map(function (row, i) {
            const last = i === rows.length - 1;
            return "<tr" + (last ? ' style="font-weight:700;"' : "") + "><td>" + TZ.escapeHtml(row[0]) + '</td><td style="text-align:right;">' + f(row[1] / periods) + '</td><td style="text-align:right;">' + f(row[1]) + "</td></tr>";
          }).join("") + "</tbody></table>";
      }
      ["tz-country", "tz-gross", "tz-freq", "tz-pretax", "tz-status", "tz-state"].forEach(function (id) { on($(id), "input", run); on($(id), "change", run); });
      on($("tz-reset"), "click", function () { $("tz-gross").value = 60000; $("tz-pretax").value = 0; $("tz-state").value = 0; run(); });
      run();
    },
  };

  /* ============================================================= MORTGAGE CALCULATOR */

  window.TZTools.mortgageCalculator = {
    init: function () {
      const cur = $("tz-currency");
      fillCurrencySelect(cur, "USD");
      function run() {
        const code = cur.value;
        const f = function (n) { return formatMoney(n, code); };
        const price = Math.max(0, numVal("tz-price"));
        const down = Math.min(100, Math.max(0, numVal("tz-down"))) / 100 * price;
        const loan = price - down;
        const n = Math.max(1, Math.round(numVal("tz-years", 30) * 12));
        const r = numVal("tz-rate") / 100 / 12;
        const pi = r === 0 ? loan / n : loan * r / (1 - Math.pow(1 + r, -n));
        const tax = price * numVal("tz-ptax") / 100 / 12;
        const ins = numVal("tz-ins") / 12;
        const hoa = numVal("tz-hoa");
        $("tz-stat-total").textContent = f(pi + tax + ins + hoa);
        $("tz-stat-pi").textContent = f(pi);
        $("tz-stat-loan").textContent = f(loan);
        $("tz-stat-interest").textContent = f(Math.max(0, pi * n - loan));
        let bal = loan, rows = "";
        for (let y = 1; y <= Math.ceil(n / 12); y++) {
          let ip = 0, pp = 0;
          for (let m = 0; m < 12 && (y - 1) * 12 + m < n; m++) {
            const i = bal * r, p = Math.min(bal, pi - i);
            ip += i; pp += p; bal -= p;
          }
          rows += "<tr><td>" + y + "</td><td>" + f(pp) + "</td><td>" + f(ip) + "</td><td>" + f(Math.max(0, bal)) + "</td></tr>";
        }
        $("tz-schedule").innerHTML = "<tr><th>Year</th><th>Principal paid</th><th>Interest paid</th><th>Balance</th></tr>" + rows;
      }
      ["tz-currency", "tz-price", "tz-down", "tz-rate", "tz-years", "tz-ptax", "tz-ins", "tz-hoa"].forEach(function (id) { on($(id), "input", run); on($(id), "change", run); });
      on($("tz-reset"), "click", function () {
        $("tz-price").value = 400000; $("tz-down").value = 20; $("tz-rate").value = 6.5; $("tz-years").value = 30;
        $("tz-ptax").value = 1.1; $("tz-ins").value = 1500; $("tz-hoa").value = 0; run();
      });
      run();
    },
  };

  /* ============================================================= TIP CALCULATOR */

  window.TZTools.tipCalculator = {
    init: function () {
      const cur = $("tz-currency");
      fillCurrencySelect(cur, "USD");
      let tipPct = 18;
      function run() {
        const f = function (n) { return formatMoney(n, cur.value); };
        const bill = Math.max(0, numVal("tz-bill"));
        const people = Math.max(1, Math.round(numVal("tz-people", 1)));
        const custom = $("tz-tip").value;
        if (custom !== "") tipPct = Math.max(0, parseFloat(custom) || 0);
        let tip = bill * tipPct / 100;
        let total = bill + tip;
        let each = total / people;
        if ($("tz-round").checked) { each = Math.ceil(each); total = each * people; tip = total - bill; }
        $("tz-stat-tip").textContent = f(tip);
        $("tz-stat-total").textContent = f(total);
        $("tz-stat-each").textContent = f(each);
        document.querySelectorAll("[data-tip]").forEach(function (b) { b.classList.toggle("btn-primary", parseFloat(b.getAttribute("data-tip")) === tipPct && custom === ""); b.classList.toggle("btn-outline", !(parseFloat(b.getAttribute("data-tip")) === tipPct && custom === "")); });
      }
      document.querySelectorAll("[data-tip]").forEach(function (b) {
        on(b, "click", function () { tipPct = parseFloat(b.getAttribute("data-tip")); $("tz-tip").value = ""; run(); });
      });
      ["tz-currency", "tz-bill", "tz-tip", "tz-people", "tz-round"].forEach(function (id) { on($(id), "input", run); on($(id), "change", run); });
      on($("tz-reset"), "click", function () { $("tz-bill").value = ""; $("tz-tip").value = ""; $("tz-people").value = 1; $("tz-round").checked = false; tipPct = 18; run(); });
      run();
    },
  };

  /* ============================================================= GPA CALCULATOR */

  window.TZTools.gpaCalculator = {
    init: function () {
      const GRADES = [["A+", 4.0], ["A", 4.0], ["A-", 3.7], ["B+", 3.3], ["B", 3.0], ["B-", 2.7], ["C+", 2.3], ["C", 2.0], ["C-", 1.7], ["D+", 1.3], ["D", 1.0], ["D-", 0.7], ["F", 0]];
      const tbody = $("tz-courses");
      function row(name, credits, grade) {
        const tr = document.createElement("tr");
        tr.innerHTML =
          '<td><input type="text" class="input-field c-name" aria-label="Course name" placeholder="Course (optional)"></td>' +
          '<td><input type="number" class="input-field c-credits" aria-label="Credits" min="0" step="0.5" value="3"></td>' +
          '<td><select class="input-field c-grade" aria-label="Grade">' + GRADES.map(function (g) { return '<option value="' + g[1] + '">' + g[0] + "</option>"; }).join("") + "</select></td>" +
          '<td><button type="button" class="line-item-remove" aria-label="Remove course">' + tzIcon("trash") + "</button></td>";
        if (name) tr.querySelector(".c-name").value = name;
        if (credits != null) tr.querySelector(".c-credits").value = credits;
        if (grade != null) tr.querySelector(".c-grade").selectedIndex = grade;
        return tr;
      }
      function run() {
        let pts = 0, cr = 0;
        tbody.querySelectorAll("tr").forEach(function (tr) {
          const c = parseFloat(tr.querySelector(".c-credits").value) || 0;
          pts += c * parseFloat(tr.querySelector(".c-grade").value);
          cr += c;
        });
        const prevGpa = numVal("tz-prev-gpa"), prevCr = numVal("tz-prev-credits");
        const sem = cr ? pts / cr : 0;
        const totCr = cr + prevCr;
        const cum = totCr ? (pts + prevGpa * prevCr) / totCr : 0;
        $("tz-stat-sem").textContent = sem.toFixed(2);
        $("tz-stat-cum").textContent = prevCr ? cum.toFixed(2) : "\u2014";
        $("tz-stat-credits").textContent = String(cr);
      }
      on(tbody, "input", run);
      on(tbody, "change", run);
      on(tbody, "click", function (e) { const b = e.target.closest(".line-item-remove"); if (!b) return; b.closest("tr").remove(); run(); });
      on($("tz-add"), "click", function () { tbody.appendChild(row()); run(); });
      ["tz-prev-gpa", "tz-prev-credits"].forEach(function (id) { on($(id), "input", run); });
      function reset() {
        tbody.innerHTML = "";
        tbody.appendChild(row(null, 3, 1)); tbody.appendChild(row(null, 3, 3)); tbody.appendChild(row(null, 4, 2));
        $("tz-prev-gpa").value = ""; $("tz-prev-credits").value = "";
        run();
      }
      on($("tz-reset"), "click", reset);
      reset();
    },
  };

  /* ============================================================= COMPOUND INTEREST CALCULATOR */

  window.TZTools.compoundInterest = {
    init: function () {
      const cur = $("tz-currency");
      fillCurrencySelect(cur, "USD");
      function run() {
        const f = function (n) { return formatMoney(n, cur.value); };
        const p = Math.max(0, numVal("tz-principal"));
        const pm = Math.max(0, numVal("tz-monthly"));
        const rate = numVal("tz-rate") / 100;
        const years = Math.max(0, Math.min(100, numVal("tz-years", 10)));
        const n = parseInt($("tz-compound").value, 10) || 12;
        const g = Math.pow(1 + rate / n, n / 12);          // growth factor per month
        let bal = p, contrib = p, rows = "";
        const months = Math.round(years * 12);
        for (let m = 1; m <= months; m++) {
          bal = bal * g + pm;
          contrib += pm;
          if (m % 12 === 0 || m === months) rows += "<tr><td>" + (m / 12).toFixed(m % 12 ? 1 : 0) + "</td><td>" + f(contrib) + "</td><td>" + f(bal - contrib) + "</td><td>" + f(bal) + "</td></tr>";
        }
        $("tz-stat-balance").textContent = f(bal);
        $("tz-stat-contrib").textContent = f(contrib);
        $("tz-stat-interest").textContent = f(bal - contrib);
        $("tz-schedule").innerHTML = "<tr><th>Year</th><th>Total paid in</th><th>Interest earned</th><th>Balance</th></tr>" + rows;
      }
      ["tz-currency", "tz-principal", "tz-monthly", "tz-rate", "tz-years", "tz-compound"].forEach(function (id) { on($(id), "input", run); on($(id), "change", run); });
      on($("tz-reset"), "click", function () { $("tz-principal").value = 10000; $("tz-monthly").value = 200; $("tz-rate").value = 7; $("tz-years").value = 20; $("tz-compound").value = "12"; run(); });
      run();
    },
  };

  /* ============================================================= SALES TAX / VAT / GST CALCULATOR */

  window.TZTools.salesTaxCalculator = {
    init: function () {
      const cur = $("tz-currency");
      fillCurrencySelect(cur, "USD");
      function run() {
        const f = function (n) { return formatMoney(n, cur.value); };
        const amount = Math.max(0, numVal("tz-amount"));
        const rate = Math.max(0, numVal("tz-rate"));
        let net, tax, gross;
        if ($("tz-mode").value === "add") { net = amount; tax = amount * rate / 100; gross = net + tax; }
        else { gross = amount; net = gross / (1 + rate / 100); tax = gross - net; }
        $("tz-stat-net").textContent = f(net);
        $("tz-stat-tax").textContent = f(tax);
        $("tz-stat-gross").textContent = f(gross);
      }
      on($("tz-preset"), "change", function () { if ($("tz-preset").value) { $("tz-rate").value = parseFloat($("tz-preset").value); run(); } });
      ["tz-currency", "tz-amount", "tz-rate", "tz-mode"].forEach(function (id) { on($(id), "input", run); on($(id), "change", run); });
      on($("tz-reset"), "click", function () { $("tz-amount").value = ""; $("tz-rate").value = 20; $("tz-preset").value = ""; run(); });
      run();
    },
  };

  /* ============================================================= HOURLY TO SALARY */

  window.TZTools.hourlyToSalary = {
    init: function () {
      const cur = $("tz-currency");
      fillCurrencySelect(cur, "USD");
      function run() {
        const f = function (n) { return formatMoney(n, cur.value); };
        const hpw = Math.max(0.01, numVal("tz-hours", 40));
        const wpy = Math.max(1, Math.min(52, numVal("tz-weeks", 52)));
        const rev = $("tz-mode").value === "salary";
        $("tz-amount-label").textContent = rev ? "Yearly salary" : "Hourly rate";
        const amount = Math.max(0, numVal("tz-amount"));
        const hourly = rev ? amount / (hpw * wpy) : amount;
        const year = hourly * hpw * wpy;
        $("tz-stat-hour").textContent = f(hourly);
        $("tz-stat-day").textContent = f(hourly * hpw / 5);
        $("tz-stat-week").textContent = f(hourly * hpw);
        $("tz-stat-biweek").textContent = f(hourly * hpw * 2);
        $("tz-stat-month").textContent = f(year / 12);
        $("tz-stat-year").textContent = f(year);
      }
      ["tz-currency", "tz-amount", "tz-hours", "tz-weeks", "tz-mode"].forEach(function (id) { on($(id), "input", run); on($(id), "change", run); });
      on($("tz-reset"), "click", function () { $("tz-amount").value = ""; $("tz-hours").value = 40; $("tz-weeks").value = 52; run(); });
      run();
    },
  };

  /* ============================================================= CALORIE / TDEE CALCULATOR */

  window.TZTools.calorieCalculator = {
    init: function () {
      function run() {
        const metric = $("tz-units").value === "metric";
        $("tz-height-metric").style.display = metric ? "" : "none";
        $("tz-height-imp").style.display = metric ? "none" : "";
        $("tz-weight-label").textContent = metric ? "Weight (kg)" : "Weight (lb)";
        const age = Math.min(100, Math.max(18, numVal("tz-age", 30)));
        const cm = metric ? numVal("tz-cm") : (numVal("tz-ft") * 12 + numVal("tz-in")) * 2.54;
        const kg = metric ? numVal("tz-weight") : numVal("tz-weight") * 0.45359237;
        const male = $("tz-sex").value === "m";
        if (!cm || !kg) {
          ["bmr", "tdee", "loss", "gain"].forEach(function (k) { $("tz-stat-" + k).textContent = "\u2014"; });
          return;
        }
        const bmr = 10 * kg + 6.25 * cm - 5 * age + (male ? 5 : -161);
        const tdee = bmr * parseFloat($("tz-activity").value);
        const floor = male ? 1500 : 1200;
        const fmt = function (n) { return Math.round(n).toLocaleString(); };
        $("tz-stat-bmr").textContent = fmt(bmr);
        $("tz-stat-tdee").textContent = fmt(tdee);
        $("tz-stat-loss").textContent = fmt(Math.max(floor, tdee - 500));
        $("tz-stat-gain").textContent = fmt(tdee + 500);
      }
      ["tz-units", "tz-sex", "tz-age", "tz-cm", "tz-ft", "tz-in", "tz-weight", "tz-activity"].forEach(function (id) { on($(id), "input", run); on($(id), "change", run); });
      on($("tz-reset"), "click", function () { ["tz-cm", "tz-ft", "tz-in", "tz-weight"].forEach(function (id) { $(id).value = ""; }); $("tz-age").value = 30; run(); });
      run();
    },
  };

  /* ============================================================= REMOVE EXTRA SPACES & LINE BREAKS */

  window.TZTools.removeExtraSpaces = {
    init: function () {
      const input = $("tz-input"), output = $("tz-output");
      function run() {
        let t = input.value.replace(/\r\n?/g, "\n");
        if ($("tz-tabs").checked) t = t.replace(/\t/g, " ");
        if ($("tz-collapse").checked) t = t.replace(/[ \u00a0]{2,}/g, " ");
        if ($("tz-trim").checked) t = t.split("\n").map(function (l) { return l.trim(); }).join("\n");
        if ($("tz-empty").checked) t = t.split("\n").filter(function (l) { return l.trim() !== ""; }).join("\n");
        if ($("tz-join").checked) t = t.split("\n").filter(function (l) { return l.trim() !== ""; }).join(" ").replace(/ {2,}/g, " ");
        output.value = t;
        $("tz-stat-before").textContent = input.value.length.toLocaleString();
        $("tz-stat-after").textContent = t.length.toLocaleString();
        $("tz-stat-removed").textContent = Math.max(0, input.value.length - t.length).toLocaleString();
      }
      ["tz-input", "tz-tabs", "tz-collapse", "tz-trim", "tz-empty", "tz-join"].forEach(function (id) { on($(id), "input", run); on($(id), "change", run); });
      on($("tz-copy"), "click", function () { if (output.value) TZ.copyToClipboard(output.value, "Cleaned text copied"); });
      on($("tz-download"), "click", function () { if (output.value) TZ.downloadText(output.value, "cleaned-text.txt", "text/plain"); });
      on($("tz-reset"), "click", function () { input.value = ""; run(); });
      run();
    },
  };

  /* ============================================================= MARKDOWN TO HTML */

  function mdToHtml(md) {
    const esc = function (s) { return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); };
    const safeUrl = function (u) { return /^(https?:|mailto:|\/|#|\.)/i.test(u.trim()) ? u.trim().replace(/"/g, "%22") : "#"; };
    function inline(s) {
      const codes = [];
      s = s.replace(/`([^`]+)`/g, function (_, c) { codes.push("<code>" + esc(c) + "</code>"); return "\u0000" + (codes.length - 1) + "\u0000"; });
      s = esc(s);
      s = s.replace(/!\[([^\]]*)\]\(([^)\s]+)\)/g, function (_, a, u) { return '<img src="' + safeUrl(u) + '" alt="' + a + '">'; });
      s = s.replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, function (_, t, u) { return '<a href="' + safeUrl(u) + '">' + t + "</a>"; });
      s = s.replace(/\*\*([^*]+)\*\*|__([^_]+)__/g, function (_, a, b) { return "<strong>" + (a || b) + "</strong>"; });
      s = s.replace(/(^|[^*])\*([^*\s][^*]*)\*/g, "$1<em>$2</em>").replace(/(^|[^\w_])_([^_\s][^_]*)_(?![\w_])/g, "$1<em>$2</em>");
      s = s.replace(/~~([^~]+)~~/g, "<del>$1</del>");
      return s.replace(/\u0000(\d+)\u0000/g, function (_, i) { return codes[parseInt(i, 10)]; });
    }
    const lines = String(md).replace(/\r\n?/g, "\n").split("\n");
    let out = [], para = [], list = null, i = 0;
    const flushPara = function () { if (para.length) { out.push("<p>" + inline(para.join(" ")) + "</p>"); para = []; } };
    const closeList = function () { if (list) { out.push("</" + list + ">"); list = null; } };
    while (i < lines.length) {
      const line = lines[i];
      let m;
      if ((m = line.match(/^```(\w*)\s*$/))) {
        flushPara(); closeList();
        const buf = [];
        i++;
        while (i < lines.length && !/^```\s*$/.test(lines[i])) { buf.push(lines[i]); i++; }
        out.push("<pre><code" + (m[1] ? ' class="language-' + m[1] + '"' : "") + ">" + esc(buf.join("\n")) + "</code></pre>");
        i++; continue;
      }
      if (/^\s*$/.test(line)) { flushPara(); closeList(); i++; continue; }
      if ((m = line.match(/^(#{1,6})\s+(.*?)\s*#*\s*$/))) { flushPara(); closeList(); out.push("<h" + m[1].length + ">" + inline(m[2]) + "</h" + m[1].length + ">"); i++; continue; }
      if (/^\s*([-*_])(\s*\1){2,}\s*$/.test(line)) { flushPara(); closeList(); out.push("<hr>"); i++; continue; }
      if ((m = line.match(/^>\s?(.*)$/))) {
        flushPara(); closeList();
        const buf = [m[1]];
        i++;
        while (i < lines.length && (m = lines[i].match(/^>\s?(.*)$/))) { buf.push(m[1]); i++; }
        out.push("<blockquote><p>" + inline(buf.join(" ")) + "</p></blockquote>");
        continue;
      }
      if ((m = line.match(/^\s*([-*+])\s+(.*)$/))) {
        flushPara();
        if (list !== "ul") { closeList(); out.push("<ul>"); list = "ul"; }
        out.push("<li>" + inline(m[2]) + "</li>"); i++; continue;
      }
      if ((m = line.match(/^\s*\d+[.)]\s+(.*)$/))) {
        flushPara();
        if (list !== "ol") { closeList(); out.push("<ol>"); list = "ol"; }
        out.push("<li>" + inline(m[1]) + "</li>"); i++; continue;
      }
      closeList();
      para.push(line.trim());
      i++;
    }
    flushPara(); closeList();
    return out.join("\n");
  }

  window.TZTools.markdownToHtml = {
    init: function () {
      const input = $("tz-input"), code = $("tz-output"), preview = $("tz-preview");
      function run() {
        const html = mdToHtml(input.value);
        code.value = html;
        preview.innerHTML = html || '<p style="color:var(--muted);">Your preview will appear here\u2026</p>';
        $("tz-stat-words").textContent = countWords(input.value).toLocaleString();
        $("tz-stat-chars").textContent = html.length.toLocaleString();
      }
      on(input, "input", run);
      on($("tz-copy"), "click", function () { if (code.value) TZ.copyToClipboard(code.value, "HTML copied"); });
      on($("tz-download"), "click", function () { if (code.value) TZ.downloadText(code.value, "converted.html", "text/html"); });
      on($("tz-reset"), "click", function () { input.value = ""; run(); });
      input.value = "# Hello, Markdown!\n\nWrite **bold**, *italic* and `code`, add a [link](https://www.toolzihub.com), and make lists:\n\n- First item\n- Second item\n\n> A short quote.";
      run();
    },
  };

  /* ============================================================= CSS GRADIENT GENERATOR */

  window.TZTools.cssGradient = {
    init: function () {
      let stops = [{ c: "#0EA5EC", p: 0 }, { c: "#22C55E", p: 100 }];
      const list = $("tz-stops"), preview = $("tz-preview"), out = $("tz-output");
      function css() {
        const type = $("tz-type").value;
        const s = stops.slice().sort(function (a, b) { return a.p - b.p; }).map(function (x) { return x.c + " " + x.p + "%"; }).join(", ");
        if (type === "linear") return "linear-gradient(" + $("tz-angle").value + "deg, " + s + ")";
        if (type === "radial") return "radial-gradient(circle, " + s + ")";
        return "conic-gradient(from " + $("tz-angle").value + "deg, " + s + ")";
      }
      function renderStops() {
        list.innerHTML = stops.map(function (s, i) {
          return '<div class="field-row" style="grid-template-columns:70px 1fr auto;align-items:center;margin-bottom:10px;">' +
            '<input type="color" data-i="' + i + '" data-k="c" value="' + s.c + '" aria-label="Color ' + (i + 1) + '" style="width:60px;height:40px;border:none;background:none;">' +
            '<input type="range" data-i="' + i + '" data-k="p" min="0" max="100" value="' + s.p + '" aria-label="Position ' + (i + 1) + '">' +
            '<button type="button" class="line-item-remove" data-rm="' + i + '" aria-label="Remove color"' + (stops.length <= 2 ? " disabled" : "") + ">" + tzIcon("trash") + "</button></div>";
        }).join("");
      }
      function run() {
        const g = css();
        preview.style.background = g;
        out.value = "background: " + g + ";";
        $("tz-angle-wrap").style.display = $("tz-type").value === "radial" ? "none" : "";
        $("tz-angle-out").textContent = $("tz-angle").value + "\u00b0";
      }
      on(list, "input", function (e) {
        const t = e.target, i = parseInt(t.getAttribute("data-i"), 10);
        if (isNaN(i)) return;
        stops[i][t.getAttribute("data-k")] = t.getAttribute("data-k") === "p" ? parseInt(t.value, 10) : t.value;
        run();
      });
      on(list, "click", function (e) {
        const b = e.target.closest("[data-rm]");
        if (!b || stops.length <= 2) return;
        stops.splice(parseInt(b.getAttribute("data-rm"), 10), 1);
        renderStops(); run();
      });
      on($("tz-add"), "click", function () {
        if (stops.length >= 6) { TZ.showToast("Up to 6 colors"); return; }
        stops.push({ c: "#" + Math.floor(Math.random() * 0xffffff).toString(16).padStart(6, "0"), p: 50 });
        renderStops(); run();
      });
      on($("tz-random"), "click", function () {
        const rc = function () { return "#" + Math.floor(Math.random() * 0xffffff).toString(16).padStart(6, "0"); };
        stops = [{ c: rc(), p: 0 }, { c: rc(), p: 100 }];
        $("tz-angle").value = Math.floor(Math.random() * 360);
        renderStops(); run();
      });
      on($("tz-type"), "change", run);
      on($("tz-angle"), "input", run);
      on($("tz-copy"), "click", function () { TZ.copyToClipboard(out.value, "CSS copied"); });
      renderStops(); run();
    },
  };

  /* ============================================================= JWT DECODER */

  window.TZTools.jwtDecoder = {
    init: function () {
      const input = $("tz-input"), outEl = $("tz-result");
      function b64url(s) {
        s = s.replace(/-/g, "+").replace(/_/g, "/");
        while (s.length % 4) s += "=";
        const bin = atob(s);
        const bytes = new Uint8Array(bin.length);
        for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
        return new TextDecoder().decode(bytes);
      }
      function run() {
        const token = input.value.trim().replace(/^Bearer\s+/i, "");
        if (!token) { outEl.style.display = "none"; return; }
        const parts = token.split(".");
        if (parts.length < 2) { showResult(outEl, "That doesn\u2019t look like a JWT. A token has three parts separated by dots.", "error"); return; }
        try {
          const header = JSON.parse(b64url(parts[0]));
          const payload = JSON.parse(b64url(parts[1]));
          const now = Date.now() / 1000;
          const when = function (v) { return typeof v === "number" ? new Date(v * 1000).toLocaleString() + " (" + new Date(v * 1000).toISOString() + ")" : null; };
          let status = "";
          if (typeof payload.exp === "number") status = payload.exp < now ? "Expired" : "Not expired yet";
          let claims = "";
          [["iss", "Issuer"], ["sub", "Subject"], ["aud", "Audience"], ["iat", "Issued at"], ["nbf", "Not valid before"], ["exp", "Expires"]].forEach(function (c) {
            if (payload[c[0]] == null) return;
            const v = ["iat", "nbf", "exp"].indexOf(c[0]) !== -1 ? (when(payload[c[0]]) || String(payload[c[0]])) : (typeof payload[c[0]] === "object" ? JSON.stringify(payload[c[0]]) : String(payload[c[0]]));
            claims += "<tr><td><strong>" + c[1] + "</strong></td><td>" + TZ.escapeHtml(v) + "</td></tr>";
          });
          outEl.style.display = "block";
          outEl.className = "result-box" + (status === "Expired" ? " error" : " success");
          outEl.innerHTML =
            "<p><strong>Algorithm:</strong> " + TZ.escapeHtml(String(header.alg || "unknown")) + (status ? " &nbsp;\u00b7&nbsp; <strong>Status:</strong> " + status : "") + "</p>" +
            (claims ? '<table class="invoice-table" style="margin:10px 0;"><tbody>' + claims + "</tbody></table>" : "") +
            "<h4>Header</h4><pre>" + TZ.escapeHtml(JSON.stringify(header, null, 2)) + "</pre>" +
            "<h4 style=\"margin-top:12px;\">Payload</h4><pre>" + TZ.escapeHtml(JSON.stringify(payload, null, 2)) + "</pre>" +
            '<p class="field-hint" style="margin-top:10px;">The signature is not verified \u2014 this tool only decodes the token so you can read it.</p>';
        } catch (e) {
          showResult(outEl, "Couldn\u2019t decode that token. Check that you copied the whole JWT.", "error");
        }
      }
      on(input, "input", run);
      on($("tz-reset"), "click", function () { input.value = ""; outEl.style.display = "none"; });
      on($("tz-sample"), "click", function () {
        input.value = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c";
        run();
      });
    },
  };

  /* ============================================================= BARCODE GENERATOR */

  window.TZTools.barcodeGenerator = {
    init: function () {
      const resultEl = $("tz-result");
      const svg = $("tz-barcode");
      let ok = false;
      const HINTS = {
        CODE128: "Any text or numbers (most flexible).",
        EAN13: "12 digits (the 13th check digit is added for you).",
        EAN8: "7 digits (the 8th check digit is added for you).",
        UPC: "11 digits (the 12th check digit is added for you).",
        CODE39: "Capital letters, digits and - . $ / + % and space.",
        ITF14: "13 digits (the 14th check digit is added for you).",
      };
      function run() {
        const fmt = $("tz-format").value;
        $("tz-hint").textContent = HINTS[fmt];
        const text = $("tz-text").value;
        if (typeof JsBarcode === "undefined") { showResult(resultEl, libMissingMessage("the barcode engine"), "error"); return; }
        if (!text) { svg.innerHTML = ""; resultEl.style.display = "none"; ok = false; return; }
        try {
          svg.innerHTML = "";
          JsBarcode(svg, text, { format: fmt, width: parseFloat($("tz-width").value) || 2, height: parseInt($("tz-height").value, 10) || 100, displayValue: $("tz-show").checked, margin: 16, background: "#ffffff", lineColor: "#000000", valid: function (v) { ok = v; } });
          resultEl.style.display = ok ? "none" : "block";
          if (!ok) showResult(resultEl, "That value isn\u2019t valid for " + fmt + ". " + HINTS[fmt], "error");
        } catch (e) {
          ok = false; svg.innerHTML = "";
          showResult(resultEl, "That value isn\u2019t valid for " + fmt + ". " + HINTS[fmt], "error");
        }
      }
      ["tz-format", "tz-text", "tz-width", "tz-height", "tz-show"].forEach(function (id) { on($(id), "input", run); on($(id), "change", run); });
      on($("tz-svg"), "click", function () {
        if (!ok) { TZ.showToast("Enter a valid value first"); return; }
        TZ.downloadBlob(new Blob([new XMLSerializer().serializeToString(svg)], { type: "image/svg+xml" }), "barcode.svg");
      });
      on($("tz-png"), "click", async function () {
        if (!ok) { TZ.showToast("Enter a valid value first"); return; }
        const xml = new XMLSerializer().serializeToString(svg);
        const im = await loadImage("data:image/svg+xml;charset=utf-8," + encodeURIComponent(xml));
        const k = 3, c = document.createElement("canvas");
        c.width = (parseFloat(svg.getAttribute("width")) || im.width) * k;
        c.height = (parseFloat(svg.getAttribute("height")) || im.height) * k;
        const ctx = c.getContext("2d");
        ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, c.width, c.height);
        ctx.drawImage(im, 0, 0, c.width, c.height);
        TZ.downloadBlob(await canvasToBlob(c, "image/png"), "barcode.png");
      });
      on($("tz-reset"), "click", function () { $("tz-text").value = "ToolziHub"; $("tz-format").value = "CODE128"; run(); });
      $("tz-text").value = "ToolziHub";
      run();
    },
  };

  /* ============================================================= RESUME BUILDER */

  window.TZTools.resumeBuilder = {
    init: function () {
      let exp = [], edu = [];
      const g = function (id) { return ($(id) && $(id).value || "").trim(); };
      const EXAMPLE = {
        name: "Alex Morgan", title: "Marketing Manager", email: "alex.morgan@email.com", phone: "+1 555 123 4567", location: "Toronto, Canada", links: "linkedin.com/in/alexmorgan",
        summary: "Results-driven marketing manager with 7+ years of experience growing brands through data-led campaigns, content strategy and team leadership.",
        skills: "Campaign strategy, SEO, Google Analytics, Content marketing, Team leadership, Budget management",
        exp: [{ role: "Marketing Manager", org: "Northwind Co.", dates: "2021 \u2013 Present", bullets: "Grew organic traffic by 120% in 18 months\nManaged a team of 6 and a $400K annual budget\nLaunched 3 product campaigns that exceeded revenue targets by 25%" },
              { role: "Marketing Specialist", org: "Bright Labs", dates: "2018 \u2013 2021", bullets: "Ran email and social campaigns reaching 200K subscribers\nImproved conversion rate by 18% through A/B testing" }],
        edu: [{ role: "B.A. in Communications", org: "University of Toronto", dates: "2014 \u2013 2018" }],
      };

      function entryHtml(kind, i, e) {
        const isExp = kind === "exp";
        return '<div class="tz-entry" style="border:1px solid var(--border-soft);border-radius:12px;padding:14px;margin-bottom:12px;">' +
          '<div class="field-row"><div class="field"><label class="field-label">' + (isExp ? "Job title" : "Degree / course") + '</label><input type="text" class="input-field" data-k="' + kind + '" data-i="' + i + '" data-f="role" value="' + TZ.escapeHtml(e.role || "") + '"></div>' +
          '<div class="field"><label class="field-label">' + (isExp ? "Company" : "School") + '</label><input type="text" class="input-field" data-k="' + kind + '" data-i="' + i + '" data-f="org" value="' + TZ.escapeHtml(e.org || "") + '"></div></div>' +
          '<div class="field"><label class="field-label">Dates</label><input type="text" class="input-field" data-k="' + kind + '" data-i="' + i + '" data-f="dates" placeholder="e.g. 2021 \u2013 Present" value="' + TZ.escapeHtml(e.dates || "") + '"></div>' +
          (isExp ? '<div class="field"><label class="field-label">Achievements (one per line)</label><textarea class="input-area" style="min-height:90px;" data-k="exp" data-i="' + i + '" data-f="bullets">' + TZ.escapeHtml(e.bullets || "") + "</textarea></div>" : "") +
          '<button type="button" class="btn btn-outline btn-sm" data-rm="' + kind + '" data-i="' + i + '">Remove</button></div>';
      }
      function renderEntries() {
        $("tz-exp-list").innerHTML = exp.map(function (e, i) { return entryHtml("exp", i, e); }).join("");
        $("tz-edu-list").innerHTML = edu.map(function (e, i) { return entryHtml("edu", i, e); }).join("");
      }
      function lines(t) { return t.split("\n").map(function (x) { return x.trim(); }).filter(Boolean); }
      function contact() {
        return [g("tz-email"), g("tz-phone"), g("tz-location"), g("tz-links")].filter(Boolean);
      }
      function preview() {
        const modern = $("tz-template").value === "modern";
        const accent = modern ? $("tz-accent").value : "#111111";
        const h = function (t) { return '<h4 style="margin:16px 0 6px;font-size:.78rem;letter-spacing:.08em;text-transform:uppercase;color:' + accent + ';border-bottom:1px solid ' + (modern ? accent : "#999") + ';padding-bottom:3px;">' + t + "</h4>"; };
        let html = '<div style="text-align:' + (modern ? "left" : "center") + ';"><div style="font-size:1.5rem;font-weight:700;color:' + accent + ';">' + TZ.escapeHtml(g("tz-name") || "Your Name") + "</div>" +
          (g("tz-title") ? '<div style="font-size:.95rem;color:#444;">' + TZ.escapeHtml(g("tz-title")) + "</div>" : "") +
          '<div style="font-size:.8rem;color:#555;margin-top:4px;">' + TZ.escapeHtml(contact().join("  |  ")) + "</div></div>";
        if (g("tz-summary")) html += h("Summary") + '<p style="font-size:.85rem;margin:0;">' + TZ.escapeHtml(g("tz-summary")) + "</p>";
        if (exp.length) {
          html += h("Experience");
          exp.forEach(function (e) {
            html += '<div style="margin-bottom:8px;font-size:.85rem;"><div style="display:flex;justify-content:space-between;gap:8px;"><strong>' + TZ.escapeHtml(e.role || "") + (e.org ? ", " + TZ.escapeHtml(e.org) : "") + "</strong><span style=\"color:#555;white-space:nowrap;\">" + TZ.escapeHtml(e.dates || "") + "</span></div>" +
              (lines(e.bullets || "").length ? '<ul style="margin:4px 0 0 18px;padding:0;">' + lines(e.bullets).map(function (b) { return "<li>" + TZ.escapeHtml(b) + "</li>"; }).join("") + "</ul>" : "") + "</div>";
          });
        }
        if (edu.length) {
          html += h("Education");
          edu.forEach(function (e) { html += '<div style="display:flex;justify-content:space-between;gap:8px;font-size:.85rem;margin-bottom:4px;"><span><strong>' + TZ.escapeHtml(e.role || "") + "</strong>" + (e.org ? ", " + TZ.escapeHtml(e.org) : "") + '</span><span style="color:#555;white-space:nowrap;">' + TZ.escapeHtml(e.dates || "") + "</span></div>"; });
        }
        if (g("tz-skills")) html += h("Skills") + '<p style="font-size:.85rem;margin:0;">' + TZ.escapeHtml(g("tz-skills")) + "</p>";
        $("tz-preview").innerHTML = html;
      }

      on($("tz-form"), "input", function (e) {
        const t = e.target, k = t.getAttribute("data-k");
        if (k) { (k === "exp" ? exp : edu)[parseInt(t.getAttribute("data-i"), 10)][t.getAttribute("data-f")] = t.value; }
        preview();
      });
      on($("tz-form"), "change", preview);
      on($("tz-form"), "click", function (e) {
        const b = e.target.closest("[data-rm]");
        if (!b) return;
        (b.getAttribute("data-rm") === "exp" ? exp : edu).splice(parseInt(b.getAttribute("data-i"), 10), 1);
        renderEntries(); preview();
      });
      on($("tz-add-exp"), "click", function () { exp.push({}); renderEntries(); preview(); });
      on($("tz-add-edu"), "click", function () { edu.push({}); renderEntries(); preview(); });
      on($("tz-example"), "click", function () {
        $("tz-name").value = EXAMPLE.name; $("tz-title").value = EXAMPLE.title; $("tz-email").value = EXAMPLE.email; $("tz-phone").value = EXAMPLE.phone;
        $("tz-location").value = EXAMPLE.location; $("tz-links").value = EXAMPLE.links; $("tz-summary").value = EXAMPLE.summary; $("tz-skills").value = EXAMPLE.skills;
        exp = JSON.parse(JSON.stringify(EXAMPLE.exp)); edu = JSON.parse(JSON.stringify(EXAMPLE.edu));
        renderEntries(); preview();
      });
      on($("tz-reset"), "click", function () {
        ["tz-name", "tz-title", "tz-email", "tz-phone", "tz-location", "tz-links", "tz-summary", "tz-skills"].forEach(function (id) { $(id).value = ""; });
        exp = [{}]; edu = [{}]; renderEntries(); preview();
      });

      on($("tz-run"), "click", function () {
        if (!window.jspdf) { TZ.showToast(libMissingMessage("the PDF writer")); return; }
        const modern = $("tz-template").value === "modern";
        const hex = $("tz-accent").value;
        const rgb = modern ? [parseInt(hex.slice(1, 3), 16), parseInt(hex.slice(3, 5), 16), parseInt(hex.slice(5, 7), 16)] : [17, 17, 17];
        const base = parseInt($("tz-fontsize").value, 10) || 10;
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF({ unit: "pt", format: "a4" });
        const W = doc.internal.pageSize.getWidth(), H = doc.internal.pageSize.getHeight(), M = 46;
        let y = M;
        function need(h) { if (y + h > H - M) { doc.addPage(); y = M; } }
        function wrap(text, size, width, style) { doc.setFont("helvetica", style || "normal"); doc.setFontSize(size); return doc.splitTextToSize(text, width); }
        function heading(t) {
          need(34); y += 10;
          doc.setFont("helvetica", "bold"); doc.setFontSize(base + 0.5); doc.setTextColor(rgb[0], rgb[1], rgb[2]);
          doc.text(t.toUpperCase(), M, y);
          doc.setDrawColor(modern ? rgb[0] : 150, modern ? rgb[1] : 150, modern ? rgb[2] : 150); doc.setLineWidth(0.6);
          doc.line(M, y + 4, W - M, y + 4); y += 18;
        }
        function para(t, size, color) {
          wrap(t, size, W - M * 2).forEach(function (l) { need(size + 4); doc.setTextColor(color || 40); doc.text(l, M, y); y += size + 3.5; });
        }
        const centerX = modern ? M : W / 2, align = modern ? "left" : "center";
        doc.setFont("helvetica", "bold"); doc.setFontSize(base + 14); doc.setTextColor(rgb[0], rgb[1], rgb[2]);
        doc.text(g("tz-name") || "Your Name", centerX, y + 8, { align: align }); y += 24;
        if (g("tz-title")) { doc.setFont("helvetica", "normal"); doc.setFontSize(base + 2); doc.setTextColor(70); doc.text(g("tz-title"), centerX, y, { align: align }); y += 16; }
        const ct = contact().join("   |   ");
        if (ct) { doc.setFont("helvetica", "normal"); doc.setFontSize(base - 1); doc.setTextColor(90); doc.text(doc.splitTextToSize(ct, W - M * 2), centerX, y, { align: align }); y += 14; }
        if (g("tz-summary")) { heading("Summary"); para(g("tz-summary"), base); }
        if (exp.some(function (e) { return e.role || e.org; })) {
          heading("Experience");
          exp.forEach(function (e) {
            if (!e.role && !e.org) return;
            need(30);
            doc.setFont("helvetica", "bold"); doc.setFontSize(base + 0.5); doc.setTextColor(20);
            doc.text((e.role || "") + (e.org ? ", " + e.org : ""), M, y);
            doc.setFont("helvetica", "normal"); doc.setTextColor(90); doc.text(e.dates || "", W - M, y, { align: "right" });
            y += base + 5;
            lines(e.bullets || "").forEach(function (b) {
              wrap(b, base, W - M * 2 - 14).forEach(function (l, idx) {
                need(base + 4); doc.setTextColor(40);
                if (idx === 0) doc.text("\u2022", M + 4, y);
                doc.text(l, M + 14, y); y += base + 3;
              });
            });
            y += 6;
          });
        }
        if (edu.some(function (e) { return e.role || e.org; })) {
          heading("Education");
          edu.forEach(function (e) {
            if (!e.role && !e.org) return;
            need(20);
            doc.setFont("helvetica", "bold"); doc.setFontSize(base + 0.5); doc.setTextColor(20);
            doc.text((e.role || "") + (e.org ? ", " + e.org : ""), M, y);
            doc.setFont("helvetica", "normal"); doc.setTextColor(90); doc.text(e.dates || "", W - M, y, { align: "right" });
            y += base + 6;
          });
        }
        if (g("tz-skills")) { heading("Skills"); para(g("tz-skills"), base); }
        doc.save((g("tz-name") || "resume").replace(/[^a-z0-9-_]+/gi, "-") + "-resume.pdf");
        TZ.showToast("Resume PDF downloaded");
      });

      exp = [{}]; edu = [{}];
      renderEntries(); preview();
    },
  };


  /* =====================================================================
     v13 — EMAIL TOOLS
     ===================================================================== */

  const MAILTM = "https://api.mail.tm";
  // Two free mail services share the same open API. If one is blocked on a visitor's network, the other usually works.
  const MAIL_PROVIDERS = [
    { name: "mail.tm", base: "https://api.mail.tm", site: "https://mail.tm" },
    { name: "mail.gw", base: "https://api.mail.gw", site: "https://mail.gw" },
  ];
  const DISPOSABLE_DOMAINS = ["mailinator.com", "guerrillamail.com", "guerrillamail.net", "10minutemail.com", "10minutemail.net", "tempmail.com", "temp-mail.org", "temp-mail.io", "throwawaymail.com", "yopmail.com", "yopmail.fr", "trashmail.com", "getnada.com", "sharklasers.com", "maildrop.cc", "dispostable.com", "fakeinbox.com", "mailnesia.com", "mohmal.com", "emailondeck.com", "tempinbox.com", "mintemail.com", "spamgourmet.com", "mytemp.email", "burnermail.io", "mail.tm", "mail.gw", "moakt.com", "tmpmail.org", "tempail.com", "1secmail.com", "dropmail.me", "anonbox.net", "33mail.com", "emailfake.com", "inboxkitten.com"];
  const ROLE_NAMES = ["admin", "administrator", "info", "support", "sales", "contact", "help", "billing", "noreply", "no-reply", "postmaster", "webmaster", "abuse", "hello", "office", "team", "mail", "marketing", "hr", "jobs"];
  const POPULAR_MAIL_DOMAINS = ["gmail.com", "yahoo.com", "outlook.com", "hotmail.com", "icloud.com", "aol.com", "live.com", "msn.com", "protonmail.com", "proton.me", "yandex.com", "zoho.com", "gmx.com", "mail.com"];
  const EMAIL_RE = /^[A-Za-z0-9.!#$%&'*+\/=?^_`{|}~-]+@[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?(?:\.[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?)+$/;
  const EMAIL_FIND_RE = /[A-Za-z0-9._%+\-]+@[A-Za-z0-9](?:[A-Za-z0-9\-]*[A-Za-z0-9])?(?:\.[A-Za-z0-9](?:[A-Za-z0-9\-]*[A-Za-z0-9])?)*\.[A-Za-z]{2,}/g;

  function randomString(len, alphabet) {
    const chars = alphabet || "abcdefghijklmnopqrstuvwxyz0123456789";
    const out = [];
    const buf = new Uint32Array(len);
    (window.crypto || window.msCrypto).getRandomValues(buf);
    for (let i = 0; i < len; i++) out.push(chars[buf[i] % chars.length]);
    return out.join("");
  }

  function editDistance(a, b) {
    const dp = [];
    for (let i = 0; i <= a.length; i++) { dp[i] = [i]; }
    for (let j = 1; j <= b.length; j++) dp[0][j] = j;
    for (let i = 1; i <= a.length; i++) for (let j = 1; j <= b.length; j++)
      dp[i][j] = Math.min(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
    return dp[a.length][b.length];
  }

  /* ============================================================= TEMP MAIL */

  window.TZTools.tempMail = {
    init: function () {
      const statusEl = $("tz-status");
      const inboxEl = $("tz-inbox");
      const viewEl = $("tz-message");
      let acct = null;           // {address, password, token, id}
      let pollTimer = null;
      let known = {};            // id -> message summary
      let busy = false;
      let provider = null;       // the mail service currently in use

      function setStatus(msg, kind) { statusEl.textContent = msg || ""; statusEl.style.color = kind === "error" ? "var(--danger)" : "var(--muted)"; }

      async function api(path, opts) {
        const o = opts || {};
        const headers = { Accept: "application/json" };
        if (o.body) headers["Content-Type"] = "application/json";
        if (o.token) headers.Authorization = "Bearer " + o.token;
        const base = o.base || (acct && acct.base) || (provider && provider.base) || MAILTM;
        const ctl = ("AbortController" in window) ? new AbortController() : null;
        const timer = ctl ? setTimeout(function () { ctl.abort(); }, 15000) : null;
        let res;
        try {
          res = await fetch(base + path, { method: o.method || "GET", headers: headers, body: o.body ? JSON.stringify(o.body) : undefined, signal: ctl ? ctl.signal : undefined });
        } finally { if (timer) clearTimeout(timer); }
        if (res.status === 204) return null;
        const data = await res.json().catch(function () { return null; });
        if (!res.ok) { const e = new Error((data && (data.message || data["hydra:description"])) || ("Error " + res.status)); e.status = res.status; throw e; }
        return data;
      }

      function setServiceNote() {
        const link = $("tz-service-note");
        if (link && provider) link.innerHTML = 'Using <a href="' + provider.site + '" target="_blank" rel="noopener">' + provider.name + "</a>";
      }

      async function loadDomains() {
        const sel = $("tz-domain");
        const choice = $("tz-service") ? $("tz-service").value : "auto";
        const order = MAIL_PROVIDERS.filter(function (p) { return choice === "auto" || p.name === choice; });
        $("tz-retry").style.display = "none";
        sel.innerHTML = '<option value="">Loading\u2026</option>';
        setStatus("Connecting to the mail service\u2026");
        let lastErr = "";
        for (let i = 0; i < order.length; i++) {
          try {
            const d = await api("/domains", { base: order[i].base });
            const raw = Array.isArray(d) ? d : (d && (d["hydra:member"] || d.member)) || [];
            const list = raw.filter(function (x) { return x && x.domain && x.isActive !== false; });
            if (!list.length) throw new Error("No domains");
            provider = order[i];
            sel.innerHTML = "";
            list.forEach(function (x) { const o = document.createElement("option"); o.value = x.domain; o.textContent = "@" + x.domain; sel.appendChild(o); });
            setServiceNote();
            setStatus("Pick a name and press Create address \u2014 or just press Create for a random one.");
            return true;
          } catch (e) { lastErr = (e && e.name === "AbortError") ? "timed out" : (e && e.message) || "failed"; }
        }
        provider = null;
        sel.innerHTML = '<option value="">Unavailable</option>';
        $("tz-retry").style.display = "";
        setStatus("Couldn\u2019t reach the mail service (" + lastErr + "). This usually means your network, a VPN or an ad-blocker is blocking it. Try another mail service from the menu above, switch network (for example mobile data or Wi-Fi), or turn off the blocker \u2014 then press Retry.", "error");
        return false;
      }

      function saveSession() { try { if (acct) sessionStorage.setItem("tz-tempmail", JSON.stringify(acct)); else sessionStorage.removeItem("tz-tempmail"); } catch (e) {} }

      function showAddress() {
        $("tz-address").textContent = acct ? acct.address : "\u2014";
        $("tz-box").style.display = acct ? "" : "none";
        $("tz-setup").style.display = acct ? "none" : "";
        inboxEl.innerHTML = acct ? '<p class="field-hint" style="padding:14px;">Waiting for emails\u2026 they appear here automatically.</p>' : "";
        viewEl.style.display = "none";
      }

      async function createAddress() {
        if (busy) return;
        const domain = $("tz-domain").value;
        if (!domain || !provider) { TZ.showToast("The mail service isn\u2019t reachable yet \u2014 press Retry"); return; }
        busy = true;
        const btn = $("tz-create");
        setBtnLoading(btn, true, "Creating\u2026");
        try {
          let user = $("tz-username").value.trim().toLowerCase().replace(/[^a-z0-9._-]/g, "");
          if (!user) user = randomString(10);
          const password = randomString(18, "abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789");
          let made = null;
          for (let attempt = 0; attempt < 3 && !made; attempt++) {
            const address = user + "@" + domain;
            try { made = await api("/accounts", { method: "POST", body: { address: address, password: password } }); acct = { address: address, password: password, id: made.id, base: provider.base, service: provider.name }; }
            catch (e) {
              if (e.status === 422 || e.status === 409) { user = (attempt === 0 && $("tz-username").value.trim() ? user + randomString(3) : randomString(10)); continue; }
              throw e;
            }
          }
          if (!acct) throw new Error("That name is taken. Try another.");
          const t = await api("/token", { method: "POST", body: { address: acct.address, password: acct.password } });
          acct.token = t.token;
          known = {};
          saveSession();
          showAddress();
          startPolling();
          setStatus("");
        } catch (e) {
          acct = null;
          setStatus(e.message || "Couldn\u2019t create the address. Try again.", "error");
        }
        setBtnLoading(btn, false);
        busy = false;
      }

      function timeAgo(iso) {
        const s = Math.max(0, (Date.now() - new Date(iso).getTime()) / 1000);
        if (s < 60) return "just now";
        if (s < 3600) return Math.floor(s / 60) + " min ago";
        if (s < 86400) return Math.floor(s / 3600) + " h ago";
        return new Date(iso).toLocaleDateString();
      }

      function renderInbox() {
        const list = Object.keys(known).map(function (k) { return known[k]; }).sort(function (a, b) { return new Date(b.createdAt) - new Date(a.createdAt); });
        if (!list.length) { inboxEl.innerHTML = '<p class="field-hint" style="padding:14px;">Waiting for emails\u2026 they appear here automatically.</p>'; return; }
        inboxEl.innerHTML = list.map(function (m) {
          const from = (m.from && (m.from.name || m.from.address)) || "Unknown sender";
          return '<button type="button" class="tz-mail-row' + (m.seen ? "" : " unread") + '" data-id="' + TZ.escapeHtml(m.id) + '"><span class="dot"></span><span class="who"><strong>' + TZ.escapeHtml(from) + "</strong><em>" + timeAgo(m.createdAt) + "</em></span><span class=\"subj\">" + TZ.escapeHtml(m.subject || "(no subject)") + "</span><span class=\"intro\">" + TZ.escapeHtml(m.intro || "") + "</span></button>";
        }).join("");
      }

      async function refresh(manual) {
        if (!acct || !acct.token) return;
        try {
          const d = await api("/messages", { token: acct.token });
          const arr = d["hydra:member"] || d.member || [];
          let added = 0;
          arr.forEach(function (m) { if (!known[m.id]) { added++; known[m.id] = m; } else { known[m.id].seen = m.seen; } });
          renderInbox();
          if (added && !manual) TZ.showToast("New email received");
          $("tz-count").textContent = Object.keys(known).length + " message" + (Object.keys(known).length === 1 ? "" : "s");
          setStatus("");
        } catch (e) {
          if (e.status === 401) { setStatus("This inbox has expired. Create a new address.", "error"); stopPolling(); }
          else if (manual) setStatus("Couldn\u2019t refresh. Check your connection.", "error");
        }
      }

      function startPolling() {
        stopPolling();
        pollTimer = setInterval(function () { if (!document.hidden && $("tz-auto").checked) refresh(false); }, 8000);
        refresh(true);
      }
      function stopPolling() { if (pollTimer) clearInterval(pollTimer); pollTimer = null; }

      function smartExtract(text) {
        const out = { codes: [], links: [] };
        const t = text || "";
        const near = /(?:code|otp|pin|passcode|verification|verify|security|one[- ]time|confirm)[^0-9]{0,40}(\d{4,8})\b|\b(\d{4,8})\b[^0-9]{0,30}(?:is your|is the|is my)/gi;
        let m;
        while ((m = near.exec(t)) !== null) { const c = m[1] || m[2]; if (c && out.codes.indexOf(c) === -1) out.codes.push(c); }
        if (!out.codes.length) { const any = t.match(/\b\d{6}\b/); if (any) out.codes.push(any[0]); }
        const urls = t.match(/https?:\/\/[^\s<>"')\]]+/g) || [];
        urls.forEach(function (u) {
          u = u.replace(/[.,;]+$/, "");
          if (/verif|confirm|activat|reset|magic|token|login|signin|auth|click|redirect|validate/i.test(u) && out.links.indexOf(u) === -1) out.links.push(u);
        });
        return out;
      }

      async function openMessage(id) {
        viewEl.style.display = "block";
        viewEl.innerHTML = '<p class="field-hint">Loading\u2026</p>';
        try {
          const m = await api("/messages/" + id, { token: acct.token });
          if (known[id]) known[id].seen = true;
          renderInbox();
          const text = m.text || (m.html && m.html.join ? m.html.join("\n").replace(/<style[\s\S]*?<\/style>/gi, "").replace(/<[^>]+>/g, " ").replace(/\s+/g, " ") : "") || "";
          const smart = smartExtract(text + " " + (m.html && m.html.join ? m.html.join(" ") : ""));
          let smartHtml = "";
          if (smart.codes.length) smartHtml += '<div class="tz-smart"><strong>Verification code</strong> ' + smart.codes.slice(0, 3).map(function (c) { return '<button type="button" class="btn btn-accent btn-sm" data-copy="' + TZ.escapeHtml(c) + '">' + TZ.escapeHtml(c) + " \u00b7 Copy</button>"; }).join(" ") + "</div>";
          if (smart.links.length) smartHtml += '<div class="tz-smart"><strong>Verification links</strong>' + smart.links.slice(0, 4).map(function (u) { return '<div class="tz-link"><span>' + TZ.escapeHtml(u.length > 70 ? u.slice(0, 70) + "\u2026" : u) + '</span><button type="button" class="btn btn-outline btn-sm" data-copy="' + TZ.escapeHtml(u) + '">Copy</button><a class="btn btn-outline btn-sm" href="' + TZ.escapeHtml(u) + '" target="_blank" rel="noopener noreferrer nofollow">Open</a></div>'; }).join("") + "</div>";
          viewEl.innerHTML =
            '<div class="tz-mail-head"><h4>' + TZ.escapeHtml(m.subject || "(no subject)") + "</h4><p>From <strong>" + TZ.escapeHtml((m.from && (m.from.name ? m.from.name + " <" + m.from.address + ">" : m.from.address)) || "unknown") + "</strong> \u00b7 " + new Date(m.createdAt).toLocaleString() + "</p></div>" +
            smartHtml +
            '<pre class="tz-mail-body">' + TZ.escapeHtml(text.trim() || "(This email has no text content.)") + "</pre>" +
            (m.html && m.html.length ? '<details><summary>Show the original formatted email</summary><iframe sandbox="" referrerpolicy="no-referrer" style="width:100%;min-height:360px;border:1px solid var(--border-soft);border-radius:10px;background:#fff;margin-top:10px;" srcdoc="' + TZ.escapeHtml('<meta http-equiv="Content-Security-Policy" content="default-src \'none\'; img-src data:; style-src \'unsafe-inline\'"><base target="_blank">' + m.html.join("\n")) + '"></iframe><p class="field-hint">Scripts and remote images are blocked for your safety.</p></details>' : "") +
            '<div class="toolbar-row"><button type="button" class="btn btn-outline btn-sm" id="tz-close-msg">Close</button></div>';
          $("tz-close-msg").addEventListener("click", function () { viewEl.style.display = "none"; });
        } catch (e) { viewEl.innerHTML = '<p class="field-hint" style="color:var(--danger);">Couldn\u2019t open that email.</p>'; }
      }

      on(inboxEl, "click", function (e) { const b = e.target.closest(".tz-mail-row"); if (b) openMessage(b.getAttribute("data-id")); });
      on(viewEl, "click", function (e) { const b = e.target.closest("[data-copy]"); if (b) TZ.copyToClipboard(b.getAttribute("data-copy"), "Copied"); });
      on($("tz-create"), "click", createAddress);
      on($("tz-retry"), "click", loadDomains);
      on($("tz-service"), "change", loadDomains);
      on($("tz-random"), "click", function () { $("tz-username").value = randomString(10); });
      on($("tz-copy"), "click", function () { if (acct) TZ.copyToClipboard(acct.address, "Email address copied"); });
      on($("tz-refresh"), "click", function () { refresh(true); });
      on($("tz-new"), "click", async function () {
        if (acct && acct.token) { try { await api("/accounts/" + acct.id, { method: "DELETE", token: acct.token }); } catch (e) {} }
        acct = null; known = {}; stopPolling(); saveSession(); showAddress();
        $("tz-username").value = "";
      });
      on($("tz-auto"), "change", function () { if ($("tz-auto").checked) refresh(true); });

      // resume an inbox opened earlier in this tab
      try {
        const saved = JSON.parse(sessionStorage.getItem("tz-tempmail") || "null");
        if (saved && saved.token) { acct = saved; }
      } catch (e) {}
      showAddress();
      loadDomains().then(function () { if (acct) startPolling(); });
    },
  };

  /* ============================================================= EMAIL ADDRESS CHECKER */

  window.TZTools.emailChecker = {
    init: function () {
      const resultEl = $("tz-table");
      async function mx(domain) {
        const urls = ["https://dns.google/resolve?name=" + encodeURIComponent(domain) + "&type=MX", "https://cloudflare-dns.com/dns-query?name=" + encodeURIComponent(domain) + "&type=MX"];
        for (let i = 0; i < urls.length; i++) {
          try {
            const r = await fetch(urls[i], { headers: { Accept: "application/dns-json" } });
            const j = await r.json();
            if (j.Status === 3) return "none";
            if (j.Answer && j.Answer.some(function (a) { return a.type === 15; })) return "yes";
            // fall back to A record: some domains accept mail without MX
            return j.Status === 0 ? "none" : "unknown";
          } catch (e) { /* try next resolver */ }
        }
        return "unknown";
      }
      function suggest(domain) {
        let best = null, bd = 3;
        POPULAR_MAIL_DOMAINS.forEach(function (d) { const dist = editDistance(domain, d); if (dist > 0 && dist < bd) { bd = dist; best = d; } });
        return bd <= 2 ? best : null;
      }
      on($("tz-run"), "click", async function () {
        const lines = $("tz-input").value.split(/[\n,;]+/).map(function (x) { return x.trim(); }).filter(Boolean).slice(0, 50);
        if (!lines.length) { TZ.showToast("Type at least one email address"); return; }
        const btn = $("tz-run");
        setBtnLoading(btn, true, "Checking\u2026");
        const doMx = $("tz-mx").checked;
        let rows = "";
        for (let i = 0; i < lines.length; i++) {
          const e = lines[i];
          const notes = [];
          let status = "Valid format", cls = "success";
          const valid = EMAIL_RE.test(e) && e.length <= 254 && e.split("@")[0].length <= 64 && !/\.\./.test(e);
          let mxCell = "\u2014";
          if (!valid) { status = "Invalid format"; cls = "error"; }
          else {
            const at = e.lastIndexOf("@"), local = e.slice(0, at).toLowerCase(), domain = e.slice(at + 1).toLowerCase();
            if (DISPOSABLE_DOMAINS.indexOf(domain) !== -1) { notes.push("Disposable / temporary mail domain"); cls = "warn"; }
            if (ROLE_NAMES.indexOf(local) !== -1) notes.push("Role-based address");
            const s = suggest(domain);
            if (s) { notes.push("Did you mean @" + s + "?"); cls = "warn"; }
            if (doMx) {
              const r = await mx(domain);
              mxCell = r === "yes" ? "Found" : r === "none" ? "Not found" : "Couldn\u2019t check";
              if (r === "none") { status = "Domain can\u2019t receive mail"; cls = "error"; }
            }
          }
          rows += "<tr><td>" + TZ.escapeHtml(e) + '</td><td><span class="tz-pill ' + cls + '">' + status + "</span></td><td>" + mxCell + "</td><td>" + TZ.escapeHtml(notes.join(" \u00b7 ") || "\u2014") + "</td></tr>";
          setProgress(((i + 1) / lines.length) * 100);
        }
        resultEl.innerHTML = '<div class="table-scroll"><table class="invoice-table"><thead><tr><th>Email</th><th>Result</th><th>Mail server</th><th>Notes</th></tr></thead><tbody>' + rows + "</tbody></table></div>" +
          '<p class="field-hint" style="margin-top:8px;">This checks the address format and whether the domain can receive mail. It can\u2019t confirm that a particular mailbox exists.</p>';
        setProgress(null);
        setBtnLoading(btn, false);
      });
      on($("tz-reset"), "click", function () { $("tz-input").value = ""; resultEl.innerHTML = ""; });
    },
  };

  /* ============================================================= EMAIL EXTRACTOR */

  window.TZTools.emailExtractor = {
    init: function () {
      const input = $("tz-input"), output = $("tz-output");
      function run() {
        let found = (input.value.match(EMAIL_FIND_RE) || []);
        if ($("tz-lower").checked) found = found.map(function (x) { return x.toLowerCase(); });
        if ($("tz-dedupe").checked) found = found.filter(function (x, i) { return found.indexOf(x) === i; });
        if ($("tz-sort").checked) found = found.slice().sort(function (a, b) { return a.localeCompare(b); });
        output.value = found.join("\n");
        const domains = {};
        found.forEach(function (x) { const d = x.split("@")[1].toLowerCase(); domains[d] = 1; });
        $("tz-stat-count").textContent = found.length.toLocaleString();
        $("tz-stat-domains").textContent = Object.keys(domains).length.toLocaleString();
      }
      ["tz-input", "tz-lower", "tz-dedupe", "tz-sort"].forEach(function (id) { on($(id), "input", run); on($(id), "change", run); });
      on($("tz-copy"), "click", function () { if (output.value) TZ.copyToClipboard(output.value, "Emails copied"); });
      on($("tz-comma"), "click", function () { if (output.value) TZ.copyToClipboard(output.value.split("\n").join(", "), "Copied as a comma-separated list"); });
      on($("tz-download"), "click", function () { if (output.value) TZ.downloadText("email\n" + output.value, "emails.csv", "text/csv"); });
      on($("tz-reset"), "click", function () { input.value = ""; run(); });
      run();
    },
  };

  /* ============================================================= EMAIL SIGNATURE GENERATOR */

  window.TZTools.emailSignature = {
    init: function () {
      const g = function (id) { return ($(id).value || "").trim(); };
      const safeUrl = function (u) { u = u.trim(); if (!u) return ""; if (!/^https?:\/\//i.test(u)) u = "https://" + u; return /^https?:\/\/[^\s"'<>]+$/i.test(u) ? u : ""; };
      let html = "";
      function build() {
        const accent = $("tz-accent").value, style = $("tz-style").value;
        const e = TZ.escapeHtml;
        const name = g("tz-name") || "Your Name";
        const lines = [];
        if (g("tz-title") || g("tz-company")) lines.push('<div style="font-size:13px;color:#555555;margin:2px 0 8px;">' + e([g("tz-title"), g("tz-company")].filter(Boolean).join(" | ")) + "</div>");
        const contacts = [];
        if (g("tz-phone")) contacts.push('<span style="color:#333333;">' + e(g("tz-phone")) + "</span>");
        if (g("tz-email")) contacts.push('<a href="mailto:' + e(g("tz-email")) + '" style="color:' + accent + ';text-decoration:none;">' + e(g("tz-email")) + "</a>");
        const site = safeUrl(g("tz-site"));
        if (site) contacts.push('<a href="' + e(site) + '" style="color:' + accent + ';text-decoration:none;">' + e(g("tz-site").replace(/^https?:\/\//i, "")) + "</a>");
        const sep = style === "compact" ? "  |  " : "<br>";
        if (contacts.length) lines.push('<div style="font-size:13px;line-height:1.6;">' + contacts.join(sep) + "</div>");
        if (g("tz-address")) lines.push('<div style="font-size:12px;color:#777777;margin-top:6px;">' + e(g("tz-address")) + "</div>");
        const img = safeUrl(g("tz-photo"));
        const imgCell = img ? '<td style="vertical-align:top;padding-right:14px;"><img src="' + e(img) + '" alt="" width="72" height="72" style="width:72px;height:72px;border-radius:' + (style === "modern" ? "50%" : "6px") + ';display:block;"></td>' : "";
        const bar = style === "simple" ? "" : "border-left:3px solid " + accent + ";padding-left:14px;";
        html = '<table cellpadding="0" cellspacing="0" border="0" style="font-family:Arial,Helvetica,sans-serif;color:#222222;"><tr>' + imgCell +
          '<td style="vertical-align:top;' + bar + '"><div style="font-size:17px;font-weight:bold;color:' + accent + ';">' + e(name) + "</div>" + lines.join("") + "</td></tr></table>";
        $("tz-preview").innerHTML = html;
        $("tz-code").value = html;
      }
      ["tz-name", "tz-title", "tz-company", "tz-phone", "tz-email", "tz-site", "tz-address", "tz-photo", "tz-accent", "tz-style"].forEach(function (id) { on($(id), "input", build); on($(id), "change", build); });
      on($("tz-copy-rich"), "click", async function () {
        try {
          if (window.ClipboardItem && navigator.clipboard && navigator.clipboard.write) {
            await navigator.clipboard.write([new ClipboardItem({ "text/html": new Blob([html], { type: "text/html" }), "text/plain": new Blob([$("tz-preview").innerText], { type: "text/plain" }) })]);
            TZ.showToast("Signature copied \u2014 paste it into your email settings");
            return;
          }
        } catch (e) { /* fall through */ }
        const r = document.createRange(); r.selectNodeContents($("tz-preview"));
        const s = window.getSelection(); s.removeAllRanges(); s.addRange(r);
        try { document.execCommand("copy"); TZ.showToast("Signature copied"); } catch (e) { TZ.showToast("Select the signature and copy it"); }
        s.removeAllRanges();
      });
      on($("tz-copy-html"), "click", function () { TZ.copyToClipboard(html, "HTML copied"); });
      on($("tz-download"), "click", function () { TZ.downloadText("<!DOCTYPE html><html><body>" + html + "</body></html>", "email-signature.html", "text/html"); });
      on($("tz-reset"), "click", function () { ["tz-name", "tz-title", "tz-company", "tz-phone", "tz-email", "tz-site", "tz-address", "tz-photo"].forEach(function (id) { $(id).value = ""; }); build(); });
      build();
    },
  };

  /* ============================================================= EMAIL HEADER ANALYZER */

  window.TZTools.emailHeaderAnalyzer = {
    init: function () {
      const out = $("tz-output");
      function unfold(raw) { return raw.replace(/\r\n?/g, "\n").replace(/\n[ \t]+/g, " "); }
      function parse(raw) {
        const map = {}, list = [];
        unfold(raw).split("\n").forEach(function (line) {
          const i = line.indexOf(":");
          if (i < 1 || /\s/.test(line.slice(0, i))) return;
          const k = line.slice(0, i).trim().toLowerCase(), v = line.slice(i + 1).trim();
          list.push([k, v]);
          if (!map[k]) map[k] = [];
          map[k].push(v);
        });
        return { map: map, list: list };
      }
      function pill(v) { const x = (v || "").toLowerCase(); const cls = x === "pass" ? "success" : (x === "fail" || x === "softfail" || x === "permerror") ? "error" : "warn"; return '<span class="tz-pill ' + cls + '">' + TZ.escapeHtml(v || "n/a") + "</span>"; }
      function run() {
        const raw = $("tz-input").value;
        if (!raw.trim()) { out.innerHTML = ""; return; }
        const p = parse(raw), m = p.map;
        if (!m.from && !m.received) { out.innerHTML = '<div class="result-box error">That doesn\u2019t look like email headers. Paste the full raw header block (it contains lines like From:, To: and Received:).</div>'; return; }
        const e = TZ.escapeHtml, first = function (k) { return m[k] ? m[k][0] : ""; };
        const auth = (m["authentication-results"] || []).join(" ; ") + " " + (m["received-spf"] || []).join(" ");
        const res = function (k) { const mm = auth.match(new RegExp("\\b" + k + "=([a-z]+)", "i")); return mm ? mm[1] : ""; };
        const spf = res("spf") || ((first("received-spf").match(/^(\w+)/) || [])[1] || "");
        let html = '<div class="stat-row"><div class="stat-chip"><strong>' + pill(spf) + "</strong><span>SPF</span></div><div class=\"stat-chip\"><strong>" + pill(res("dkim")) + "</strong><span>DKIM</span></div><div class=\"stat-chip\"><strong>" + pill(res("dmarc")) + "</strong><span>DMARC</span></div></div>";
        const rows = [["From", first("from")], ["To", first("to")], ["Reply-To", first("reply-to")], ["Return-Path", first("return-path")], ["Subject", first("subject")], ["Date", first("date")], ["Message-ID", first("message-id")], ["Mailer", first("x-mailer") || first("user-agent")]].filter(function (r) { return r[1]; });
        html += '<div class="table-scroll"><table class="invoice-table"><tbody>' + rows.map(function (r) { return "<tr><td><strong>" + r[0] + "</strong></td><td style=\"word-break:break-all;\">" + e(r[1]) + "</td></tr>"; }).join("") + "</tbody></table></div>";
        const hops = (m.received || []).slice().reverse();
        if (hops.length) {
          let prev = null;
          html += '<h4 style="margin:18px 0 8px;">Journey of the message (' + hops.length + " hop" + (hops.length === 1 ? "" : "s") + ")</h4>";
          html += '<div class="table-scroll"><table class="invoice-table"><thead><tr><th>#</th><th>From \u2192 By</th><th>Time</th><th>Delay</th></tr></thead><tbody>';
          hops.forEach(function (h, i) {
            const from = (h.match(/from\s+(\S+)/i) || [])[1] || "?", by = (h.match(/by\s+(\S+)/i) || [])[1] || "?";
            const ds = (h.split(";").pop() || "").trim();
            const t = new Date(ds); const ok = !isNaN(t.getTime());
            let delay = "\u2014";
            if (ok && prev) { const sec = Math.round((t - prev) / 1000); delay = (sec < 0 ? "" : "+") + sec + " s"; }
            if (ok) prev = t;
            html += "<tr><td>" + (i + 1) + "</td><td style=\"word-break:break-all;\">" + e(from) + " \u2192 " + e(by) + "</td><td>" + (ok ? t.toLocaleString() : "\u2014") + "</td><td>" + delay + "</td></tr>";
          });
          html += "</tbody></table></div>";
        }
        html += '<p class="field-hint" style="margin-top:10px;">Authentication results come from the headers themselves. A \u201cpass\u201d means the receiving server verified the sender; \u201cfail\u201d or \u201csoftfail\u201d can be a sign of spoofing. Headers can be forged before they reach your server, so treat this as a guide.</p>';
        out.innerHTML = html;
      }
      on($("tz-input"), "input", run);
      on($("tz-reset"), "click", function () { $("tz-input").value = ""; out.innerHTML = ""; });
    },
  };

  /* ============================================================= MAILTO LINK GENERATOR */

  window.TZTools.mailtoGenerator = {
    init: function () {
      let link = "";
      function build() {
        const q = [];
        const add = function (k, id) { const v = $(id).value.trim(); if (v) q.push(k + "=" + encodeURIComponent(v).replace(/%2C/gi, ",")); };
        add("cc", "tz-cc"); add("bcc", "tz-bcc"); add("subject", "tz-subject");
        const body = $("tz-body").value.trim();
        if (body) q.push("body=" + encodeURIComponent(body.replace(/\r?\n/g, "\r\n")));
        const to = $("tz-to").value.trim().replace(/\s+/g, "");
        link = "mailto:" + encodeURIComponent(to).replace(/%40/g, "@").replace(/%2C/gi, ",") + (q.length ? "?" + q.join("&") : "");
        $("tz-link").value = link;
        $("tz-html").value = '<a href="' + TZ.escapeHtml(link) + '">' + TZ.escapeHtml($("tz-label").value.trim() || "Email us") + "</a>";
        $("tz-test").setAttribute("href", link);
      }
      ["tz-to", "tz-cc", "tz-bcc", "tz-subject", "tz-body", "tz-label"].forEach(function (id) { on($(id), "input", build); });
      on($("tz-copy-link"), "click", function () { TZ.copyToClipboard(link, "Link copied"); });
      on($("tz-copy-html"), "click", function () { TZ.copyToClipboard($("tz-html").value, "HTML copied"); });
      on($("tz-reset"), "click", function () { ["tz-to", "tz-cc", "tz-bcc", "tz-subject", "tz-body"].forEach(function (id) { $(id).value = ""; }); build(); });
      build();
    },
  };

  /* =====================================================================
     v13 — MEDIA TOOLS
     ===================================================================== */

  const LAMEJS_URL = "https://cdn.jsdelivr.net/npm/lamejs@1.2.1/lame.min.js";
  function loadScriptOnce(url) {
    return new Promise(function (resolve, reject) {
      if (document.querySelector('script[data-src="' + url + '"]')) { resolve(); return; }
      const s = document.createElement("script");
      s.src = url; s.async = true; s.setAttribute("data-src", url);
      s.onload = function () { resolve(); };
      s.onerror = function () { reject(new Error("load failed")); };
      document.head.appendChild(s);
    });
  }

  function floatTo16(f) {
    const out = new Int16Array(f.length);
    for (let i = 0; i < f.length; i++) { const s = Math.max(-1, Math.min(1, f[i])); out[i] = s < 0 ? s * 0x8000 : s * 0x7fff; }
    return out;
  }

  // channels: array of Float32Array (1 or 2); returns an MP3 Blob.
  async function encodeMp3(channels, rate, kbps, onProgress) {
    if (typeof lamejs === "undefined") await loadScriptOnce(LAMEJS_URL);
    const stereo = channels.length > 1;
    const enc = new lamejs.Mp3Encoder(stereo ? 2 : 1, rate, kbps);
    const left = floatTo16(channels[0]), right = stereo ? floatTo16(channels[1]) : null;
    const block = 1152, parts = [];
    for (let i = 0; i < left.length; i += block) {
      const l = left.subarray(i, i + block);
      const buf = stereo ? enc.encodeBuffer(l, right.subarray(i, i + block)) : enc.encodeBuffer(l);
      if (buf.length) parts.push(new Uint8Array(buf));
      if ((i / block) % 400 === 0) {
        if (onProgress) onProgress(i / left.length);
        await new Promise(function (r) { setTimeout(r, 0); });
      }
    }
    const end = enc.flush();
    if (end.length) parts.push(new Uint8Array(end));
    return new Blob(parts, { type: "audio/mpeg" });
  }

  function wavFromChannels(channels, rate) {
    if (channels.length === 1) return encodeWav(channels[0], rate);
    const n = channels[0].length, inter = new Float32Array(n * 2);
    for (let i = 0; i < n; i++) { inter[i * 2] = channels[0][i]; inter[i * 2 + 1] = channels[1][i]; }
    // stereo WAV
    const buf = new ArrayBuffer(44 + inter.length * 2), v = new DataView(buf);
    const w = function (o, s) { for (let i = 0; i < s.length; i++) v.setUint8(o + i, s.charCodeAt(i)); };
    w(0, "RIFF"); v.setUint32(4, 36 + inter.length * 2, true); w(8, "WAVE"); w(12, "fmt ");
    v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 2, true); v.setUint32(24, rate, true); v.setUint32(28, rate * 4, true); v.setUint16(32, 4, true); v.setUint16(34, 16, true);
    w(36, "data"); v.setUint32(40, inter.length * 2, true);
    let o = 44;
    for (let i = 0; i < inter.length; i++, o += 2) { const s = Math.max(-1, Math.min(1, inter[i])); v.setInt16(o, s < 0 ? s * 0x8000 : s * 0x7fff, true); }
    return new Blob([buf], { type: "audio/wav" });
  }

  async function decodeAudioFile(file) {
    const Ctx = window.AudioContext || window.webkitAudioContext;
    const ctx = new Ctx();
    const buf = await new Promise(function (resolve, reject) {
      fileToArrayBuffer(file).then(function (ab) { const p = ctx.decodeAudioData(ab, resolve, reject); if (p && p.catch) p.catch(reject); });
    });
    try { ctx.close(); } catch (e) {}
    return buf;
  }

  function clockText(sec) { sec = Math.max(0, Math.floor(sec)); const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60; return (h ? h + ":" + String(m).padStart(2, "0") : m) + ":" + String(s).padStart(2, "0"); }

  /* ============================================================= SCREEN RECORDER */

  window.TZTools.screenRecorder = {
    init: function () {
      const resultEl = $("tz-result"), video = $("tz-video");
      let rec = null, chunks = [], streams = [], tick = null, startedAt = 0, pausedMs = 0, pausedAt = 0, ctx = null, url = null, ext = "webm";

      if (!(navigator.mediaDevices && navigator.mediaDevices.getDisplayMedia)) {
        showResult(resultEl, "Screen recording isn\u2019t supported in this browser. Use Chrome, Edge or Firefox on a computer.", "error");
        $("tz-start").disabled = true;
      }
      function pickMime() {
        const list = ["video/webm;codecs=vp9,opus", "video/webm;codecs=vp8,opus", "video/webm", "video/mp4"];
        for (let i = 0; i < list.length; i++) if (window.MediaRecorder && MediaRecorder.isTypeSupported(list[i])) return list[i];
        return "";
      }
      function stopTracks() { streams.forEach(function (s) { s.getTracks().forEach(function (t) { t.stop(); }); }); streams = []; if (ctx) { try { ctx.close(); } catch (e) {} ctx = null; } }
      function setUi(state) {
        $("tz-start").disabled = state !== "idle";
        $("tz-pause").disabled = state === "idle";
        $("tz-stop").disabled = state === "idle";
        $("tz-pause").querySelector("span").textContent = state === "paused" ? "Resume" : "Pause";
        $("tz-dot").style.display = state === "recording" ? "inline-block" : "none";
      }
      function elapsed() { return ((pausedAt ? pausedAt : Date.now()) - startedAt - pausedMs) / 1000; }

      on($("tz-start"), "click", async function () {
        resultEl.style.display = "none";
        try {
          const display = await navigator.mediaDevices.getDisplayMedia({ video: { frameRate: 30 }, audio: $("tz-sys").checked });
          streams.push(display);
          let tracks = display.getVideoTracks().slice();
          const wantMic = $("tz-mic").checked, hasSys = display.getAudioTracks().length > 0;
          if (wantMic || hasSys) {
            const Ctx = window.AudioContext || window.webkitAudioContext;
            ctx = new Ctx();
            const dest = ctx.createMediaStreamDestination();
            if (hasSys) ctx.createMediaStreamSource(new MediaStream(display.getAudioTracks())).connect(dest);
            if (wantMic) {
              try { const mic = await navigator.mediaDevices.getUserMedia({ audio: true }); streams.push(mic); ctx.createMediaStreamSource(mic).connect(dest); }
              catch (e) { TZ.showToast("Microphone not available \u2014 recording without it"); }
            }
            tracks = tracks.concat(dest.stream.getAudioTracks());
          }
          const mime = pickMime();
          ext = /mp4/.test(mime) ? "mp4" : "webm";
          const stream = new MediaStream(tracks);
          rec = new MediaRecorder(stream, Object.assign({ videoBitsPerSecond: parseInt($("tz-quality").value, 10) || 5000000 }, mime ? { mimeType: mime } : {}));
          chunks = [];
          rec.ondataavailable = function (e) { if (e.data && e.data.size) chunks.push(e.data); };
          rec.onstop = function () {
            clearInterval(tick); stopTracks();
            const blob = new Blob(chunks, { type: rec.mimeType || "video/webm" });
            if (url) URL.revokeObjectURL(url);
            url = URL.createObjectURL(blob);
            video.src = url; video.style.display = "block";
            $("tz-download").style.display = ""; $("tz-download").dataset.size = blob.size;
            showResult(resultEl, "Recording ready \u2014 " + clockText(elapsed()) + " (" + TZ.formatBytes(blob.size) + "). Preview it below or download it.", "success");
            setUi("idle");
          };
          display.getVideoTracks()[0].addEventListener("ended", function () { if (rec && rec.state !== "inactive") rec.stop(); });
          rec.start(1000);
          startedAt = Date.now(); pausedMs = 0; pausedAt = 0;
          tick = setInterval(function () { $("tz-time").textContent = clockText(elapsed()); }, 250);
          video.style.display = "none"; $("tz-download").style.display = "none";
          setUi("recording");
        } catch (e) {
          stopTracks();
          showResult(resultEl, e && e.name === "NotAllowedError" ? "Screen sharing was cancelled or blocked." : "Couldn\u2019t start recording on this device.", "error");
          setUi("idle");
        }
      });
      on($("tz-pause"), "click", function () {
        if (!rec) return;
        if (rec.state === "recording") { rec.pause(); pausedAt = Date.now(); setUi("paused"); }
        else if (rec.state === "paused") { rec.resume(); pausedMs += Date.now() - pausedAt; pausedAt = 0; setUi("recording"); }
      });
      on($("tz-stop"), "click", function () { if (rec && rec.state !== "inactive") rec.stop(); });
      on($("tz-download"), "click", function () { if (url) { const a = document.createElement("a"); a.href = url; a.download = "screen-recording." + ext; document.body.appendChild(a); a.click(); a.remove(); } });
      on($("tz-reset"), "click", function () { if (rec && rec.state !== "inactive") rec.stop(); video.style.display = "none"; video.removeAttribute("src"); $("tz-download").style.display = "none"; resultEl.style.display = "none"; $("tz-time").textContent = "0:00"; });
      setUi("idle");
      $("tz-download").style.display = "none"; video.style.display = "none";
    },
  };

  /* ============================================================= VOICE RECORDER */

  window.TZTools.voiceRecorder = {
    init: function () {
      const resultEl = $("tz-result"), audioEl = $("tz-audio");
      let rec = null, chunks = [], stream = null, tick = null, startedAt = 0, pausedMs = 0, pausedAt = 0, url = null, blob = null, ctx = null, raf = 0, ext = "webm";

      if (!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia && window.MediaRecorder)) {
        showResult(resultEl, "Recording isn\u2019t supported in this browser.", "error");
        $("tz-start").disabled = true;
      }
      function setUi(state) {
        $("tz-start").disabled = state !== "idle";
        $("tz-pause").disabled = state === "idle";
        $("tz-stop").disabled = state === "idle";
        $("tz-pause").querySelector("span").textContent = state === "paused" ? "Resume" : "Pause";
      }
      function elapsed() { return ((pausedAt ? pausedAt : Date.now()) - startedAt - pausedMs) / 1000; }
      function meter(analyser) {
        const data = new Uint8Array(analyser.fftSize);
        (function loop() {
          analyser.getByteTimeDomainData(data);
          let peak = 0;
          for (let i = 0; i < data.length; i++) peak = Math.max(peak, Math.abs(data[i] - 128));
          $("tz-level").style.width = Math.min(100, peak / 128 * 140) + "%";
          raf = requestAnimationFrame(loop);
        })();
      }
      function cleanup() { clearInterval(tick); cancelAnimationFrame(raf); $("tz-level").style.width = "0%"; if (stream) stream.getTracks().forEach(function (t) { t.stop(); }); stream = null; if (ctx) { try { ctx.close(); } catch (e) {} ctx = null; } }

      on($("tz-start"), "click", async function () {
        resultEl.style.display = "none";
        try {
          stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: $("tz-clean").checked, noiseSuppression: $("tz-clean").checked, autoGainControl: $("tz-clean").checked } });
          const Ctx = window.AudioContext || window.webkitAudioContext;
          ctx = new Ctx();
          const an = ctx.createAnalyser(); an.fftSize = 512;
          ctx.createMediaStreamSource(stream).connect(an);
          meter(an);
          rec = new MediaRecorder(stream);
          ext = /mp4/.test(rec.mimeType) ? "m4a" : /ogg/.test(rec.mimeType) ? "ogg" : "webm";
          chunks = [];
          rec.ondataavailable = function (e) { if (e.data && e.data.size) chunks.push(e.data); };
          rec.onstop = function () {
            const dur = elapsed();
            cleanup();
            blob = new Blob(chunks, { type: rec.mimeType || "audio/webm" });
            if (url) URL.revokeObjectURL(url);
            url = URL.createObjectURL(blob);
            audioEl.src = url; audioEl.style.display = "block";
            $("tz-dl").style.display = ""; $("tz-dl-wav").style.display = "";
            showResult(resultEl, "Recording ready \u2014 " + clockText(dur) + " (" + TZ.formatBytes(blob.size) + ").", "success");
            setUi("idle");
          };
          rec.start(500);
          startedAt = Date.now(); pausedMs = 0; pausedAt = 0;
          tick = setInterval(function () { $("tz-time").textContent = clockText(elapsed()); }, 250);
          audioEl.style.display = "none"; $("tz-dl").style.display = "none"; $("tz-dl-wav").style.display = "none";
          setUi("recording");
        } catch (e) {
          cleanup();
          showResult(resultEl, e && e.name === "NotAllowedError" ? "Microphone access was blocked. Allow the microphone for this site and try again." : "Couldn\u2019t find a microphone.", "error");
          setUi("idle");
        }
      });
      on($("tz-pause"), "click", function () {
        if (!rec) return;
        if (rec.state === "recording") { rec.pause(); pausedAt = Date.now(); setUi("paused"); }
        else if (rec.state === "paused") { rec.resume(); pausedMs += Date.now() - pausedAt; pausedAt = 0; setUi("recording"); }
      });
      on($("tz-stop"), "click", function () { if (rec && rec.state !== "inactive") rec.stop(); });
      on($("tz-dl"), "click", function () { if (blob) TZ.downloadBlob(blob, "voice-recording." + ext); });
      on($("tz-dl-wav"), "click", async function () {
        if (!blob) return;
        const btn = $("tz-dl-wav");
        setBtnLoading(btn, true, "Converting\u2026");
        try {
          const buf = await decodeAudioFile(new File([blob], "rec"));
          const ch = [buf.getChannelData(0)];
          TZ.downloadBlob(wavFromChannels(ch, buf.sampleRate), "voice-recording.wav");
        } catch (e) { showResult(resultEl, "Couldn\u2019t convert to WAV in this browser. Use the original download instead.", "error"); }
        setBtnLoading(btn, false);
      });
      on($("tz-reset"), "click", function () { if (rec && rec.state !== "inactive") rec.stop(); audioEl.style.display = "none"; audioEl.removeAttribute("src"); $("tz-dl").style.display = "none"; $("tz-dl-wav").style.display = "none"; resultEl.style.display = "none"; $("tz-time").textContent = "0:00"; blob = null; });
      setUi("idle");
      audioEl.style.display = "none"; $("tz-dl").style.display = "none"; $("tz-dl-wav").style.display = "none";
    },
  };

  /* ============================================================= VIDEO TO MP3 */

  window.TZTools.videoToMp3 = {
    init: function () {
      const resultEl = $("tz-result");
      let file = null;
      const upload = setupSingleUpload({ iconKey: "volume", onFile: function (f) { file = f; $("tz-run").disabled = !f; } });
      on($("tz-run"), "click", async function () {
        if (!file) { TZ.showToast("Choose a video or audio file first"); return; }
        if (file.size > 400 * 1024 * 1024) { showResult(resultEl, "That file is very large. Try a file under 400 MB so your browser doesn\u2019t run out of memory.", "error"); return; }
        const btn = $("tz-run");
        setBtnLoading(btn, true, "Working\u2026");
        setProgress(2);
        try {
          showResult(resultEl, "Reading the audio from your file\u2026");
          const buf = await decodeAudioFile(file);
          const chs = [];
          const stereo = $("tz-channels").value === "stereo" && buf.numberOfChannels > 1;
          chs.push(buf.getChannelData(0));
          if (stereo) chs.push(buf.getChannelData(1));
          const fmt = $("tz-format").value;
          let blob;
          if (fmt === "wav") blob = wavFromChannels(chs, buf.sampleRate);
          else {
            showResult(resultEl, "Creating your MP3\u2026");
            blob = await encodeMp3(chs, buf.sampleRate, parseInt($("tz-bitrate").value, 10) || 192, function (p) { setProgress(5 + p * 90); });
          }
          TZ.downloadBlob(blob, baseName(file.name) + "." + (fmt === "wav" ? "wav" : "mp3"));
          showResult(resultEl, "Done \u2014 " + clockText(buf.duration) + " of audio saved (" + TZ.formatBytes(blob.size) + ").", "success");
        } catch (err) {
          showResult(resultEl, "Couldn\u2019t read the audio from that file. Your browser may not support its format \u2014 try MP4, WebM, MP3, WAV, M4A or OGG.", "error");
        }
        setProgress(null);
        setBtnLoading(btn, false);
      });
      on($("tz-format"), "change", function () { $("tz-bitrate-wrap").style.display = $("tz-format").value === "mp3" ? "" : "none"; });
      on($("tz-reset"), "click", function () { upload.clear(); file = null; $("tz-run").disabled = true; resultEl.style.display = "none"; });
      $("tz-run").disabled = true;
    },
  };

  /* ============================================================= AUDIO TRIMMER */

  window.TZTools.audioTrimmer = {
    init: function () {
      const resultEl = $("tz-result"), canvas = $("tz-wave");
      let file = null, buf = null, src = null, ctx = null, playTimer = null;
      const upload = setupSingleUpload({
        iconKey: "volume",
        onFile: async function (f) {
          stopPlay(); file = f; buf = null;
          $("tz-stage").style.display = "none";
          if (!f) return;
          try {
            showResult(resultEl, "Reading your audio\u2026");
            buf = await decodeAudioFile(f);
            resultEl.style.display = "none";
            $("tz-start").max = $("tz-end").max = buf.duration.toFixed(2);
            $("tz-start").step = $("tz-end").step = "0.01";
            $("tz-start").value = 0; $("tz-end").value = buf.duration.toFixed(2);
            $("tz-stage").style.display = "block";
            drawWave(); sync();
          } catch (e) { showResult(resultEl, "Couldn\u2019t read that audio file. Try MP3, WAV, M4A or OGG.", "error"); }
        },
      });

      function range() { let a = parseFloat($("tz-start").value) || 0, b = parseFloat($("tz-end").value) || 0; if (b < a) { const t = a; a = b; b = t; } return [a, b]; }
      function drawWave() {
        const w = canvas.width = canvas.clientWidth || 600, h = canvas.height = 110, ch = buf.getChannelData(0), step = Math.max(1, Math.floor(ch.length / w));
        const [a, b] = range(), x1 = a / buf.duration * w, x2 = b / buf.duration * w;
        const g = canvas.getContext("2d");
        g.clearRect(0, 0, w, h);
        g.fillStyle = "rgba(14,165,236,.14)"; g.fillRect(x1, 0, Math.max(1, x2 - x1), h);
        g.fillStyle = "#0EA5EC";
        for (let x = 0; x < w; x++) {
          let min = 1, max = -1;
          for (let i = 0; i < step; i += Math.max(1, Math.floor(step / 8))) { const v = ch[x * step + i] || 0; if (v < min) min = v; if (v > max) max = v; }
          const y1 = (1 + min) * 0.5 * h, y2 = (1 + max) * 0.5 * h;
          g.globalAlpha = x >= x1 && x <= x2 ? 1 : 0.35;
          g.fillRect(x, y1, 1, Math.max(1, y2 - y1));
        }
        g.globalAlpha = 1;
      }
      function sync() { const [a, b] = range(); $("tz-info").textContent = "Selection: " + a.toFixed(2) + " s \u2192 " + b.toFixed(2) + " s (" + (b - a).toFixed(2) + " s)"; drawWave(); }
      function stopPlay() { if (src) { try { src.stop(); } catch (e) {} src = null; } if (ctx) { try { ctx.close(); } catch (e) {} ctx = null; } clearTimeout(playTimer); }
      ["tz-start", "tz-end"].forEach(function (id) { on($(id), "input", function () { if (buf) sync(); }); });
      on($("tz-preview"), "click", function () {
        if (!buf) return;
        stopPlay();
        const [a, b] = range();
        const Ctx = window.AudioContext || window.webkitAudioContext;
        ctx = new Ctx();
        src = ctx.createBufferSource(); src.buffer = buf; src.connect(ctx.destination);
        src.start(0, a, Math.max(0.05, b - a));
      });
      on($("tz-stop"), "click", stopPlay);
      on($("tz-run"), "click", async function () {
        if (!buf) { TZ.showToast("Upload an audio file first"); return; }
        const [a, b] = range();
        if (b - a < 0.05) { TZ.showToast("Select a longer part"); return; }
        const btn = $("tz-run");
        setBtnLoading(btn, true, "Working\u2026");
        try {
          const s0 = Math.floor(a * buf.sampleRate), s1 = Math.min(buf.length, Math.floor(b * buf.sampleRate));
          const fade = $("tz-fade").checked ? Math.min(Math.floor(0.05 * buf.sampleRate), Math.floor((s1 - s0) / 2)) : 0;
          const chs = [];
          for (let c = 0; c < Math.min(2, buf.numberOfChannels); c++) {
            const part = buf.getChannelData(c).slice(s0, s1);
            for (let i = 0; i < fade; i++) { part[i] *= i / fade; part[part.length - 1 - i] *= i / fade; }
            chs.push(part);
          }
          const fmt = $("tz-format").value;
          const blob = fmt === "wav" ? wavFromChannels(chs, buf.sampleRate) : await encodeMp3(chs, buf.sampleRate, 192, function (p) { setProgress(p * 100); });
          TZ.downloadBlob(blob, baseName(file.name) + "-trimmed." + (fmt === "wav" ? "wav" : "mp3"));
          showResult(resultEl, "Done \u2014 your trimmed audio was downloaded.", "success");
        } catch (e) { showResult(resultEl, "Couldn\u2019t save the audio. " + libMissingMessage("the MP3 encoder"), "error"); }
        setProgress(null);
        setBtnLoading(btn, false);
      });
      on($("tz-reset"), "click", function () { stopPlay(); upload.clear(); file = null; buf = null; $("tz-stage").style.display = "none"; resultEl.style.display = "none"; });
      $("tz-stage").style.display = "none";
    },
  };

  /* =====================================================================
     v13 — IMAGE, CALCULATOR AND GENERATOR TOOLS
     ===================================================================== */

  /* ============================================================= COMPRESS IMAGE TO TARGET SIZE */

  window.TZTools.compressToKb = {
    init: function () {
      const resultEl = $("tz-result");
      let file = null, blobOut = null;
      const upload = setupSingleUpload({ iconKey: "image", onFile: function (f) { file = f; blobOut = null; $("tz-download").style.display = "none"; if (f) $("tz-orig").textContent = TZ.formatBytes(f.size); } });
      on($("tz-run"), "click", async function () {
        if (!file) { TZ.showToast("Upload an image first"); return; }
        const target = Math.max(5, numVal("tz-target", 100)) * 1024;
        const type = $("tz-format").value;
        const btn = $("tz-run");
        setBtnLoading(btn, true, "Compressing\u2026");
        setProgress(5);
        try {
          const img = await loadImage(await fileToDataUrl(file));
          let w = img.naturalWidth, h = img.naturalHeight, best = null, bestQ = 0;
          const c = document.createElement("canvas");
          for (let round = 0; round < 12 && !best; round++) {
            c.width = Math.max(1, Math.round(w)); c.height = Math.max(1, Math.round(h));
            const ctx = c.getContext("2d");
            ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, c.width, c.height);
            ctx.drawImage(img, 0, 0, c.width, c.height);
            let lo = 0.05, hi = 0.95, found = null;
            for (let i = 0; i < 8; i++) {
              const q = (lo + hi) / 2;
              const b = await canvasToBlob(c, type, q);
              if (b.size <= target) { found = b; bestQ = q; lo = q; } else hi = q;
            }
            if (found) best = found; else { w *= 0.85; h *= 0.85; if (w < 60 || h < 60) break; }
            setProgress(5 + round * 7);
          }
          if (!best) throw new Error("too small");
          blobOut = best;
          $("tz-new").textContent = TZ.formatBytes(best.size);
          $("tz-dim").textContent = c.width + " \u00d7 " + c.height + " px";
          $("tz-download").style.display = "";
          showResult(resultEl, "Done \u2014 reduced from " + TZ.formatBytes(file.size) + " to " + TZ.formatBytes(best.size) + " (target " + TZ.formatBytes(target) + ").", "success");
        } catch (e) { showResult(resultEl, "Couldn\u2019t reach that size without making the picture too small. Try a larger target.", "error"); }
        setProgress(null);
        setBtnLoading(btn, false);
      });
      on($("tz-download"), "click", function () { if (blobOut) TZ.downloadBlob(blobOut, baseName(file.name) + "-compressed." + ($("tz-format").value === "image/webp" ? "webp" : "jpg")); });
      on($("tz-reset"), "click", function () { upload.clear(); file = null; blobOut = null; $("tz-download").style.display = "none"; resultEl.style.display = "none"; $("tz-orig").textContent = $("tz-new").textContent = $("tz-dim").textContent = "\u2014"; });
      $("tz-download").style.display = "none";
    },
  };

  /* ============================================================= FAVICON GENERATOR */

  window.TZTools.faviconGenerator = {
    init: function () {
      const resultEl = $("tz-result");
      let file = null, img = null, made = [];
      const SIZES = [16, 32, 48, 64, 180, 192, 512];
      const upload = setupSingleUpload({
        iconKey: "image",
        onFile: async function (f) { file = f; img = null; if (f) { try { img = await loadImage(await fileToDataUrl(f)); } catch (e) { showResult(resultEl, "Couldn\u2019t open that image.", "error"); } } },
      });
      function square(size) {
        const c = document.createElement("canvas"); c.width = c.height = size;
        const g = c.getContext("2d"), s = Math.min(img.naturalWidth, img.naturalHeight);
        const bg = $("tz-bg").value;
        if (bg !== "transparent") { g.fillStyle = bg; g.fillRect(0, 0, size, size); }
        g.imageSmoothingQuality = "high";
        g.drawImage(img, (img.naturalWidth - s) / 2, (img.naturalHeight - s) / 2, s, s, 0, 0, size, size);
        return c;
      }
      function buildIco(pngs) {
        const head = 6 + pngs.length * 16; let offset = head;
        const buf = new ArrayBuffer(head), v = new DataView(buf);
        v.setUint16(0, 0, true); v.setUint16(2, 1, true); v.setUint16(4, pngs.length, true);
        pngs.forEach(function (p, i) {
          const o = 6 + i * 16;
          v.setUint8(o, p.size >= 256 ? 0 : p.size); v.setUint8(o + 1, p.size >= 256 ? 0 : p.size); v.setUint8(o + 2, 0); v.setUint8(o + 3, 0);
          v.setUint16(o + 4, 1, true); v.setUint16(o + 6, 32, true); v.setUint32(o + 8, p.bytes.length, true); v.setUint32(o + 12, offset, true);
          offset += p.bytes.length;
        });
        return new Blob([buf].concat(pngs.map(function (p) { return p.bytes; })), { type: "image/x-icon" });
      }
      on($("tz-run"), "click", async function () {
        if (!img) { TZ.showToast("Upload an image first"); return; }
        if (typeof JSZip === "undefined") { TZ.showToast(libMissingMessage("the ZIP tool")); return; }
        const btn = $("tz-run");
        setBtnLoading(btn, true, "Creating\u2026");
        made = [];
        const grid = $("tz-grid"); grid.innerHTML = "";
        for (let i = 0; i < SIZES.length; i++) {
          const s = SIZES[i], c = square(s), blob = await canvasToBlob(c, "image/png");
          made.push({ size: s, blob: blob, bytes: new Uint8Array(await blob.arrayBuffer()) });
          const cell = document.createElement("div");
          cell.style.cssText = "text-align:center;font-size:.75rem;color:var(--muted);";
          cell.innerHTML = '<img src="' + c.toDataURL() + '" width="' + Math.min(s, 96) + '" height="' + Math.min(s, 96) + '" alt="' + s + ' px icon" style="border:1px solid var(--border-soft);border-radius:8px;background:repeating-conic-gradient(#e5e7eb 0% 25%,#fff 0% 50%) 50%/12px 12px;"><div>' + s + " \u00d7 " + s + "</div>";
          grid.appendChild(cell);
        }
        $("tz-code").value = '<link rel="icon" href="/favicon.ico" sizes="any">\n<link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">\n<link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">\n<link rel="apple-touch-icon" href="/apple-touch-icon.png">\n<link rel="manifest" href="/site.webmanifest">';
        $("tz-out").style.display = "";
        showResult(resultEl, "Done \u2014 your favicon files are ready to download.", "success");
        setBtnLoading(btn, false);
      });
      on($("tz-zip"), "click", async function () {
        if (!made.length) return;
        const zip = new JSZip();
        const names = { 16: "favicon-16x16.png", 32: "favicon-32x32.png", 48: "favicon-48x48.png", 64: "favicon-64x64.png", 180: "apple-touch-icon.png", 192: "android-chrome-192x192.png", 512: "android-chrome-512x512.png" };
        made.forEach(function (m) { zip.file(names[m.size], m.bytes); });
        zip.file("favicon.ico", buildIco(made.filter(function (m) { return m.size <= 48; })));
        zip.file("site.webmanifest", JSON.stringify({ name: "", short_name: "", icons: [{ src: "/android-chrome-192x192.png", sizes: "192x192", type: "image/png" }, { src: "/android-chrome-512x512.png", sizes: "512x512", type: "image/png" }], theme_color: "#ffffff", background_color: "#ffffff", display: "standalone" }, null, 2));
        TZ.downloadBlob(await zip.generateAsync({ type: "blob" }), "favicons.zip");
      });
      on($("tz-copy"), "click", function () { TZ.copyToClipboard($("tz-code").value, "HTML copied"); });
      on($("tz-reset"), "click", function () { upload.clear(); file = null; img = null; made = []; $("tz-grid").innerHTML = ""; $("tz-out").style.display = "none"; resultEl.style.display = "none"; });
      $("tz-out").style.display = "none";
    },
  };

  /* ============================================================= IMAGE COLOR PICKER */

  window.TZTools.imageColorPicker = {
    init: function () {
      const canvas = $("tz-view"), ctx = canvas.getContext("2d", { willReadFrequently: true });
      let loaded = false, history = [];
      const upload = setupSingleUpload({
        iconKey: "image",
        onFile: async function (f) {
          loaded = false; $("tz-stage").style.display = "none";
          if (!f) return;
          try {
            const img = await loadImage(await fileToDataUrl(f));
            const k = Math.min(1, 720 / img.naturalWidth);
            canvas.width = Math.round(img.naturalWidth * k); canvas.height = Math.round(img.naturalHeight * k);
            ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
            loaded = true; $("tz-stage").style.display = "block";
            palette();
          } catch (e) { showResult($("tz-result"), "Couldn\u2019t open that image.", "error"); }
        },
      });
      const hex = function (r, g, b) { return "#" + [r, g, b].map(function (v) { return v.toString(16).padStart(2, "0"); }).join("").toUpperCase(); };
      function hsl(r, g, b) {
        r /= 255; g /= 255; b /= 255;
        const mx = Math.max(r, g, b), mn = Math.min(r, g, b); let h = 0, s = 0; const l = (mx + mn) / 2;
        if (mx !== mn) { const d = mx - mn; s = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn); h = mx === r ? (g - b) / d + (g < b ? 6 : 0) : mx === g ? (b - r) / d + 2 : (r - g) / d + 4; h *= 60; }
        return "hsl(" + Math.round(h) + ", " + Math.round(s * 100) + "%, " + Math.round(l * 100) + "%)";
      }
      function show(r, g, b, keep) {
        const hx = hex(r, g, b);
        $("tz-swatch").style.background = hx;
        $("tz-hex").value = hx; $("tz-rgb").value = "rgb(" + r + ", " + g + ", " + b + ")"; $("tz-hsl").value = hsl(r, g, b);
        if (keep) { history = [hx].concat(history.filter(function (x) { return x !== hx; })).slice(0, 12); renderHistory(); }
      }
      function renderHistory() { $("tz-history").innerHTML = history.map(function (h) { return '<button type="button" class="tz-chip-color" data-c="' + h + '" style="background:' + h + ';" aria-label="' + h + '" title="' + h + '"></button>'; }).join(""); }
      function pixel(e) {
        const r = canvas.getBoundingClientRect();
        const x = Math.max(0, Math.min(canvas.width - 1, Math.floor((e.clientX - r.left) * canvas.width / r.width)));
        const y = Math.max(0, Math.min(canvas.height - 1, Math.floor((e.clientY - r.top) * canvas.height / r.height)));
        return ctx.getImageData(x, y, 1, 1).data;
      }
      on(canvas, "pointermove", function (e) { if (loaded) { const d = pixel(e); show(d[0], d[1], d[2], false); } });
      on(canvas, "click", function (e) { if (loaded) { const d = pixel(e); show(d[0], d[1], d[2], true); } });
      on($("tz-history"), "click", function (e) { const b = e.target.closest("[data-c]"); if (b) TZ.copyToClipboard(b.getAttribute("data-c"), b.getAttribute("data-c") + " copied"); });
      function palette() {
        const d = ctx.getImageData(0, 0, canvas.width, canvas.height).data, buckets = {};
        for (let i = 0; i < d.length; i += 4 * 7) {
          if (d[i + 3] < 128) continue;
          const key = (d[i] >> 4) + "," + (d[i + 1] >> 4) + "," + (d[i + 2] >> 4);
          const b = buckets[key] || (buckets[key] = { n: 0, r: 0, g: 0, b: 0 });
          b.n++; b.r += d[i]; b.g += d[i + 1]; b.b += d[i + 2];
        }
        const top = Object.keys(buckets).map(function (k) { return buckets[k]; }).sort(function (a, b) { return b.n - a.n; });
        const picked = [];
        top.forEach(function (b) {
          const c = [Math.round(b.r / b.n), Math.round(b.g / b.n), Math.round(b.b / b.n)];
          if (picked.length < 6 && picked.every(function (p) { return Math.abs(p[0] - c[0]) + Math.abs(p[1] - c[1]) + Math.abs(p[2] - c[2]) > 90; })) picked.push(c);
        });
        $("tz-palette").innerHTML = picked.map(function (c) { const h = hex(c[0], c[1], c[2]); return '<button type="button" class="tz-chip-color big" data-c="' + h + '" style="background:' + h + ';" aria-label="' + h + '" title="' + h + '"><span>' + h + "</span></button>"; }).join("");
      }
      on($("tz-palette"), "click", function (e) { const b = e.target.closest("[data-c]"); if (b) TZ.copyToClipboard(b.getAttribute("data-c"), b.getAttribute("data-c") + " copied"); });
      ["tz-hex", "tz-rgb", "tz-hsl"].forEach(function (id) { on($(id), "click", function () { if ($(id).value) TZ.copyToClipboard($(id).value, "Copied"); }); });
      on($("tz-reset"), "click", function () { upload.clear(); loaded = false; history = []; renderHistory(); $("tz-stage").style.display = "none"; });
      $("tz-stage").style.display = "none";
    },
  };

  /* ============================================================= CURRENCY CONVERTER */

  window.TZTools.currencyConverter = {
    init: function () {
      const from = $("tz-from"), to = $("tz-to");
      const cache = {};
      [from, to].forEach(function (s) { fillCurrencySelect(s, s === from ? "USD" : "EUR"); });
      async function rates(base) {
        if (cache[base]) return cache[base];
        const r = await fetch("https://open.er-api.com/v6/latest/" + encodeURIComponent(base));
        const j = await r.json();
        if (j.result !== "success") throw new Error("rates");
        cache[base] = j;
        return j;
      }
      async function run() {
        const amt = numVal("tz-amount", 1), a = from.value, b = to.value;
        try {
          const j = await rates(a);
          const rate = j.rates[b];
          if (!rate) { $("tz-stat-result").textContent = "Rate not available"; return; }
          $("tz-stat-result").textContent = formatMoney(amt * rate, b);
          $("tz-stat-rate").textContent = "1 " + a + " = " + rate.toLocaleString(undefined, { maximumFractionDigits: 6 }) + " " + b;
          $("tz-stat-inv").textContent = "1 " + b + " = " + (1 / rate).toLocaleString(undefined, { maximumFractionDigits: 6 }) + " " + a;
          $("tz-updated").textContent = "Rates updated " + (j.time_last_update_utc || "").replace(/ \+0000$/, " UTC") + ". Exchange rates are indicative and may differ from what your bank charges.";
        } catch (e) {
          $("tz-stat-result").textContent = "\u2014";
          $("tz-updated").textContent = "Couldn\u2019t load live exchange rates. Check your internet connection and try again.";
        }
      }
      ["tz-amount", "tz-from", "tz-to"].forEach(function (id) { on($(id), "input", run); on($(id), "change", run); });
      on($("tz-swap"), "click", function () { const t = from.value; from.value = to.value; to.value = t; run(); });
      on($("tz-reset"), "click", function () { $("tz-amount").value = 1; from.value = "USD"; to.value = "EUR"; run(); });
      run();
    },
  };

  /* ============================================================= DISCOUNT CALCULATOR */

  window.TZTools.discountCalculator = {
    init: function () {
      const cur = $("tz-currency");
      fillCurrencySelect(cur, "USD");
      function run() {
        const f = function (n) { return isFinite(n) ? formatMoney(n, cur.value) : "\u2014"; };
        const mode = $("tz-mode").value;
        $("tz-w-price").style.display = mode === "sale" || mode === "percent" ? "" : "none";
        $("tz-w-disc").style.display = mode === "sale" || mode === "original" ? "" : "none";
        $("tz-w-extra").style.display = mode === "sale" ? "" : "none";
        $("tz-w-final").style.display = mode === "original" || mode === "percent" ? "" : "none";
        const price = numVal("tz-price"), d1 = numVal("tz-disc"), d2 = numVal("tz-extra"), fin = numVal("tz-final"), tax = numVal("tz-tax");
        let orig, paid, pct;
        if (mode === "sale") { orig = price; paid = price * (1 - d1 / 100) * (1 - d2 / 100); pct = orig ? (1 - paid / orig) * 100 : 0; }
        else if (mode === "original") { paid = fin; orig = d1 >= 100 ? NaN : fin / (1 - d1 / 100); pct = d1; }
        else { orig = price; paid = fin; pct = orig ? (1 - paid / orig) * 100 : 0; }
        const withTax = paid * (1 + tax / 100);
        $("tz-stat-paid").textContent = f(withTax);
        $("tz-stat-save").textContent = f(orig - paid);
        $("tz-stat-orig").textContent = f(orig);
        $("tz-stat-pct").textContent = isFinite(pct) ? pct.toFixed(2).replace(/\.?0+$/, "") + "%" : "\u2014";
      }
      ["tz-currency", "tz-mode", "tz-price", "tz-disc", "tz-extra", "tz-final", "tz-tax"].forEach(function (id) { on($(id), "input", run); on($(id), "change", run); });
      on($("tz-reset"), "click", function () { ["tz-price", "tz-disc", "tz-extra", "tz-final", "tz-tax"].forEach(function (id) { $(id).value = ""; }); run(); });
      run();
    },
  };

  /* ============================================================= TIMER, STOPWATCH & POMODORO */

  window.TZTools.timerStopwatch = {
    init: function () {
      let mode = "timer", running = false, endAt = 0, remaining = 0, startAt = 0, elapsedBase = 0, laps = [], tick = null, pomo = { phase: "focus", round: 1 };
      const display = $("tz-display"), baseTitle = document.title;
      function fmt(ms, hund) {
        const t = Math.max(0, ms), h = Math.floor(t / 3600000), m = Math.floor(t / 60000) % 60, s = Math.floor(t / 1000) % 60, c = Math.floor(t / 10) % 100;
        return (h ? h + ":" : "") + String(m).padStart(2, "0") + ":" + String(s).padStart(2, "0") + (hund ? "." + String(c).padStart(2, "0") : "");
      }
      function beep() {
        try {
          const Ctx = window.AudioContext || window.webkitAudioContext, c = new Ctx();
          [0, 0.35, 0.7].forEach(function (t) { const o = c.createOscillator(), g = c.createGain(); o.frequency.value = 880; o.connect(g); g.connect(c.destination); g.gain.setValueAtTime(0.0001, c.currentTime + t); g.gain.exponentialRampToValueAtTime(0.4, c.currentTime + t + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, c.currentTime + t + 0.28); o.start(c.currentTime + t); o.stop(c.currentTime + t + 0.3); });
          setTimeout(function () { try { c.close(); } catch (e) {} }, 1500);
        } catch (e) {}
      }
      function phaseMs() { const p = pomo.phase; return (p === "focus" ? numVal("tz-focus", 25) : p === "short" ? numVal("tz-short", 5) : numVal("tz-long", 15)) * 60000; }
      function paint() {
        if (mode === "stopwatch") { const e = elapsedBase + (running ? Date.now() - startAt : 0); display.textContent = fmt(e, true); document.title = running ? fmt(e) + " \u00b7 " + baseTitle : baseTitle; }
        else { const left = running ? endAt - Date.now() : remaining; display.textContent = fmt(left); document.title = running ? fmt(left) + " \u00b7 " + baseTitle : baseTitle; if (running && left <= 0) done(); }
      }
      function done() {
        running = false; clearInterval(tick); beep();
        if (mode === "pomodoro") {
          const next = pomo.phase === "focus" ? (pomo.round % 4 === 0 ? "long" : "short") : "focus";
          if (pomo.phase === "focus") $("tz-pomo-count").textContent = "Focus sessions completed: " + pomo.round;
          if (pomo.phase !== "focus") pomo.round++;
          pomo.phase = next; remaining = phaseMs(); $("tz-phase").textContent = next === "focus" ? "Focus time" : next === "short" ? "Short break" : "Long break";
          display.textContent = fmt(remaining);
        } else { remaining = 0; display.textContent = "00:00"; TZ.showToast("Time\u2019s up!"); }
        document.title = baseTitle; $("tz-start").querySelector("span").textContent = "Start";
      }
      function setRemainingFromInputs() { remaining = (numVal("tz-h") * 3600 + numVal("tz-m") * 60 + numVal("tz-s")) * 1000; }
      function switchMode() {
        mode = $("tz-mode").value; running = false; clearInterval(tick); document.title = baseTitle;
        $("tz-p-timer").style.display = mode === "timer" ? "" : "none";
        $("tz-p-pomo").style.display = mode === "pomodoro" ? "" : "none";
        $("tz-p-laps").style.display = mode === "stopwatch" ? "" : "none";
        $("tz-lap").style.display = mode === "stopwatch" ? "" : "none";
        $("tz-start").querySelector("span").textContent = "Start";
        $("tz-phase").textContent = mode === "pomodoro" ? "Focus time" : "";
        pomo = { phase: "focus", round: 1 }; elapsedBase = 0; laps = []; $("tz-laps").innerHTML = "";
        if (mode === "timer") setRemainingFromInputs(); else if (mode === "pomodoro") remaining = phaseMs();
        paint();
      }
      on($("tz-start"), "click", function () {
        if (!running) {
          if (mode === "timer" && !remaining) setRemainingFromInputs();
          if (mode !== "stopwatch" && remaining <= 0) { TZ.showToast("Set a time first"); return; }
          running = true; if (mode === "stopwatch") startAt = Date.now(); else endAt = Date.now() + remaining;
          tick = setInterval(paint, mode === "stopwatch" ? 31 : 200);
          $("tz-start").querySelector("span").textContent = "Pause";
        } else {
          if (mode === "stopwatch") elapsedBase += Date.now() - startAt; else remaining = Math.max(0, endAt - Date.now());
          running = false; clearInterval(tick); $("tz-start").querySelector("span").textContent = "Resume"; paint();
        }
      });
      on($("tz-lap"), "click", function () {
        if (mode !== "stopwatch") return;
        const e = elapsedBase + (running ? Date.now() - startAt : 0); if (!e) return;
        laps.unshift(e); $("tz-laps").innerHTML = laps.map(function (l, i) { return "<li><span>Lap " + (laps.length - i) + "</span><strong>" + fmt(l, true) + "</strong></li>"; }).join("");
      });
      on($("tz-reset"), "click", switchMode);
      on($("tz-mode"), "change", switchMode);
      ["tz-h", "tz-m", "tz-s"].forEach(function (id) { on($(id), "input", function () { if (!running && mode === "timer") { setRemainingFromInputs(); paint(); } }); });
      ["tz-focus", "tz-short", "tz-long"].forEach(function (id) { on($(id), "input", function () { if (!running && mode === "pomodoro") { remaining = phaseMs(); paint(); } }); });
      document.querySelectorAll("[data-preset]").forEach(function (b) { on(b, "click", function () { const m = parseInt(b.getAttribute("data-preset"), 10); $("tz-h").value = Math.floor(m / 60); $("tz-m").value = m % 60; $("tz-s").value = 0; if (!running) { setRemainingFromInputs(); paint(); } }); });
      switchMode();
    },
  };

  /* ============================================================= RANDOM PICKER (numbers, dice, coin, names) */

  window.TZTools.randomPicker = {
    init: function () {
      const out = $("tz-out");
      function rnd(min, max) { const range = max - min + 1, lim = Math.floor(4294967296 / range) * range; let x; const buf = new Uint32Array(1); do { crypto.getRandomValues(buf); x = buf[0]; } while (x >= lim); return min + (x % range); }
      function panels() { const m = $("tz-mode").value; ["number", "dice", "coin", "list"].forEach(function (k) { $("tz-p-" + k).style.display = m === k ? "" : "none"; }); }
      function compute() {
        const m = $("tz-mode").value;
        if (m === "number") {
          let a = Math.floor(numVal("tz-min", 1)), b = Math.floor(numVal("tz-max", 100)); if (a > b) { const t = a; a = b; b = t; }
          const n = Math.max(1, Math.min(1000, Math.floor(numVal("tz-count", 1)))), uniq = $("tz-unique").checked;
          if (uniq && n > b - a + 1) return { text: "Can\u2019t pick " + n + " different numbers from only " + (b - a + 1) + ".", big: false };
          const res = [];
          while (res.length < n) { const v = rnd(a, b); if (!uniq || res.indexOf(v) === -1) res.push(v); }
          return { text: res.join(", "), big: n === 1 };
        }
        if (m === "dice") {
          const n = Math.max(1, Math.min(30, Math.floor(numVal("tz-dice", 2)))), sides = parseInt($("tz-sides").value, 10), res = [];
          for (let i = 0; i < n; i++) res.push(rnd(1, sides));
          return { text: res.join(" + ") + (n > 1 ? "  =  " + res.reduce(function (a, b) { return a + b; }, 0) : ""), big: n === 1 };
        }
        if (m === "coin") return { text: rnd(0, 1) ? "Heads" : "Tails", big: true };
        const items = $("tz-list").value.split("\n").map(function (x) { return x.trim(); }).filter(Boolean);
        if (!items.length) return { text: "Add some names or items first.", big: false };
        const k = Math.min(items.length, Math.max(1, Math.floor(numVal("tz-pick", 1)))), pool = items.slice(), picked = [];
        for (let i = 0; i < k; i++) picked.push(pool.splice(rnd(0, pool.length - 1), 1)[0]);
        return { text: picked.join(", "), big: k === 1 };
      }
      on($("tz-run"), "click", function () {
        const m = $("tz-mode").value; let frames = 0;
        const btn = $("tz-run"); btn.disabled = true;
        const t = setInterval(function () {
          const r = compute(); out.textContent = r.text; out.classList.toggle("big", r.big); out.classList.add("rolling");
          if (++frames >= (m === "coin" || m === "dice" ? 9 : 6)) { clearInterval(t); out.classList.remove("rolling"); btn.disabled = false; }
        }, 70);
      });
      on($("tz-copy"), "click", function () { if (out.textContent) TZ.copyToClipboard(out.textContent, "Copied"); });
      on($("tz-mode"), "change", function () { panels(); out.textContent = "Press the button"; out.classList.add("big"); });
      on($("tz-reset"), "click", function () { $("tz-list").value = ""; out.textContent = "Press the button"; out.classList.add("big"); });
      panels();
    },
  };

})();
