package com.toolzihub.app;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.webkit.WebViewAssetLoader;

public class MainActivity extends Activity {
    private WebView webView;
    private FrameLayout root;
    private View splash;
    private boolean pageReady = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(4, 27, 69));
        getWindow().setNavigationBarColor(Color.rgb(4, 27, 69));

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.WHITE);
        setContentView(root);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(false);
        webView.getSettings().setAllowContentAccess(false);
        webView.setWebChromeClient(new WebChromeClient());

        WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
            .addPathHandler("/", new WebViewAssetLoader.AssetsPathHandler(this))
            .build();

        webView.setWebViewClient(new WebViewClient() {
            @Override public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }
            @Override public void onPageFinished(WebView view, String url) {
                pageReady = true;
                if (splash != null) hideSplash();
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String host = request.getUrl().getHost();
                if ("appassets.androidplatform.net".equals(host)) return false;
                return true;
            }
        });

        root.addView(webView, new FrameLayout.LayoutParams(-1, -1));
        showSplash();
        webView.loadUrl("https://appassets.androidplatform.net/index.html");
    }

    private void showSplash() {
        FrameLayout overlay = new FrameLayout(this);
        overlay.setBackgroundColor(Color.rgb(4, 27, 69));

        LinearLayout stack = new LinearLayout(this);
        stack.setOrientation(LinearLayout.VERTICAL);
        stack.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams stackParams = new FrameLayout.LayoutParams(-1, -1);
        overlay.addView(stack, stackParams);

        TextView mark = new TextView(this);
        mark.setText("T");
        mark.setTextColor(Color.WHITE);
        mark.setTextSize(42);
        mark.setTypeface(Typeface.create("sans-serif-black", Typeface.BOLD));
        mark.setGravity(Gravity.CENTER);
        GradientDrawable badge = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
            new int[]{Color.rgb(59,130,246), Color.rgb(14,165,233)});
        badge.setCornerRadius(dp(24));
        mark.setBackground(badge);
        mark.setElevation(dp(10));
        LinearLayout.LayoutParams markParams = new LinearLayout.LayoutParams(dp(86), dp(86));
        markParams.bottomMargin = dp(20);
        stack.addView(mark, markParams);

        TextView title = new TextView(this);
        title.setText("ToolziHub");
        title.setTextColor(Color.WHITE);
        title.setTextSize(29);
        title.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        stack.addView(title);

        TextView tagline = new TextView(this);
        tagline.setText("Many useful tools. One smart hub.");
        tagline.setTextColor(Color.rgb(190, 211, 242));
        tagline.setTextSize(14);
        LinearLayout.LayoutParams tagParams = new LinearLayout.LayoutParams(-2, -2);
        tagParams.topMargin = dp(7);
        stack.addView(tagline, tagParams);

        ProgressBar progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setIndeterminate(true);
        progress.setProgressTintList(android.content.res.ColorStateList.valueOf(Color.rgb(56,189,248)));
        progress.setIndeterminateTintList(android.content.res.ColorStateList.valueOf(Color.rgb(56,189,248)));
        LinearLayout.LayoutParams progressParams = new LinearLayout.LayoutParams(dp(132), dp(4));
        progressParams.topMargin = dp(38);
        stack.addView(progress, progressParams);

        TextView loading = new TextView(this);
        loading.setText("Preparing your tools…");
        loading.setTextColor(Color.rgb(190, 211, 242));
        loading.setTextSize(12);
        LinearLayout.LayoutParams loadParams = new LinearLayout.LayoutParams(-2, -2);
        loadParams.topMargin = dp(12);
        stack.addView(loading, loadParams);

        mark.setScaleX(0.75f); mark.setScaleY(0.75f); mark.setAlpha(0f);
        mark.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(550).setInterpolator(new DecelerateInterpolator()).start();
        title.setAlpha(0f); title.animate().alpha(1f).setStartDelay(180).setDuration(500).start();
        splash = overlay;
        root.addView(splash, new FrameLayout.LayoutParams(-1, -1));
    }

    private void hideSplash() {
        if (splash == null) return;
        final View old = splash;
        splash = null;
        old.animate().alpha(0f).setDuration(350).setListener(new AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(Animator animation) {
                if (old.getParent() != null) ((ViewGroup)old.getParent()).removeView(old);
            }
        }).start();
    }

    private int dp(int value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (webView != null) { webView.stopLoading(); webView.destroy(); }
        super.onDestroy();
    }
}
