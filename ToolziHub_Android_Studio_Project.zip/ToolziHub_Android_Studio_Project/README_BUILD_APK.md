# ToolziHub Android app project

This is an Android Studio project wrapper for the supplied ToolziHub static website. It includes the site's local HTML/CSS/JS assets and a native animated splash screen.

## Build the APK
1. Install Android Studio (current stable) and its Android SDK Platform 35.
2. Open this folder (`ToolziHub_Android_Studio_Project`) in Android Studio.
3. Allow Gradle sync to finish.
4. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the generated APK location (usually `app/build/outputs/apk/debug/app-debug.apk`).

## Notes
- The wrapper loads website files from app assets, so the basic site shell can open without hosting.
- Some website tools may depend on browser APIs or third-party network services; test each tool on a physical Android device before publishing.
- The app currently uses a simple native “T” splash mark. Replace it with your approved logo if desired.
- The project source is provided; this environment does not include Android SDK/Gradle tooling, so a compiled APK is not included.
