import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:print_bluetooth_thermal/print_bluetooth_thermal.dart';
import 'package:esc_pos_utils_plus/esc_pos_utils_plus.dart';
import 'package:permission_handler/permission_handler.dart';

late SharedPreferences sp;
Map<String, dynamic> db = {};

void save() => sp.setString('db', jsonEncode(db));

void loadDb() {
  final s = sp.getString('db');
  if (s != null) db = jsonDecode(s);
  db.putIfAbsent('tokens', () => []);
  db.putIfAbsent('nextToken', () => 1);
  db.putIfAbsent('settings', () => {'grace': 15, 'lostFee': 100, 'payNo': '', 'printerMac': null});
  db.putIfAbsent('vehicles', () => [
        {'name': 'Motorcycle', 'mode': 'fixed', 'fixed': 20, 'h1': 0, 'h2': 0, 'h3': 0, 'extra': 0},
        {'name': 'Rickshaw', 'mode': 'fixed', 'fixed': 30, 'h1': 0, 'h2': 0, 'h3': 0, 'extra': 0},
        {'name': 'Car', 'mode': 'hourly', 'fixed': 0, 'h1': 50, 'h2': 80, 'h3': 100, 'extra': 30},
        {'name': 'Jeep / Van', 'mode': 'hourly', 'fixed': 0, 'h1': 80, 'h2': 120, 'h3': 150, 'extra': 40},
        {'name': 'Pickup / Loader', 'mode': 'hourly', 'fixed': 0, 'h1': 100, 'h2': 150, 'h3': 200, 'extra': 50},
        {'name': 'Truck / Bus', 'mode': 'hourly', 'fixed': 0, 'h1': 150, 'h2': 250, 'h3': 350, 'extra': 100},
      ]);
}

Map? vehicleOf(String name) {
  for (final v in db['vehicles']) {
    if (v['name'] == name) return v;
  }
  return null;
}

int calcFee(Map v, Map t) {
  if (v['mode'] == 'fixed') return v['fixed'] as int;
  final mins = DateTime.now().difference(DateTime.parse(t['in'])).inMinutes;
  final grace = db['settings']['grace'] as int;
  int h = ((mins - grace) / 60).ceil();
  if (h < 1) h = 1;
  final exp = (t['expH'] ?? 0) as int;
  if (exp > h) h = exp;
  if (h <= 3) return v['h$h'] as int;
  return (v['h3'] as int) + (h - 3) * (v['extra'] as int);
}

String dur(String iso) {
  final m = DateTime.now().difference(DateTime.parse(iso)).inMinutes;
  return m >= 60 ? '${m ~/ 60}h ${m % 60}m' : '${m}m';
}

bool today(String iso) {
  final d = DateTime.parse(iso), n = DateTime.now();
  return d.year == n.year && d.month == n.month && d.day == n.day;
}

void msg(BuildContext c, String s) =>
    ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(s)));

Widget tf(TextEditingController c, String l, {bool pw = false, bool num = false}) => Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: c,
        obscureText: pw,
        keyboardType: num ? TextInputType.number : TextInputType.text,
        decoration: InputDecoration(labelText: l, border: const OutlineInputBorder()),
      ),
    );

// ---------- Printing ----------
Future<String> printSlip(Map t) async {
  final mac = db['settings']['printerMac'];
  if (mac == null) return 'Printer connect nahi hai (Settings > Connect to Printer)';
  try {
    if (!await PrintBluetoothThermal.connectionStatus) {
      final ok = await PrintBluetoothThermal.connect(macPrinterAddress: mac);
      if (!ok) return 'Printer se connect nahi ho saka';
    }
    final v = vehicleOf(t['vehicle']);
    final shop = db['shop'] ?? {};
    final g = Generator(PaperSize.mm58, await CapabilityProfile.load());
    List<int> b = [];
    const c = PosStyles(align: PosAlign.center);
    b += g.text('${shop['name'] ?? ''}', styles: const PosStyles(align: PosAlign.center, bold: true, height: PosTextSize.size2));
    b += g.text('${shop['place'] ?? ''}', styles: c);
    b += g.text('${shop['phone'] ?? ''}', styles: c);
    b += g.hr();
    b += g.text('PARKING TOKEN', styles: c);
    b += g.text('#${t['id']}', styles: const PosStyles(align: PosAlign.center, bold: true, height: PosTextSize.size3, width: PosTextSize.size3));
    b += g.text('${t['plate']}', styles: const PosStyles(align: PosAlign.center, bold: true, height: PosTextSize.size2));
    b += g.text('${t['vehicle']}', styles: c);
    final d = DateTime.parse(t['in']);
    b += g.text('In: ${d.day}-${d.month}-${d.year} ${d.hour}:${d.minute.toString().padLeft(2, '0')}', styles: c);
    b += g.hr();
    if (v != null && v['mode'] == 'fixed') {
      b += g.text('Fee: Rs ${v['fixed']} (fixed)', styles: const PosStyles(align: PosAlign.center, bold: true));
    } else if (v != null) {
      b += g.text('1hr Rs ${v['h1']}  2hr Rs ${v['h2']}', styles: c);
      b += g.text('3hr Rs ${v['h3']}  +hr Rs ${v['extra']}', styles: c);
    }
    b += g.text('Show this token at exit', styles: c);
    b += g.qrcode('TOKEN-${t['id']}');
    final pay = '${db['settings']['payNo']}';
    if (pay.isNotEmpty) {
      b += g.hr();
      b += g.text('Online payment:', styles: c);
      b += g.text(pay, styles: const PosStyles(align: PosAlign.center, bold: true));
      b += g.qrcode(pay);
    }
    b += g.feed(3);
    final ok = await PrintBluetoothThermal.writeBytes(b);
    return ok ? 'Token print ho gaya' : 'Print nahi ho saka';
  } catch (e) {
    return 'Print error: $e';
  }
}

// ---------- App ----------
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  sp = await SharedPreferences.getInstance();
  loadDb();
  runApp(const ParkingApp());
}

class ParkingApp extends StatelessWidget {
  const ParkingApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Parking App',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF2A7F8E)),
          scaffoldBackgroundColor: const Color(0xFFF4F8F9),
        ),
        home: const Root(),
      );
}

class Root extends StatefulWidget {
  const Root({super.key});
  @override
  State<Root> createState() => _RootState();
}

class _RootState extends State<Root> {
  void refresh() {
    save();
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    if (db['user'] == null) return AuthScreen(signup: true, done: refresh);
    if (db['loggedIn'] != true) return AuthScreen(signup: false, done: refresh);
    if (db['shop'] == null) return ShopScreen(done: refresh);
    return Home(onLogout: refresh);
  }
}

class AuthScreen extends StatefulWidget {
  final bool signup;
  final VoidCallback done;
  const AuthScreen({super.key, required this.signup, required this.done});
  @override
  State<AuthScreen> createState() => _AuthState();
}

class _AuthState extends State<AuthScreen> {
  final n = TextEditingController(), p = TextEditingController();
  void go() {
    if (n.text.trim().isEmpty || p.text.isEmpty) return msg(context, 'Naam aur password likhein');
    if (widget.signup) {
      db['user'] = {'name': n.text.trim(), 'pass': p.text};
    } else {
      final u = db['user'];
      if (u['name'] != n.text.trim() || u['pass'] != p.text) return msg(context, 'Naam ya password ghalat hai');
    }
    db['loggedIn'] = true;
    widget.done();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              const Icon(Icons.local_parking, size: 80, color: Color(0xFF2A7F8E)),
              const SizedBox(height: 8),
              Text(widget.signup ? 'Account banayein' : 'Login', style: Theme.of(context).textTheme.headlineSmall),
              const SizedBox(height: 24),
              tf(n, 'Naam / Username'),
              tf(p, 'Password', pw: true),
              SizedBox(width: double.infinity, child: FilledButton(onPressed: go, child: Text(widget.signup ? 'Account banayein' : 'Login'))),
            ]),
          ),
        ),
      );
}

class ShopScreen extends StatefulWidget {
  final VoidCallback done;
  const ShopScreen({super.key, required this.done});
  @override
  State<ShopScreen> createState() => _ShopState();
}

class _ShopState extends State<ShopScreen> {
  final n = TextEditingController(), pl = TextEditingController(), ph = TextEditingController();
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Parking ki details')),
        body: Padding(
          padding: const EdgeInsets.all(24),
          child: ListView(children: [
            tf(n, 'Shop / Parking ka naam'),
            tf(pl, 'Jagah / Address'),
            tf(ph, 'Phone number', num: true),
            FilledButton(
              onPressed: () {
                if (n.text.trim().isEmpty) return msg(context, 'Shop ka naam likhein');
                db['shop'] = {'name': n.text.trim(), 'place': pl.text.trim(), 'phone': ph.text.trim()};
                widget.done();
              },
              child: const Text('Aage chalein'),
            ),
          ]),
        ),
      );
}

class Home extends StatefulWidget {
  final VoidCallback onLogout;
  const Home({super.key, required this.onLogout});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  int tab = 0;
  void rf() {
    save();
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final pages = [dashboard(), inside(), reports(), settings()];
    return Scaffold(
      appBar: AppBar(title: Text(db['shop']['name']), backgroundColor: const Color(0xFF2A7F8E), foregroundColor: Colors.white),
      body: pages[tab],
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.directions_car), label: 'Inside'),
          NavigationDestination(icon: Icon(Icons.bar_chart), label: 'Reports'),
          NavigationDestination(icon: Icon(Icons.settings), label: 'Settings'),
        ],
      ),
    );
  }

  List<Map> get tokens => (db['tokens'] as List).cast<Map>();

  Widget dashboard() {
    final inside = tokens.where((t) => t['out'] == null).length;
    final inToday = tokens.where((t) => today(t['in'])).length;
    final done = tokens.where((t) => t['out'] != null && today(t['out'])).toList();
    int cash = 0, online = 0;
    for (final t in done) {
      if (t['pay'] == 'online') {
        online += t['fee'] as int;
      } else {
        cash += t['fee'] as int;
      }
    }
    final colors = [Colors.orange, Colors.blue, Colors.green, Colors.purple, Colors.red, Colors.teal, Colors.pink, Colors.indigo];
    final vs = (db['vehicles'] as List).cast<Map>();
    return ListView(padding: const EdgeInsets.all(16), children: [
      Card(
        color: const Color(0xFF1F5F6B),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: DefaultTextStyle(
            style: const TextStyle(color: Colors.white, fontSize: 15),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Abhi andar'),
              Text('$inside', style: const TextStyle(fontSize: 40, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Text('Aaj aayi: $inToday   |   Aaj gayi: ${done.length}'),
              Text('Aaj cash: Rs $cash   |   Online: Rs $online'),
            ]),
          ),
        ),
      ),
      const SizedBox(height: 12),
      const Text('Gaadi andar karne ke liye tap karein', style: TextStyle(fontWeight: FontWeight.w600)),
      const SizedBox(height: 8),
      GridView.count(
        crossAxisCount: 2, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
        mainAxisSpacing: 10, crossAxisSpacing: 10, childAspectRatio: 1.5,
        children: [
          for (int i = 0; i < vs.length; i++)
            InkWell(
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => EntryScreen(v: vs[i]))).then((_) => rf()),
              child: Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(color: colors[i % colors.length], borderRadius: BorderRadius.circular(16)),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.end, children: [
                  Text(vs[i]['name'], style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
                  Text(vs[i]['mode'] == 'fixed' ? 'Rs ${vs[i]['fixed']} fixed' : 'Rs ${vs[i]['h1']}/hr+', style: const TextStyle(color: Colors.white70)),
                ]),
              ),
            ),
        ],
      ),
    ]);
  }

  String q = '';
  Widget inside() {
    final list = tokens.where((t) => t['out'] == null && ('${t['plate']}'.toLowerCase().contains(q.toLowerCase()) || '#${t['id']}' == q || '${t['id']}' == q)).toList().reversed.toList();
    return Column(children: [
      Padding(
        padding: const EdgeInsets.all(12),
        child: TextField(
          onChanged: (s) => setState(() => q = s.trim()),
          decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Number plate ya token number', border: OutlineInputBorder()),
        ),
      ),
      Expanded(
        child: list.isEmpty
            ? const Center(child: Text('Koi gaadi andar nahi'))
            : ListView(children: [
                for (final t in list)
                  ListTile(
                    leading: CircleAvatar(child: Text('${t['id']}')),
                    title: Text('${t['plate']}  -  ${t['vehicle']}', style: const TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Text('Ruki hui: ${dur(t['in'])}'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ExitScreen(t: t))).then((_) => rf()),
                  ),
              ]),
      ),
    ]);
  }

  Widget reports() {
    final done = tokens.where((t) => t['out'] != null && today(t['out'])).toList().reversed.toList();
    int total = 0;
    for (final t in done) {
      total += t['fee'] as int;
    }
    return Column(children: [
      ListTile(title: const Text('Aaj ki kul kamai'), trailing: Text('Rs $total', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),
      const Divider(),
      Expanded(
        child: ListView(children: [
          for (final t in done)
            ListTile(
              title: Text('#${t['id']}  ${t['plate']}'),
              subtitle: Text('${t['vehicle']}  |  ${t['pay'] == 'online' ? 'Online' : 'Cash'}${t['lost'] == true ? '  |  Token lost' : ''}'),
              trailing: Text('Rs ${t['fee']}', style: const TextStyle(fontWeight: FontWeight.bold)),
            ),
        ]),
      ),
    ]);
  }

  Widget settings() {
    final s = db['settings'];
    final vs = (db['vehicles'] as List).cast<Map>();
    return ListView(children: [
      const ListTile(title: Text('Vehicles aur rate', style: TextStyle(fontWeight: FontWeight.bold))),
      for (int i = 0; i < vs.length; i++)
        ListTile(
          title: Text(vs[i]['name']),
          subtitle: Text(vs[i]['mode'] == 'fixed' ? 'Fixed Rs ${vs[i]['fixed']}' : '1h ${vs[i]['h1']} | 2h ${vs[i]['h2']} | 3h ${vs[i]['h3']} | +hr ${vs[i]['extra']}'),
          trailing: const Icon(Icons.edit),
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => VehicleEdit(idx: i))).then((_) => rf()),
        ),
      ListTile(
        leading: const Icon(Icons.add_circle),
        title: const Text('Vehicle add karein'),
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const VehicleEdit())).then((_) => rf()),
      ),
      const Divider(),
      ListTile(
        leading: const Icon(Icons.print),
        title: const Text('Connect to Printer'),
        subtitle: Text(s['printerMac'] == null ? 'Connect nahi' : 'Connected: ${s['printerMac']}'),
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PrinterScreen())).then((_) => rf()),
      ),
      ListTile(
        leading: const Icon(Icons.tune),
        title: const Text('Grace time, lost token fee, payment number'),
        subtitle: Text('Grace ${s['grace']} min | Lost Rs ${s['lostFee']} | Pay: ${s['payNo'] == '' ? '-' : s['payNo']}'),
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const GeneralSettings())).then((_) => rf()),
      ),
      ListTile(
        leading: const Icon(Icons.logout),
        title: const Text('Logout'),
        onTap: () {
          db['loggedIn'] = false;
          widget.onLogout();
        },
      ),
    ]);
  }
}

class EntryScreen extends StatefulWidget {
  final Map v;
  const EntryScreen({super.key, required this.v});
  @override
  State<EntryScreen> createState() => _EntryState();
}

class _EntryState extends State<EntryScreen> {
  final plate = TextEditingController();
  String? photo;
  int expH = 0;

  Future<void> snap() async {
    final x = await ImagePicker().pickImage(source: ImageSource.camera, imageQuality: 60);
    if (x != null) setState(() => photo = x.path);
  }

  Future<void> create() async {
    final p = plate.text.trim().toUpperCase();
    if (p.isEmpty) return msg(context, 'Number plate likhein');
    final tokens = (db['tokens'] as List).cast<Map>();
    final dup = tokens.where((t) => t['out'] == null && t['plate'] == p);
    if (dup.isNotEmpty) return msg(context, 'Ye gaadi pehle se andar hai (token #${dup.first['id']})');
    final t = {
      'id': db['nextToken'], 'plate': p, 'vehicle': widget.v['name'],
      'in': DateTime.now().toIso8601String(), 'expH': expH, 'photo': photo,
      'out': null, 'fee': null, 'pay': null, 'lost': false,
    };
    db['nextToken'] = (db['nextToken'] as int) + 1;
    (db['tokens'] as List).add(t);
    save();
    final r = await printSlip(t);
    if (!mounted) return;
    msg(context, r);
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final hourly = widget.v['mode'] == 'hourly';
    return Scaffold(
      appBar: AppBar(title: Text('New entry - ${widget.v['name']}')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        InkWell(
          onTap: snap,
          child: Container(
            height: 180,
            decoration: BoxDecoration(color: Colors.black12, borderRadius: BorderRadius.circular(12)),
            child: photo == null
                ? const Center(child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.camera_alt, size: 40), Text('Gaadi ki photo kheenchein')]))
                : ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.file(File(photo!), fit: BoxFit.cover, width: double.infinity)),
          ),
        ),
        const SizedBox(height: 12),
        tf(plate, 'Number plate (maslan ALE-931)'),
        if (hourly)
          DropdownButtonFormField<int>(
            value: expH,
            decoration: const InputDecoration(labelText: 'Kitne ghante ke liye (optional)', border: OutlineInputBorder()),
            items: [
              const DropdownMenuItem(value: 0, child: Text('Tay nahi')),
              for (int h = 1; h <= 12; h++) DropdownMenuItem(value: h, child: Text('$h ghanta')),
            ],
            onChanged: (v) => setState(() => expH = v ?? 0),
          ),
        const SizedBox(height: 16),
        FilledButton.icon(onPressed: create, icon: const Icon(Icons.print), label: const Text('Andar aane do aur token print karein')),
      ]),
    );
  }
}

class ExitScreen extends StatefulWidget {
  final Map t;
  const ExitScreen({super.key, required this.t});
  @override
  State<ExitScreen> createState() => _ExitState();
}

class _ExitState extends State<ExitScreen> {
  bool lost = false;
  String pay = 'cash';

  @override
  Widget build(BuildContext context) {
    final t = widget.t;
    final v = vehicleOf(t['vehicle']) ?? {'mode': 'fixed', 'fixed': 0};
    final base = calcFee(v, t);
    final fee = base + (lost ? db['settings']['lostFee'] as int : 0);
    final d = DateTime.parse(t['in']);
    return Scaffold(
      appBar: AppBar(title: Text('Token #${t['id']}')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        if (t['photo'] != null && File(t['photo']).existsSync())
          ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.file(File(t['photo']), height: 180, fit: BoxFit.cover)),
        const SizedBox(height: 12),
        Center(child: Text('${t['plate']}', style: const TextStyle(fontSize: 32, fontWeight: FontWeight.bold))),
        Card(
          child: Column(children: [
            ListTile(title: const Text('Vehicle'), trailing: Text('${t['vehicle']}')),
            ListTile(title: const Text('Andar aaya'), trailing: Text('${d.day}-${d.month} ${d.hour}:${d.minute.toString().padLeft(2, '0')}')),
            ListTile(title: const Text('Ruki hui'), trailing: Text(dur(t['in']))),
            if ((t['expH'] ?? 0) > 0) ListTile(title: const Text('Tay ghante'), trailing: Text('${t['expH']}')),
          ]),
        ),
        SwitchListTile(title: Text('Token lost (+Rs ${db['settings']['lostFee']})'), value: lost, onChanged: (x) => setState(() => lost = x)),
        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(color: const Color(0xFF1F5F6B), borderRadius: BorderRadius.circular(14)),
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            const Text('Collect', style: TextStyle(color: Colors.white, fontSize: 18)),
            Text('Rs $fee', style: const TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.bold)),
          ]),
        ),
        const SizedBox(height: 12),
        SegmentedButton<String>(
          segments: const [ButtonSegment(value: 'cash', label: Text('Cash'), icon: Icon(Icons.payments)), ButtonSegment(value: 'online', label: Text('Online'), icon: Icon(Icons.qr_code))],
          selected: {pay},
          onSelectionChanged: (s) => setState(() => pay = s.first),
        ),
        const SizedBox(height: 12),
        FilledButton(
          onPressed: () {
            t['out'] = DateTime.now().toIso8601String();
            t['fee'] = fee;
            t['pay'] = pay;
            t['lost'] = lost;
            save();
            Navigator.pop(context);
          },
          child: const Text('Collected - gaadi nikaalein'),
        ),
        TextButton(onPressed: () async => msg(context, await printSlip(t)), child: const Text('Token dobara print')),
        TextButton(
          onPressed: () {
            (db['tokens'] as List).removeWhere((x) => x['id'] == t['id']);
            save();
            Navigator.pop(context);
          },
          child: const Text('Token cancel', style: TextStyle(color: Colors.red)),
        ),
      ]),
    );
  }
}

class VehicleEdit extends StatefulWidget {
  final int? idx;
  const VehicleEdit({super.key, this.idx});
  @override
  State<VehicleEdit> createState() => _VehicleEditState();
}

class _VehicleEditState extends State<VehicleEdit> {
  final c = {for (final k in ['name', 'fixed', 'h1', 'h2', 'h3', 'extra']) k: TextEditingController()};
  String mode = 'fixed';

  @override
  void initState() {
    super.initState();
    if (widget.idx != null) {
      final v = db['vehicles'][widget.idx!] as Map;
      mode = v['mode'];
      for (final k in c.keys) {
        c[k]!.text = '${v[k]}';
      }
    }
  }

  int n(String k) => int.tryParse(c[k]!.text.trim()) ?? 0;

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(widget.idx == null ? 'Naya vehicle' : 'Vehicle edit')),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          tf(c['name']!, 'Vehicle ka naam (maslan Tractor)'),
          SegmentedButton<String>(
            segments: const [ButtonSegment(value: 'fixed', label: Text('Fixed rate')), ButtonSegment(value: 'hourly', label: Text('Ghante ke hisaab'))],
            selected: {mode},
            onSelectionChanged: (s) => setState(() => mode = s.first),
          ),
          const SizedBox(height: 16),
          if (mode == 'fixed') tf(c['fixed']!, 'Fixed rate (Rs)', num: true),
          if (mode == 'hourly') ...[
            tf(c['h1']!, '1 ghante ka rate', num: true),
            tf(c['h2']!, '2 ghante ka rate', num: true),
            tf(c['h3']!, '3 ghante ka rate', num: true),
            tf(c['extra']!, '3 ghante ke baad har extra ghante ka rate', num: true),
          ],
          FilledButton(
            onPressed: () {
              if (c['name']!.text.trim().isEmpty) return msg(context, 'Naam likhein');
              final v = {'name': c['name']!.text.trim(), 'mode': mode, 'fixed': n('fixed'), 'h1': n('h1'), 'h2': n('h2'), 'h3': n('h3'), 'extra': n('extra')};
              if (widget.idx == null) {
                (db['vehicles'] as List).add(v);
              } else {
                (db['vehicles'] as List)[widget.idx!] = v;
              }
              save();
              Navigator.pop(context);
            },
            child: const Text('Save'),
          ),
          if (widget.idx != null)
            TextButton(
              onPressed: () {
                (db['vehicles'] as List).removeAt(widget.idx!);
                save();
                Navigator.pop(context);
              },
              child: const Text('Delete', style: TextStyle(color: Colors.red)),
            ),
        ]),
      );
}

class GeneralSettings extends StatefulWidget {
  const GeneralSettings({super.key});
  @override
  State<GeneralSettings> createState() => _GeneralState();
}

class _GeneralState extends State<GeneralSettings> {
  final s = db['settings'];
  late final g = TextEditingController(text: '${s['grace']}');
  late final l = TextEditingController(text: '${s['lostFee']}');
  late final p = TextEditingController(text: '${s['payNo']}');

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Settings')),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          tf(g, 'Grace time (minute) - itna extra waqt free', num: true),
          tf(l, 'Token lost ka extra charge (Rs)', num: true),
          tf(p, 'Online payment number / account (slip par print hoga)'),
          FilledButton(
            onPressed: () {
              s['grace'] = int.tryParse(g.text) ?? 15;
              s['lostFee'] = int.tryParse(l.text) ?? 100;
              s['payNo'] = p.text.trim();
              save();
              Navigator.pop(context);
            },
            child: const Text('Save'),
          ),
        ]),
      );
}

class PrinterScreen extends StatefulWidget {
  const PrinterScreen({super.key});
  @override
  State<PrinterScreen> createState() => _PrinterState();
}

class _PrinterState extends State<PrinterScreen> {
  List<BluetoothInfo> list = [];
  String info = 'Pehle phone ki Bluetooth settings mein printer pair karein.';

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    await [Permission.bluetoothConnect, Permission.bluetoothScan].request();
    final l = await PrintBluetoothThermal.pairedBluetooths;
    if (mounted) setState(() => list = l);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Connect to Printer')),
        body: Column(children: [
          Padding(padding: const EdgeInsets.all(12), child: Text(info)),
          Expanded(
            child: ListView(children: [
              for (final b in list)
                ListTile(
                  leading: const Icon(Icons.print),
                  title: Text(b.name),
                  subtitle: Text(b.macAdress),
                  onTap: () async {
                    final ok = await PrintBluetoothThermal.connect(macPrinterAddress: b.macAdress);
                    if (ok) {
                      db['settings']['printerMac'] = b.macAdress;
                      save();
                    }
                    setState(() => info = ok ? '${b.name} connect ho gaya' : 'Connect nahi ho saka, printer on karein');
                  },
                ),
            ]),
          ),
        ]),
      );
}
