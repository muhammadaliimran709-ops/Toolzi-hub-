PARKING APP - V1 (Flutter)

APK BANANE KE STEPS (computer par Flutter installed ho)
1) Zip extract karein, folder mein terminal kholein.
2) flutter create --platforms=android .
3) android/app/src/main/AndroidManifest.xml mein <manifest> ke andar ye lines add karein:
   <uses-permission android:name="android.permission.BLUETOOTH" android:maxSdkVersion="30"/>
   <uses-permission android:name="android.permission.BLUETOOTH_ADMIN" android:maxSdkVersion="30"/>
   <uses-permission android:name="android.permission.BLUETOOTH_CONNECT"/>
   <uses-permission android:name="android.permission.BLUETOOTH_SCAN" android:usesPermissionFlags="neverForLocation"/>
   <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>
   <uses-permission android:name="android.permission.CAMERA"/>
4) android/app/build.gradle (ya .kts) mein minSdk 21 ya zyada rakhein.
5) flutter pub get
6) Phone par test (USB debugging on): flutter run
7) APK: flutter build apk --release
   File yahan milegi: build/app/outputs/flutter-apk/app-release.apk

Printer: pehle phone ki Bluetooth settings mein printer pair karein, phir app: Settings > Connect to Printer.
